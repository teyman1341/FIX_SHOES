using System;
using System.Collections;
using System.Data;
using System.Web;
using System.IO;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using COMPONENTS;
using System.Net.Mail;
using System.Collections.Generic;
namespace PROJETO
{
	public partial class FIXSHOES : System.Web.UI.Page
	{
  
		#region SQLExecutaRetornoF9 - Pega primeiro campo da sql informa no banco de dados
        //Padrão retornando um array
        public static List<object> SQLExecutaRetornoF9(string SQL, int RetornarComoList, string Banco)
        {
            List<object> retorno = new List<object>();
            if (Banco == "")
            {
                foreach (DatabaseInfo vgDbi in ((Databases) HttpContext.Current.Application["Databases"]).DataBaseList.Values)
                {
                    Banco = vgDbi.DataBaseAlias;
                }
            }

            COMPONENTS.Data.DataAccessObject Dao = COMPONENTS.Configuration.Settings.GetDataAccessObject(((Databases) HttpContext.Current.Application["Databases"])[Banco]);


            DataSet dss = Dao.RunSql(String.Format(SQL));
            System.Data.DataTableReader dtr = dss.CreateDataReader();
            while (dtr.Read())
            {
                for (int i = 0; i < dtr.FieldCount; i++)
                {
                    retorno.Add(dtr[i]);
                }
            }
            Dao.CloseConnection();
            Dao.Dispose();

            return retorno;
        }
		
		//Classica, retornando a primeira coluna como string
        public static string SQLExecutaRetornoF9(string SQL2, string Banco)
        {
			List<object> retorno = SQLExecutaRetornoF9(SQL2,0, Banco);
			if (retorno.Count > 0)
			{
				return retorno[0].ToString();
			}
			else
			{
				return "";
			}
				
        }
		
		public static bool SQLExecutaF9(string SQL, string banco)
		{
            bool exec;
			COMPONENTS.Data.DataAccessObject Dao = COMPONENTS.Configuration.Settings.GetDataAccessObject(((Databases)HttpContext.Current.Application["Databases"])[banco]);
            try { 
		        DataSet dss = Dao.RunSql(String.Format(SQL));
                exec = true;
            }
            catch
            {
                exec = false;
            }
			Dao.CloseConnection();
			Dao.Dispose();
            return exec;
		}
		#endregion
		

	}

}

using System;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Data;
using PROJETO;
using COMPONENTS;
using COMPONENTS.Data;
using COMPONENTS.Security;
using COMPONENTS.Configuration;
using System.IO;
using System.Web;
using System.Web.UI;
using PROJETO.DataProviders;
using PROJETO.DataPages;

namespace PROJETO.DataProviders
{
	public partial class CRMSSI_TB_NEGOCIOItem : GeneralDataProviderItem
	{
		private string DataBaseName;
				
		private DataAccessObject _Dao;
		public DataAccessObject Dao
		{
			get 
			{ 
				if (_Dao == null) _Dao = Settings.GetDataAccessObject(((Databases)HttpContext.Current.Application["Databases"])[DataBaseName]);
				return _Dao;
			}
		}

		public CRMSSI_TB_NEGOCIOItem(string DataBaseName) : this(DataBaseName, true)
		{
		}

		public CRMSSI_TB_NEGOCIOItem(string DataBaseName, params string[] FieldNames) : this(DataBaseName, false, FieldNames)
		{
		}
		
		/// <summary>
		/// Construtor da Página
		/// </summary>
		private CRMSSI_TB_NEGOCIOItem(string DataBaseName, bool AllFields, params string[] FieldNames)
		{
			this.DataBaseName = DataBaseName;	
			Fields = CreateItemFields(AllFields, FieldNames);
		}
		
		public static Dictionary<string, FieldBase> CreateItemFields(bool AllFields, params string[] FieldNames)
		{
			Dictionary<string, FieldBase> NewFields = new Dictionary<string, FieldBase>();
			 NewFields.Add("NEG_ID", new LongField("NEG_ID", "", null, false));
			if (AllFields || Contains(FieldNames, "NEG_TITULO")) NewFields.Add("NEG_TITULO", new TextField("NEG_TITULO", "", null, true));
			if (AllFields || Contains(FieldNames, "CLI_ID")) NewFields.Add("CLI_ID", new LongField("CLI_ID", "", null, true));
			if (AllFields || Contains(FieldNames, "NEG_RESPONSAVEL")) NewFields.Add("NEG_RESPONSAVEL", new TextField("NEG_RESPONSAVEL", "", null, true));
			if (AllFields || Contains(FieldNames, "NEG_VALORTOTAL")) NewFields.Add("NEG_VALORTOTAL", new DecimalField("NEG_VALORTOTAL", "", null, true));
			if (AllFields || Contains(FieldNames, "NEG_VALORULT")) NewFields.Add("NEG_VALORULT", new DecimalField("NEG_VALORULT", "", null, true));
			if (AllFields || Contains(FieldNames, "NEG_DATAINICIAL")) NewFields.Add("NEG_DATAINICIAL", new DateField("NEG_DATAINICIAL", "", null, true));
			if (AllFields || Contains(FieldNames, "NEG_DATACONCLUSAO")) NewFields.Add("NEG_DATACONCLUSAO", new DateField("NEG_DATACONCLUSAO", "", null, true));
			if (AllFields || Contains(FieldNames, "NEG_DESCRICAO")) NewFields.Add("NEG_DESCRICAO", new MemoField("NEG_DESCRICAO", "", null, true));
			if (AllFields || Contains(FieldNames, "NEG_STATUS")) NewFields.Add("NEG_STATUS", new TextField("NEG_STATUS", "", null, true));
			if (AllFields || Contains(FieldNames, "NEG_MOTIVOPERDA")) NewFields.Add("NEG_MOTIVOPERDA", new TextField("NEG_MOTIVOPERDA", "", null, true));
			if (AllFields || Contains(FieldNames, "FASE_ID")) NewFields.Add("FASE_ID", new LongField("FASE_ID", "", null, true));
			if (AllFields || Contains(FieldNames, "FASE_PAR")) NewFields.Add("FASE_PAR", new LongField("FASE_PAR", "", null, true));
			if (AllFields || Contains(FieldNames, "NEG_COMENTARIO_PERDA")) NewFields.Add("NEG_COMENTARIO_PERDA", new TextField("NEG_COMENTARIO_PERDA", "", null, true));
			if (AllFields || Contains(FieldNames, "PROD_ID")) NewFields.Add("PROD_ID", new LongField("PROD_ID", "", null, true));
			if (AllFields || Contains(FieldNames, "NEG_CORPOPROP")) NewFields.Add("NEG_CORPOPROP", new MemoField("NEG_CORPOPROP", "", null, true));
			
			if (!AllFields)
			{
				Dictionary<string, FieldBase> NewFieldsOrder = new Dictionary<string, FieldBase>();
				foreach (string Field in FieldNames)
				{
					NewFieldsOrder.Add(Field, NewFields[Field]);
				}
				NewFields = NewFieldsOrder; 
			}
			
			return NewFields;
		}
		
		/// <summary>
		/// Valida se todos os campos foram preenchidos corretamente
		/// </summary>
		/// <param name="provider">Provider que vai ser usado para inserir o registro na tabela</param>
		public override void Validate(GeneralDataProvider provider)
		{
		}
	}
	
	/// <summary>
	/// Classe de provider usada para acessar a tabela de produtos
	/// </summary>
	public class CRMSSI_TB_NEGOCIODataProvider : GeneralDataProvider
	{
		public FieldBase this[string ColumnName]
		{
			get
			{
				return Item[ColumnName];
			}
		}

		public override Dictionary<string, FieldBase> CreateItemFields()
		{
			return CRMSSI_TB_NEGOCIOItem.CreateItemFields(true); 
		}
	
		public CRMSSI_TB_NEGOCIODataProvider(IGeneralDataProvider BasePage, string TableName, string DataBaseName, string IndexName, string Name) : base(BasePage, TableName, DataBaseName, IndexName, Name, "")
		{
		}

		public override void CreateUniqueParameter()
		{
			Parameters.Clear();
			switch (IndexName)
			{
				case "PK_TB_NEGOCIO":
					CreateParameter("NEG_ID");
					break;
			}
		}
				
		public override void CreateParameters()
		{
			Parameters.Clear();
			switch (IndexName)
			{
				case "PK_TB_NEGOCIO":
					CreateParameter("NEG_ID");
					break;
			}
			base.CreateParameters();
		}

		public override string ProviderFilterExpression()
		{
			return this.GetFilterExpression( CRMSSI_TB_NEGOCIOItem.CreateItemFields(false, GetUniqueKeyFields()));
		}

		public override string[] GetUniqueKeyFields()
		{
			return new string[] { "NEG_ID" };
		}			
	}
}

using System;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Data;
using PROJETO;
using COMPONENTS;
using COMPONENTS.Data;
using COMPONENTS.Security;
using COMPONENTS.Configuration;
using System.IO;
using System.Web;
using System.Web.UI;
using PROJETO.DataProviders;
using PROJETO.DataPages;

namespace PROJETO.DataProviders
{
	public partial class CRMSSI_TB_TAREFAItem : GeneralDataProviderItem
	{
		private string DataBaseName;
				
		private DataAccessObject _Dao;
		public DataAccessObject Dao
		{
			get 
			{ 
				if (_Dao == null) _Dao = Settings.GetDataAccessObject(((Databases)HttpContext.Current.Application["Databases"])[DataBaseName]);
				return _Dao;
			}
		}

		public CRMSSI_TB_TAREFAItem(string DataBaseName) : this(DataBaseName, true)
		{
		}

		public CRMSSI_TB_TAREFAItem(string DataBaseName, params string[] FieldNames) : this(DataBaseName, false, FieldNames)
		{
		}
		
		/// <summary>
		/// Construtor da Página
		/// </summary>
		private CRMSSI_TB_TAREFAItem(string DataBaseName, bool AllFields, params string[] FieldNames)
		{
			this.DataBaseName = DataBaseName;	
			Fields = CreateItemFields(AllFields, FieldNames);
		}
		
		public static Dictionary<string, FieldBase> CreateItemFields(bool AllFields, params string[] FieldNames)
		{
			Dictionary<string, FieldBase> NewFields = new Dictionary<string, FieldBase>();
			 NewFields.Add("TAR_ID", new LongField("TAR_ID", "", null, false));
			if (AllFields || Contains(FieldNames, "TAR_TIPO")) NewFields.Add("TAR_TIPO", new TextField("TAR_TIPO", "", null, true));
			if (AllFields || Contains(FieldNames, "TAR_DESC")) NewFields.Add("TAR_DESC", new TextField("TAR_DESC", "", null, true));
			if (AllFields || Contains(FieldNames, "NEG_ID")) NewFields.Add("NEG_ID", new LongField("NEG_ID", "", null, true));
			if (AllFields || Contains(FieldNames, "TAR_RESPONSAVEL")) NewFields.Add("TAR_RESPONSAVEL", new TextField("TAR_RESPONSAVEL", "", null, true));
			if (AllFields || Contains(FieldNames, "CLI_ID")) NewFields.Add("CLI_ID", new LongField("CLI_ID", "", null, true));
			if (AllFields || Contains(FieldNames, "TAR_FINALIZADO")) NewFields.Add("TAR_FINALIZADO", new BooleanField("TAR_FINALIZADO", "", null, true));
			if (AllFields || Contains(FieldNames, "TAR_DATAHORA")) NewFields.Add("TAR_DATAHORA", new DateField("TAR_DATAHORA", "", null, true));
			
			if (!AllFields)
			{
				Dictionary<string, FieldBase> NewFieldsOrder = new Dictionary<string, FieldBase>();
				foreach (string Field in FieldNames)
				{
					NewFieldsOrder.Add(Field, NewFields[Field]);
				}
				NewFields = NewFieldsOrder; 
			}
			
			return NewFields;
		}
		
		/// <summary>
		/// Valida se todos os campos foram preenchidos corretamente
		/// </summary>
		/// <param name="provider">Provider que vai ser usado para inserir o registro na tabela</param>
		public override void Validate(GeneralDataProvider provider)
		{
		}
	}
	
	/// <summary>
	/// Classe de provider usada para acessar a tabela de produtos
	/// </summary>
	public class CRMSSI_TB_TAREFADataProvider : GeneralDataProvider
	{
		public FieldBase this[string ColumnName]
		{
			get
			{
				return Item[ColumnName];
			}
		}

		public override Dictionary<string, FieldBase> CreateItemFields()
		{
			return CRMSSI_TB_TAREFAItem.CreateItemFields(true); 
		}
	
		public CRMSSI_TB_TAREFADataProvider(IGeneralDataProvider BasePage, string TableName, string DataBaseName, string IndexName, string Name) : base(BasePage, TableName, DataBaseName, IndexName, Name, "")
		{
		}

		public override void CreateUniqueParameter()
		{
			Parameters.Clear();
			switch (IndexName)
			{
				case "PK_TB_TAREFA":
					CreateParameter("TAR_ID");
					break;
			}
		}
				
		public override void CreateParameters()
		{
			Parameters.Clear();
			switch (IndexName)
			{
				case "PK_TB_TAREFA":
					CreateParameter("TAR_ID");
					break;
			}
			base.CreateParameters();
		}

		public override string ProviderFilterExpression()
		{
			return this.GetFilterExpression( CRMSSI_TB_TAREFAItem.CreateItemFields(false, GetUniqueKeyFields()));
		}

		public override string[] GetUniqueKeyFields()
		{
			return new string[] { "TAR_ID" };
		}			
	}
}

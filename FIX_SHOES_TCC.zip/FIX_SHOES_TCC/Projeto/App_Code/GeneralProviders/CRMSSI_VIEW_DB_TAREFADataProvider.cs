using System;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Data;
using PROJETO;
using COMPONENTS;
using COMPONENTS.Data;
using COMPONENTS.Security;
using COMPONENTS.Configuration;
using System.IO;
using System.Web;
using System.Web.UI;
using PROJETO.DataProviders;
using PROJETO.DataPages;

namespace PROJETO.DataProviders
{
	public partial class CRMSSI_VIEW_DB_TAREFAItem : GeneralDataProviderItem
	{
		private string DataBaseName;
				
		private DataAccessObject _Dao;
		public DataAccessObject Dao
		{
			get 
			{ 
				if (_Dao == null) _Dao = Settings.GetDataAccessObject(((Databases)HttpContext.Current.Application["Databases"])[DataBaseName]);
				return _Dao;
			}
		}

		public CRMSSI_VIEW_DB_TAREFAItem(string DataBaseName) : this(DataBaseName, true)
		{
		}

		public CRMSSI_VIEW_DB_TAREFAItem(string DataBaseName, params string[] FieldNames) : this(DataBaseName, false, FieldNames)
		{
		}
		
		/// <summary>
		/// Construtor da Página
		/// </summary>
		private CRMSSI_VIEW_DB_TAREFAItem(string DataBaseName, bool AllFields, params string[] FieldNames)
		{
			this.DataBaseName = DataBaseName;	
			Fields = CreateItemFields(AllFields, FieldNames);
		}
		
		public static Dictionary<string, FieldBase> CreateItemFields(bool AllFields, params string[] FieldNames)
		{
			Dictionary<string, FieldBase> NewFields = new Dictionary<string, FieldBase>();
			if (AllFields || Contains(FieldNames, "Tipo")) NewFields.Add("Tipo", new TextField("Tipo", "", null, true));
			if (AllFields || Contains(FieldNames, "NEG_TITULO")) NewFields.Add("NEG_TITULO", new TextField("NEG_TITULO", "", null, true));
			if (AllFields || Contains(FieldNames, "Descricao")) NewFields.Add("Descricao", new TextField("Descricao", "", null, true));
			if (AllFields || Contains(FieldNames, "TAR_DESC")) NewFields.Add("TAR_DESC", new TextField("TAR_DESC", "", null, true));
			if (AllFields || Contains(FieldNames, "ID")) NewFields.Add("ID", new TextField("ID", "", null, true));
			if (AllFields || Contains(FieldNames, "Finalizado")) NewFields.Add("Finalizado", new BooleanField("Finalizado", "", null, true));
			if (AllFields || Contains(FieldNames, "Data")) NewFields.Add("Data", new DateField("Data", "", null, true));
			if (AllFields || Contains(FieldNames, "NEG_ID")) NewFields.Add("NEG_ID", new LongField("NEG_ID", "", null, true));
			if (AllFields || Contains(FieldNames, "CLI_NOME")) NewFields.Add("CLI_NOME", new TextField("CLI_NOME", "", null, true));
			if (AllFields || Contains(FieldNames, "CLI_FONE")) NewFields.Add("CLI_FONE", new TextField("CLI_FONE", "", null, true));
			if (AllFields || Contains(FieldNames, "CLI_CELULAR")) NewFields.Add("CLI_CELULAR", new TextField("CLI_CELULAR", "", null, true));
			if (AllFields || Contains(FieldNames, "CLI_EMAIL")) NewFields.Add("CLI_EMAIL", new TextField("CLI_EMAIL", "", null, true));
			if (AllFields || Contains(FieldNames, "CLI_SKYPE")) NewFields.Add("CLI_SKYPE", new TextField("CLI_SKYPE", "", null, true));
			
			if (!AllFields)
			{
				Dictionary<string, FieldBase> NewFieldsOrder = new Dictionary<string, FieldBase>();
				foreach (string Field in FieldNames)
				{
					NewFieldsOrder.Add(Field, NewFields[Field]);
				}
				NewFields = NewFieldsOrder; 
			}
			
			return NewFields;
		}
		
		/// <summary>
		/// Valida se todos os campos foram preenchidos corretamente
		/// </summary>
		/// <param name="provider">Provider que vai ser usado para inserir o registro na tabela</param>
		public override void Validate(GeneralDataProvider provider)
		{
		}
	}
	
	/// <summary>
	/// Classe de provider usada para acessar a tabela de produtos
	/// </summary>
	public class CRMSSI_VIEW_DB_TAREFADataProvider : GeneralDataProvider
	{
		public FieldBase this[string ColumnName]
		{
			get
			{
				return Item[ColumnName];
			}
		}

		public override Dictionary<string, FieldBase> CreateItemFields()
		{
			return CRMSSI_VIEW_DB_TAREFAItem.CreateItemFields(true); 
		}
	
		public CRMSSI_VIEW_DB_TAREFADataProvider(IGeneralDataProvider BasePage, string TableName, string DataBaseName, string IndexName, string Name) : base(BasePage, TableName, DataBaseName, IndexName, Name, "")
		{
		}

		public override string ProviderFilterExpression()
		{
			return this.GetFilterExpression( CRMSSI_VIEW_DB_TAREFAItem.CreateItemFields(false, GetUniqueKeyFields()));
		}

		public override string[] GetUniqueKeyFields()
		{
			return null;
		}			
	}
}

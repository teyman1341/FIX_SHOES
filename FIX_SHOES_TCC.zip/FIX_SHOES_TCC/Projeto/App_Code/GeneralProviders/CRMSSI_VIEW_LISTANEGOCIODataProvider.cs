using System;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Data;
using PROJETO;
using COMPONENTS;
using COMPONENTS.Data;
using COMPONENTS.Security;
using COMPONENTS.Configuration;
using System.IO;
using System.Web;
using System.Web.UI;
using PROJETO.DataProviders;
using PROJETO.DataPages;

namespace PROJETO.DataProviders
{
	public partial class CRMSSI_VIEW_LISTANEGOCIOItem : GeneralDataProviderItem
	{
		private string DataBaseName;
				
		private DataAccessObject _Dao;
		public DataAccessObject Dao
		{
			get 
			{ 
				if (_Dao == null) _Dao = Settings.GetDataAccessObject(((Databases)HttpContext.Current.Application["Databases"])[DataBaseName]);
				return _Dao;
			}
		}

		public CRMSSI_VIEW_LISTANEGOCIOItem(string DataBaseName) : this(DataBaseName, true)
		{
		}

		public CRMSSI_VIEW_LISTANEGOCIOItem(string DataBaseName, params string[] FieldNames) : this(DataBaseName, false, FieldNames)
		{
		}
		
		/// <summary>
		/// Construtor da Página
		/// </summary>
		private CRMSSI_VIEW_LISTANEGOCIOItem(string DataBaseName, bool AllFields, params string[] FieldNames)
		{
			this.DataBaseName = DataBaseName;	
			Fields = CreateItemFields(AllFields, FieldNames);
		}
		
		public static Dictionary<string, FieldBase> CreateItemFields(bool AllFields, params string[] FieldNames)
		{
			Dictionary<string, FieldBase> NewFields = new Dictionary<string, FieldBase>();
			if (AllFields || Contains(FieldNames, "NEG_ID")) NewFields.Add("NEG_ID", new LongField("NEG_ID", "", null, true));
			if (AllFields || Contains(FieldNames, "NEG_TITULO")) NewFields.Add("NEG_TITULO", new TextField("NEG_TITULO", "", null, true));
			if (AllFields || Contains(FieldNames, "CLI_ID")) NewFields.Add("CLI_ID", new LongField("CLI_ID", "", null, true));
			if (AllFields || Contains(FieldNames, "CLI_NOME")) NewFields.Add("CLI_NOME", new TextField("CLI_NOME", "", null, true));
			if (AllFields || Contains(FieldNames, "FASE_ID")) NewFields.Add("FASE_ID", new LongField("FASE_ID", "", null, true));
			if (AllFields || Contains(FieldNames, "FASE_NOME")) NewFields.Add("FASE_NOME", new TextField("FASE_NOME", "", null, true));
			if (AllFields || Contains(FieldNames, "PROD_ID")) NewFields.Add("PROD_ID", new LongField("PROD_ID", "", null, true));
			if (AllFields || Contains(FieldNames, "PROD_NOME")) NewFields.Add("PROD_NOME", new TextField("PROD_NOME", "", null, true));
			if (AllFields || Contains(FieldNames, "NEG_STATUS")) NewFields.Add("NEG_STATUS", new TextField("NEG_STATUS", "", null, true));
			if (AllFields || Contains(FieldNames, "NEG_VALORTOTAL")) NewFields.Add("NEG_VALORTOTAL", new DecimalField("NEG_VALORTOTAL", "", null, true));
			if (AllFields || Contains(FieldNames, "CLI_CONTATO")) NewFields.Add("CLI_CONTATO", new TextField("CLI_CONTATO", "", null, true));
			if (AllFields || Contains(FieldNames, "NEG_VALORULT")) NewFields.Add("NEG_VALORULT", new DecimalField("NEG_VALORULT", "", null, true));
			
			if (!AllFields)
			{
				Dictionary<string, FieldBase> NewFieldsOrder = new Dictionary<string, FieldBase>();
				foreach (string Field in FieldNames)
				{
					NewFieldsOrder.Add(Field, NewFields[Field]);
				}
				NewFields = NewFieldsOrder; 
			}
			
			return NewFields;
		}
		
		/// <summary>
		/// Valida se todos os campos foram preenchidos corretamente
		/// </summary>
		/// <param name="provider">Provider que vai ser usado para inserir o registro na tabela</param>
		public override void Validate(GeneralDataProvider provider)
		{
		}
	}
	
	/// <summary>
	/// Classe de provider usada para acessar a tabela de produtos
	/// </summary>
	public class CRMSSI_VIEW_LISTANEGOCIODataProvider : GeneralDataProvider
	{
		public FieldBase this[string ColumnName]
		{
			get
			{
				return Item[ColumnName];
			}
		}

		public override Dictionary<string, FieldBase> CreateItemFields()
		{
			return CRMSSI_VIEW_LISTANEGOCIOItem.CreateItemFields(true); 
		}
	
		public CRMSSI_VIEW_LISTANEGOCIODataProvider(IGeneralDataProvider BasePage, string TableName, string DataBaseName, string IndexName, string Name) : base(BasePage, TableName, DataBaseName, IndexName, Name, "")
		{
		}

		public override string ProviderFilterExpression()
		{
			return this.GetFilterExpression( CRMSSI_VIEW_LISTANEGOCIOItem.CreateItemFields(false, GetUniqueKeyFields()));
		}

		public override string[] GetUniqueKeyFields()
		{
			return null;
		}			
	}
}

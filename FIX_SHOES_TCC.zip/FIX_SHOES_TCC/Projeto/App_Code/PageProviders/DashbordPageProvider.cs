using System;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Data;
using System.Globalization;
using PROJETO;
using COMPONENTS;
using COMPONENTS.Data;
using COMPONENTS.Security;
using COMPONENTS.Configuration;
using System.IO;
using System.Web;
using System.Web.UI;
using PROJETO.DataProviders;
using PROJETO.DataPages;
using Telerik.Web.UI;


namespace PROJETO.DataProviders
{
	/// <summary>
	/// Classe de provider usada para a tabela auxiliar
	/// </summary>
	public class DashbordPageProvider : GeneralProvider
	{
		public Dashbord_Grid1GridDataProvider Dashbord_Grid1Provider;
		public Dashbord_Grid2GridDataProvider Dashbord_Grid2Provider;
		public CRMSSI_VIEW_GRAFICODataProvider Graph1GraphProvider;

		public DashbordPageProvider(IGeneralDataProvider Provider)
		{
			MainProvider = Provider;
			MainProvider.DataProvider = new CRMSSI_TB_PARAMETRODataProvider(MainProvider, MainProvider.TableName, MainProvider.DatabaseName, "", "Dashbord");
			MainProvider.DataProvider.PageProvider = this;
			Dashbord_Grid1Provider = new Dashbord_Grid1GridDataProvider(this);
			Dashbord_Grid1Provider.SetRelationFields += new GeneralGridProvider.SetRelationFieldsEventHandler(Dashbord_Grid1Provider_SetRelationFields);
			Dashbord_Grid2Provider = new Dashbord_Grid2GridDataProvider(this);
			Dashbord_Grid2Provider.SetRelationFields += new GeneralGridProvider.SetRelationFieldsEventHandler(Dashbord_Grid2Provider_SetRelationFields);
			Graph1GraphProvider = new CRMSSI_VIEW_GRAFICODataProvider(MainProvider,"VIEW_GRAFICO", "CRMSSI", "", "");
			Graph1GraphProvider.PageProvider = this;
		}


		private void Dashbord_Grid1Provider_SetRelationFields(object sender, GeneralDataProviderItem Item)
		{
			try
			{
				if (MainProvider.DataProvider.Item == null)
				{
					MainProvider.DataProvider.Item = MainProvider.LoadItemFromControl(false);
				}
				Dashbord_Grid1Provider.AliasVariables = new Dictionary<string, object>();
			}
			catch (Exception)
			{
			}
		}

		private void Dashbord_Grid2Provider_SetRelationFields(object sender, GeneralDataProviderItem Item)
		{
			try
			{
				if (MainProvider.DataProvider.Item == null)
				{
					MainProvider.DataProvider.Item = MainProvider.LoadItemFromControl(false);
				}
				Dashbord_Grid2Provider.AliasVariables = new Dictionary<string, object>();
			}
			catch (Exception)
			{
			}
		}



		public override GeneralDataProviderItem GetDataProviderItem(GeneralDataProvider Provider)
		{
			if (Provider == MainProvider.DataProvider)
			{ 
				return new CRMSSI_TB_PARAMETROItem(MainProvider.DatabaseName);
			}
			else if (Provider == Graph1GraphProvider)
			{
				return new CRMSSI_VIEW_GRAFICOItem("CRMSSI", "MES", "Status", "Quantidade");
			}
			return null;
		}

		public override void FillAuxiliarTables()
		{
		}

		public override int GetMaxProcessLanc()
		{
			return 1;
		}
		
		public override void GetTableIdentity()
		{
		}

		public override string CreateProcessBeforeInsert(string FieldName)
		{
			return "";
		}

		public override void CreateProcess(int Pos)
		{
			CreateProcess("",true, Pos);
		}

		public void ExecuteSingleProcess(string ProcessName)
        {
            CreateProcess(ProcessName, false);
            List<Process> ProcList = new List<Process>(Process.Values);
            if (ProcList.Count > 0)
                DataProcessEntry.ExecuteProcess(ProcList, MainProvider.DataProvider.Dao);
        }
		
		public void CreateProcess(string ProcessName, bool AllProcess)
		{
			CreateProcess(ProcessName, AllProcess, -1);
		}

		public void CreateProcess(string ProcessName, bool AllProcess, int Pos)
		{
			string RelationField = "";
			object ValueField = "";
			object RawValue = "";
			GeneralDataProviderItem Item;
			Process = new Dictionary<string, Process>();
			Process.Clear();
		}

		public override void CreateReverseProcess(int Pos , string SituationProcess)
		{
			string RelationField = "";
			object ValueField = "";
			object RawValue = "";
			GeneralDataProviderItem Item;
			ReverseProcess = new Dictionary<string, Process>();
			ReverseProcess.Clear();
			var situationP = new Dictionary<string, bool>();
		}



		/// <summary>
		/// Valida se todos os campos foram preenchidos corretamente
		/// </summary>
		/// <param name="provider">Provider que vai ser usado para carregar os itens da p?gina</param>
		public override bool Validate(GeneralDataProviderItem ProviderItem)
		{
			return (ProviderItem.Errors.Count == 0);
		}
		


	}
	/// <summary>
	/// Classe de provider usada para acessar a tabela principal do grid
	/// </summary>
	public class Dashbord_Grid1GridDataProvider : GeneralGridProvider
	{
		public string TipoField;
		public string DescricaoField;
		public string NEG_TITULOField;
		public string TAR_DESCField;
		public string IDField;
		public bool FinalizadoField;
		public DateTime DataField;
		public long NEG_IDField;
		public string CLI_NOMEField;
		public string CLI_FONEField;
		public string CLI_CELULARField;
		public string CLI_EMAILField;
		public string CLI_SKYPEField;

		#region GeneralGridProvider Members

		public override int GetMaxProcessLanc()
		{
			return 1;
		}

		private CRMSSI_VIEW_DB_TAREFADataProvider _DataProvider;
		
		public override GeneralDataProvider DataProvider
		{
			get
			{
				return _DataProvider;
			}
			set
			{
				_DataProvider = value as CRMSSI_VIEW_DB_TAREFADataProvider;
			}
		}

		public DashbordPageProvider ParentPageProvider;
		
		public override string TableName { get { return "VIEW_DB_TAREFA"; } }

		public override string DatabaseName { get { return "CRMSSI"; } }

		public override string FormID { get { return "28718"; } }
		
		public override void SetOldParameters(GeneralDataProviderItem Item)
		{
		}

		/// <summary>
		/// Valida se todos os campos do GRID foram preenchidos corretamente
		/// </summary>
		/// <param name="provider">Provider que vai ser usado para carregar os itens da página</param>
		public override bool Validate(GeneralDataProviderItem ProviderItem)
		{
			return (ProviderItem.Errors.Count == 0);
		}		
		
		#endregion

		public Dashbord_Grid1GridDataProvider(DashbordPageProvider ParentProvider)
		{
			ParentPageProvider = ParentProvider;
			DataProvider = new CRMSSI_VIEW_DB_TAREFADataProvider(this, TableName, DatabaseName, "", "Dashbord_Grid1");
			MainProvider = this;
			MainProvider.DataProvider.PageProvider = this;
		}

		public CRMSSI_VIEW_DB_TAREFAItem GetDataProviderItem()
		{
			return GetDataProviderItem(MainProvider.DataProvider) as CRMSSI_VIEW_DB_TAREFAItem;
		}

		public override GeneralDataProviderItem GetDataProviderItem(GeneralDataProvider Provider)
		{
			if (Provider.Name == "Dashbord_Grid1")
			{
				return new CRMSSI_VIEW_DB_TAREFAItem(DatabaseName);
			}
			return null;
		}

		public override void RefreshParentProvider(GeneralProvider ParentProvider)
		{
		ParentPageProvider = (DashbordPageProvider)ParentProvider;
		}

		public override void InitializeAlias(GeneralDataProviderItem Item)
		{
			if (AliasVariables == null)
			{
				AliasVariables = new Dictionary<string, object>();
			}
			TipoField = Convert.ToString(Item["Tipo"].GetValue(),CultureInfo.CurrentCulture);
			if (AliasVariables.ContainsKey("TipoField"))
			{
				AliasVariables["TipoField"] = TipoField;
			}
			else
			{
				AliasVariables.Add("TipoField" ,TipoField);
			}
			DescricaoField = Convert.ToString(Item["Descricao"].GetValue(),CultureInfo.CurrentCulture);
			if (AliasVariables.ContainsKey("DescricaoField"))
			{
				AliasVariables["DescricaoField"] = DescricaoField;
			}
			else
			{
				AliasVariables.Add("DescricaoField" ,DescricaoField);
			}
			NEG_TITULOField = Convert.ToString(Item["NEG_TITULO"].GetValue(),CultureInfo.CurrentCulture);
			if (AliasVariables.ContainsKey("NEG_TITULOField"))
			{
				AliasVariables["NEG_TITULOField"] = NEG_TITULOField;
			}
			else
			{
				AliasVariables.Add("NEG_TITULOField" ,NEG_TITULOField);
			}
			TAR_DESCField = Convert.ToString(Item["TAR_DESC"].GetValue(),CultureInfo.CurrentCulture);
			if (AliasVariables.ContainsKey("TAR_DESCField"))
			{
				AliasVariables["TAR_DESCField"] = TAR_DESCField;
			}
			else
			{
				AliasVariables.Add("TAR_DESCField" ,TAR_DESCField);
			}
			IDField = Convert.ToString(Item["ID"].GetValue(),CultureInfo.CurrentCulture);
			if (AliasVariables.ContainsKey("IDField"))
			{
				AliasVariables["IDField"] = IDField;
			}
			else
			{
				AliasVariables.Add("IDField" ,IDField);
			}
			FinalizadoField = Convert.ToBoolean(Item["Finalizado"].GetValue(),CultureInfo.CurrentCulture);
			if (AliasVariables.ContainsKey("FinalizadoField"))
			{
				AliasVariables["FinalizadoField"] = FinalizadoField;
			}
			else
			{
				AliasVariables.Add("FinalizadoField" ,FinalizadoField);
			}
			DataField = Convert.ToDateTime(Item["Data"].GetValue(),CultureInfo.CurrentCulture);
			if (AliasVariables.ContainsKey("DataField"))
			{
				AliasVariables["DataField"] = DataField;
			}
			else
			{
				AliasVariables.Add("DataField" ,DataField);
			}
			NEG_IDField = Convert.ToInt64(Item["NEG_ID"].GetValue(),CultureInfo.CurrentCulture);
			if (AliasVariables.ContainsKey("NEG_IDField"))
			{
				AliasVariables["NEG_IDField"] = NEG_IDField;
			}
			else
			{
				AliasVariables.Add("NEG_IDField" ,NEG_IDField);
			}
			CLI_NOMEField = Convert.ToString(Item["CLI_NOME"].GetValue(),CultureInfo.CurrentCulture);
			if (AliasVariables.ContainsKey("CLI_NOMEField"))
			{
				AliasVariables["CLI_NOMEField"] = CLI_NOMEField;
			}
			else
			{
				AliasVariables.Add("CLI_NOMEField" ,CLI_NOMEField);
			}
			CLI_FONEField = Convert.ToString(Item["CLI_FONE"].GetValue(),CultureInfo.CurrentCulture);
			if (AliasVariables.ContainsKey("CLI_FONEField"))
			{
				AliasVariables["CLI_FONEField"] = CLI_FONEField;
			}
			else
			{
				AliasVariables.Add("CLI_FONEField" ,CLI_FONEField);
			}
			CLI_CELULARField = Convert.ToString(Item["CLI_CELULAR"].GetValue(),CultureInfo.CurrentCulture);
			if (AliasVariables.ContainsKey("CLI_CELULARField"))
			{
				AliasVariables["CLI_CELULARField"] = CLI_CELULARField;
			}
			else
			{
				AliasVariables.Add("CLI_CELULARField" ,CLI_CELULARField);
			}
			CLI_EMAILField = Convert.ToString(Item["CLI_EMAIL"].GetValue(),CultureInfo.CurrentCulture);
			if (AliasVariables.ContainsKey("CLI_EMAILField"))
			{
				AliasVariables["CLI_EMAILField"] = CLI_EMAILField;
			}
			else
			{
				AliasVariables.Add("CLI_EMAILField" ,CLI_EMAILField);
			}
			CLI_SKYPEField = Convert.ToString(Item["CLI_SKYPE"].GetValue(),CultureInfo.CurrentCulture);
			if (AliasVariables.ContainsKey("CLI_SKYPEField"))
			{
				AliasVariables["CLI_SKYPEField"] = CLI_SKYPEField;
			}
			else
			{
				AliasVariables.Add("CLI_SKYPEField" ,CLI_SKYPEField);
			}
			FillAuxiliarTables();
		}
		
		
		public override void GetTableIdentity()
		{
		}

		public override string CreateProcessBeforeInsert(string FieldName)
		{
			return "";
		}

		public override void CreateProcess(int Pos)
		{
			CreateProcess("",true, Pos);
		}

		public void CreateProcess(string ProcessName, bool AllProcess)
		{
			CreateProcess(ProcessName, AllProcess, -1);
		}

		public void CreateProcess(string ProcessName, bool AllProcess, int Pos)
		{
			string RelationField = "";
			object ValueField = "";
			object RawValue = "";
			GeneralDataProviderItem Item;
			Process = new Dictionary<string, Process>();
			Process.Clear();
			InitializeAlias(MainProvider.DataProvider.Item);
		}

		public override void CreateReverseProcess(int Pos, string SituationProcess)
		{
			CreateReverseProcess("", true, Pos, SituationProcess);
		}

		public void CreateReverseProcess(string ProcessName, bool AllProcess, int Pos, string SituationProcess)
		{
			string RelationField = "";
			object ValueField = "";
			object RawValue = "";
			GeneralDataProviderItem Item;
			ReverseProcess = new Dictionary<string, Process>();
			ReverseProcess.Clear();
			var situationP = new Dictionary<string, bool>();
		}


}
	/// <summary>
	/// Classe de provider usada para acessar a tabela principal do grid
	/// </summary>
	public class Dashbord_Grid2GridDataProvider : GeneralGridProvider
	{
		public string NEG_TITULOField;
		public long NEG_IDField;
		public long CLI_IDField;
		public string NEG_RESPONSAVELField;
		public double NEG_VALORTOTALField;
		public double NEG_VALORULTField;
		public DateTime NEG_DATAINICIALField;
		public DateTime NEG_DATACONCLUSAOField;
		public string NEG_DESCRICAOField;
		public string NEG_STATUSField;
		public string NEG_MOTIVOPERDAField;
		public long FASE_IDField;
		public long FASE_PARField;
		public string NEG_COMENTARIO_PERDAField;
		public long PROD_IDField;
		public string NEG_CORPOPROPField;

		#region GeneralGridProvider Members

		public override int GetMaxProcessLanc()
		{
			return 1;
		}

		private CRMSSI_TB_NEGOCIODataProvider _DataProvider;
		
		public override GeneralDataProvider DataProvider
		{
			get
			{
				return _DataProvider;
			}
			set
			{
				_DataProvider = value as CRMSSI_TB_NEGOCIODataProvider;
			}
		}

		public DashbordPageProvider ParentPageProvider;
		
		public override string TableName { get { return "TB_NEGOCIO"; } }

		public override string DatabaseName { get { return "CRMSSI"; } }

		public override string FormID { get { return "28718"; } }
		
		public override void SetOldParameters(GeneralDataProviderItem Item)
		{
		}

		/// <summary>
		/// Valida se todos os campos do GRID foram preenchidos corretamente
		/// </summary>
		/// <param name="provider">Provider que vai ser usado para carregar os itens da página</param>
		public override bool Validate(GeneralDataProviderItem ProviderItem)
		{
			return (ProviderItem.Errors.Count == 0);
		}		
		
		#endregion

		public Dashbord_Grid2GridDataProvider(DashbordPageProvider ParentProvider)
		{
			ParentPageProvider = ParentProvider;
			DataProvider = new CRMSSI_TB_NEGOCIODataProvider(this, TableName, DatabaseName, "PK_TB_NEGOCIO", "Dashbord_Grid2");
			MainProvider = this;
			MainProvider.DataProvider.PageProvider = this;
		}

		public CRMSSI_TB_NEGOCIOItem GetDataProviderItem()
		{
			return GetDataProviderItem(MainProvider.DataProvider) as CRMSSI_TB_NEGOCIOItem;
		}

		public override GeneralDataProviderItem GetDataProviderItem(GeneralDataProvider Provider)
		{
			if (Provider.Name == "Dashbord_Grid2")
			{
				return new CRMSSI_TB_NEGOCIOItem(DatabaseName);
			}
			return null;
		}

		public override void RefreshParentProvider(GeneralProvider ParentProvider)
		{
		ParentPageProvider = (DashbordPageProvider)ParentProvider;
		}

		public override void InitializeAlias(GeneralDataProviderItem Item)
		{
			if (AliasVariables == null)
			{
				AliasVariables = new Dictionary<string, object>();
			}
			NEG_TITULOField = Convert.ToString(Item["NEG_TITULO"].GetValue(),CultureInfo.CurrentCulture);
			if (AliasVariables.ContainsKey("NEG_TITULOField"))
			{
				AliasVariables["NEG_TITULOField"] = NEG_TITULOField;
			}
			else
			{
				AliasVariables.Add("NEG_TITULOField" ,NEG_TITULOField);
			}
			NEG_IDField = Convert.ToInt64(Item["NEG_ID"].GetValue(),CultureInfo.CurrentCulture);
			if (AliasVariables.ContainsKey("NEG_IDField"))
			{
				AliasVariables["NEG_IDField"] = NEG_IDField;
			}
			else
			{
				AliasVariables.Add("NEG_IDField" ,NEG_IDField);
			}
			CLI_IDField = Convert.ToInt64(Item["CLI_ID"].GetValue(),CultureInfo.CurrentCulture);
			if (AliasVariables.ContainsKey("CLI_IDField"))
			{
				AliasVariables["CLI_IDField"] = CLI_IDField;
			}
			else
			{
				AliasVariables.Add("CLI_IDField" ,CLI_IDField);
			}
			NEG_RESPONSAVELField = Convert.ToString(Item["NEG_RESPONSAVEL"].GetValue(),CultureInfo.CurrentCulture);
			if (AliasVariables.ContainsKey("NEG_RESPONSAVELField"))
			{
				AliasVariables["NEG_RESPONSAVELField"] = NEG_RESPONSAVELField;
			}
			else
			{
				AliasVariables.Add("NEG_RESPONSAVELField" ,NEG_RESPONSAVELField);
			}
			try{NEG_VALORTOTALField = Convert.ToDouble(Item["NEG_VALORTOTAL"].GetValue().ToString().Replace(".", ",") ,CultureInfo.CurrentCulture);}catch (Exception){}
			if (AliasVariables.ContainsKey("NEG_VALORTOTALField"))
			{
				AliasVariables["NEG_VALORTOTALField"] = NEG_VALORTOTALField;
			}
			else
			{
				AliasVariables.Add("NEG_VALORTOTALField" ,NEG_VALORTOTALField);
			}
			try{NEG_VALORULTField = Convert.ToDouble(Item["NEG_VALORULT"].GetValue().ToString().Replace(".", ",") ,CultureInfo.CurrentCulture);}catch (Exception){}
			if (AliasVariables.ContainsKey("NEG_VALORULTField"))
			{
				AliasVariables["NEG_VALORULTField"] = NEG_VALORULTField;
			}
			else
			{
				AliasVariables.Add("NEG_VALORULTField" ,NEG_VALORULTField);
			}
			NEG_DATAINICIALField = Convert.ToDateTime(Item["NEG_DATAINICIAL"].GetValue(),CultureInfo.CurrentCulture);
			if (AliasVariables.ContainsKey("NEG_DATAINICIALField"))
			{
				AliasVariables["NEG_DATAINICIALField"] = NEG_DATAINICIALField;
			}
			else
			{
				AliasVariables.Add("NEG_DATAINICIALField" ,NEG_DATAINICIALField);
			}
			NEG_DATACONCLUSAOField = Convert.ToDateTime(Item["NEG_DATACONCLUSAO"].GetValue(),CultureInfo.CurrentCulture);
			if (AliasVariables.ContainsKey("NEG_DATACONCLUSAOField"))
			{
				AliasVariables["NEG_DATACONCLUSAOField"] = NEG_DATACONCLUSAOField;
			}
			else
			{
				AliasVariables.Add("NEG_DATACONCLUSAOField" ,NEG_DATACONCLUSAOField);
			}
			NEG_DESCRICAOField = Convert.ToString(Item["NEG_DESCRICAO"].GetValue(),CultureInfo.CurrentCulture);
			if (AliasVariables.ContainsKey("NEG_DESCRICAOField"))
			{
				AliasVariables["NEG_DESCRICAOField"] = NEG_DESCRICAOField;
			}
			else
			{
				AliasVariables.Add("NEG_DESCRICAOField" ,NEG_DESCRICAOField);
			}
			NEG_STATUSField = Convert.ToString(Item["NEG_STATUS"].GetValue(),CultureInfo.CurrentCulture);
			if (AliasVariables.ContainsKey("NEG_STATUSField"))
			{
				AliasVariables["NEG_STATUSField"] = NEG_STATUSField;
			}
			else
			{
				AliasVariables.Add("NEG_STATUSField" ,NEG_STATUSField);
			}
			NEG_MOTIVOPERDAField = Convert.ToString(Item["NEG_MOTIVOPERDA"].GetValue(),CultureInfo.CurrentCulture);
			if (AliasVariables.ContainsKey("NEG_MOTIVOPERDAField"))
			{
				AliasVariables["NEG_MOTIVOPERDAField"] = NEG_MOTIVOPERDAField;
			}
			else
			{
				AliasVariables.Add("NEG_MOTIVOPERDAField" ,NEG_MOTIVOPERDAField);
			}
			FASE_IDField = Convert.ToInt64(Item["FASE_ID"].GetValue(),CultureInfo.CurrentCulture);
			if (AliasVariables.ContainsKey("FASE_IDField"))
			{
				AliasVariables["FASE_IDField"] = FASE_IDField;
			}
			else
			{
				AliasVariables.Add("FASE_IDField" ,FASE_IDField);
			}
			FASE_PARField = Convert.ToInt64(Item["FASE_PAR"].GetValue(),CultureInfo.CurrentCulture);
			if (AliasVariables.ContainsKey("FASE_PARField"))
			{
				AliasVariables["FASE_PARField"] = FASE_PARField;
			}
			else
			{
				AliasVariables.Add("FASE_PARField" ,FASE_PARField);
			}
			NEG_COMENTARIO_PERDAField = Convert.ToString(Item["NEG_COMENTARIO_PERDA"].GetValue(),CultureInfo.CurrentCulture);
			if (AliasVariables.ContainsKey("NEG_COMENTARIO_PERDAField"))
			{
				AliasVariables["NEG_COMENTARIO_PERDAField"] = NEG_COMENTARIO_PERDAField;
			}
			else
			{
				AliasVariables.Add("NEG_COMENTARIO_PERDAField" ,NEG_COMENTARIO_PERDAField);
			}
			PROD_IDField = Convert.ToInt64(Item["PROD_ID"].GetValue(),CultureInfo.CurrentCulture);
			if (AliasVariables.ContainsKey("PROD_IDField"))
			{
				AliasVariables["PROD_IDField"] = PROD_IDField;
			}
			else
			{
				AliasVariables.Add("PROD_IDField" ,PROD_IDField);
			}
			NEG_CORPOPROPField = Convert.ToString(Item["NEG_CORPOPROP"].GetValue(),CultureInfo.CurrentCulture);
			if (AliasVariables.ContainsKey("NEG_CORPOPROPField"))
			{
				AliasVariables["NEG_CORPOPROPField"] = NEG_CORPOPROPField;
			}
			else
			{
				AliasVariables.Add("NEG_CORPOPROPField" ,NEG_CORPOPROPField);
			}
			FillAuxiliarTables();
		}
		
		
		public override void GetTableIdentity()
		{
			MainProvider.DataProvider.FindRecord("PK_TB_NEGOCIO", false,new string[] { MainProvider.DataProvider.Dao.GetIdentity(MainProvider.TableName , "NEG_ID") });
		}

		public override string CreateProcessBeforeInsert(string FieldName)
		{
			return "";
		}

		public override void CreateProcess(int Pos)
		{
			CreateProcess("",true, Pos);
		}

		public void CreateProcess(string ProcessName, bool AllProcess)
		{
			CreateProcess(ProcessName, AllProcess, -1);
		}

		public void CreateProcess(string ProcessName, bool AllProcess, int Pos)
		{
			string RelationField = "";
			object ValueField = "";
			object RawValue = "";
			GeneralDataProviderItem Item;
			Process = new Dictionary<string, Process>();
			Process.Clear();
			InitializeAlias(MainProvider.DataProvider.Item);
		}

		public override void CreateReverseProcess(int Pos, string SituationProcess)
		{
			CreateReverseProcess("", true, Pos, SituationProcess);
		}

		public void CreateReverseProcess(string ProcessName, bool AllProcess, int Pos, string SituationProcess)
		{
			string RelationField = "";
			object ValueField = "";
			object RawValue = "";
			GeneralDataProviderItem Item;
			ReverseProcess = new Dictionary<string, Process>();
			ReverseProcess.Clear();
			var situationP = new Dictionary<string, bool>();
		}


}

}

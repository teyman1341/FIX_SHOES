using System;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Data;
using System.Globalization;
using PROJETO;
using COMPONENTS;
using COMPONENTS.Data;
using COMPONENTS.Security;
using COMPONENTS.Configuration;
using System.IO;
using System.Web;
using System.Web.UI;
using PROJETO.DataProviders;
using PROJETO.DataPages;
using Telerik.Web.UI;


namespace PROJETO.DataProviders
{
	/// <summary>
	/// Classe de provider usada para a tabela auxiliar
	/// </summary>
	public class Lista___TarefasPageProvider : GeneralProvider
	{
		public VIEW_DB_TAREFADataListDataProvider DataList1DataListProvider;

		public Lista___TarefasPageProvider(IGeneralDataProvider Provider)
		{
			MainProvider = Provider;
			MainProvider.DataProvider = new CRMSSI_TB_PARAMETRODataProvider(MainProvider, MainProvider.TableName, MainProvider.DatabaseName, "", "Lista___Tarefas");
			MainProvider.DataProvider.PageProvider = this;
			DataList1DataListProvider = new VIEW_DB_TAREFADataListDataProvider(this);
		}

		public override GeneralDataProviderItem GetDataProviderItem(GeneralDataProvider Provider)
		{
			if (Provider == MainProvider.DataProvider)
			{ 
				return new CRMSSI_TB_PARAMETROItem(MainProvider.DatabaseName);
			}
			return null;
		}

		public override void FillAuxiliarTables()
		{
		}

		public override int GetMaxProcessLanc()
		{
			return 1;
		}
		
		public override void GetTableIdentity()
		{
		}

		public override string CreateProcessBeforeInsert(string FieldName)
		{
			return "";
		}

		public override void CreateProcess(int Pos)
		{
			CreateProcess("",true, Pos);
		}

		public void ExecuteSingleProcess(string ProcessName)
        {
            CreateProcess(ProcessName, false);
            List<Process> ProcList = new List<Process>(Process.Values);
            if (ProcList.Count > 0)
                DataProcessEntry.ExecuteProcess(ProcList, MainProvider.DataProvider.Dao);
        }
		
		public void CreateProcess(string ProcessName, bool AllProcess)
		{
			CreateProcess(ProcessName, AllProcess, -1);
		}

		public void CreateProcess(string ProcessName, bool AllProcess, int Pos)
		{
			string RelationField = "";
			object ValueField = "";
			object RawValue = "";
			GeneralDataProviderItem Item;
			Process = new Dictionary<string, Process>();
			Process.Clear();
		}

		public override void CreateReverseProcess(int Pos , string SituationProcess)
		{
			string RelationField = "";
			object ValueField = "";
			object RawValue = "";
			GeneralDataProviderItem Item;
			ReverseProcess = new Dictionary<string, Process>();
			ReverseProcess.Clear();
			var situationP = new Dictionary<string, bool>();
		}



		/// <summary>
		/// Valida se todos os campos foram preenchidos corretamente
		/// </summary>
		/// <param name="provider">Provider que vai ser usado para carregar os itens da p?gina</param>
		public override bool Validate(GeneralDataProviderItem ProviderItem)
		{
			return (ProviderItem.Errors.Count == 0);
		}
		


	/// <summary>
	/// Classe de provider usada para acessar a tabela principal do DataList
	/// </summary>
	public class VIEW_DB_TAREFADataListDataProvider : GeneralListControlProvider
	{
		public string TipoField;
		public string NEG_TITULOField;
		public string DescricaoField;
		public string TAR_DESCField;
		public string IDField;
		public bool FinalizadoField;
		public DateTime DataField;
		public long NEG_IDField;
		public string CLI_NOMEField;
		public string CLI_FONEField;
		public string CLI_CELULARField;
		public string CLI_EMAILField;
		public string CLI_SKYPEField;

		#region GeneralDataListProvider Members

		private CRMSSI_VIEW_DB_TAREFADataProvider _DataProvider;
		
		public override GeneralDataProvider DataProvider
		{
			get
			{
				return _DataProvider;
			}
			set
			{
				_DataProvider = value as CRMSSI_VIEW_DB_TAREFADataProvider;
			}
		}

		public Lista___TarefasPageProvider ParentPageProvider;
		
		public override string TableName { get { return "VIEW_DB_TAREFA"; } }

		public override string DatabaseName { get { return "CRMSSI"; } }

		public override string FormID { get { return "28690"; } }
		
		/// <summary>
		/// Valida se todos os campos do DataList foram preenchidos corretamente
		/// </summary>
		/// <param name="provider">Provider que vai ser usado para carregar os itens da página</param>
		public override bool Validate(GeneralDataProviderItem ProviderItem)
		{
			return (ProviderItem.Errors.Count == 0);
		}		
		
		#endregion

		public VIEW_DB_TAREFADataListDataProvider(Lista___TarefasPageProvider ParentProvider)
		{
			ParentPageProvider = ParentProvider;
			DataProvider = new CRMSSI_VIEW_DB_TAREFADataProvider(this, TableName, DatabaseName, "", "VIEW_DB_TAREFA");
			MainProvider = this;
			MainProvider.DataProvider.PageProvider = this;
		}

		public CRMSSI_VIEW_DB_TAREFAItem GetDataProviderItem()
		{
			return GetDataProviderItem(MainProvider.DataProvider) as CRMSSI_VIEW_DB_TAREFAItem;
		}

		public override GeneralDataProviderItem GetDataProviderItem(GeneralDataProvider Provider)
		{
			if (Provider.Name == "VIEW_DB_TAREFA")
			{
				return new CRMSSI_VIEW_DB_TAREFAItem(DatabaseName);
			}
			return null;
		}
		
		public override void SetParametersValues(GeneralDataProvider Provider)
        {
            try
            {
            }
            catch
            {
            }
        }

		public override void InitializeAlias(GeneralDataProviderItem Item)
        {
		    if (AliasVariables == null)
            {
                AliasVariables = new Dictionary<string, object>();
            }

			TipoField = Convert.ToString(Item["Tipo"].GetValue(),CultureInfo.CurrentCulture);
			if (AliasVariables.ContainsKey("TipoField"))
			{
				AliasVariables["TipoField"] = TipoField;
			}
			else
			{
				AliasVariables.Add("TipoField" ,TipoField);
			}
			NEG_TITULOField = Convert.ToString(Item["NEG_TITULO"].GetValue(),CultureInfo.CurrentCulture);
			if (AliasVariables.ContainsKey("NEG_TITULOField"))
			{
				AliasVariables["NEG_TITULOField"] = NEG_TITULOField;
			}
			else
			{
				AliasVariables.Add("NEG_TITULOField" ,NEG_TITULOField);
			}
			DescricaoField = Convert.ToString(Item["Descricao"].GetValue(),CultureInfo.CurrentCulture);
			if (AliasVariables.ContainsKey("DescricaoField"))
			{
				AliasVariables["DescricaoField"] = DescricaoField;
			}
			else
			{
				AliasVariables.Add("DescricaoField" ,DescricaoField);
			}
			TAR_DESCField = Convert.ToString(Item["TAR_DESC"].GetValue(),CultureInfo.CurrentCulture);
			if (AliasVariables.ContainsKey("TAR_DESCField"))
			{
				AliasVariables["TAR_DESCField"] = TAR_DESCField;
			}
			else
			{
				AliasVariables.Add("TAR_DESCField" ,TAR_DESCField);
			}
			IDField = Convert.ToString(Item["ID"].GetValue(),CultureInfo.CurrentCulture);
			if (AliasVariables.ContainsKey("IDField"))
			{
				AliasVariables["IDField"] = IDField;
			}
			else
			{
				AliasVariables.Add("IDField" ,IDField);
			}
			FinalizadoField = Convert.ToBoolean(Item["Finalizado"].GetValue(),CultureInfo.CurrentCulture);
			if (AliasVariables.ContainsKey("FinalizadoField"))
			{
				AliasVariables["FinalizadoField"] = FinalizadoField;
			}
			else
			{
				AliasVariables.Add("FinalizadoField" ,FinalizadoField);
			}
			DataField = Convert.ToDateTime(Item["Data"].GetValue(),CultureInfo.CurrentCulture);
			if (AliasVariables.ContainsKey("DataField"))
			{
				AliasVariables["DataField"] = DataField;
			}
			else
			{
				AliasVariables.Add("DataField" ,DataField);
			}
			NEG_IDField = Convert.ToInt64(Item["NEG_ID"].GetValue(),CultureInfo.CurrentCulture);
			if (AliasVariables.ContainsKey("NEG_IDField"))
			{
				AliasVariables["NEG_IDField"] = NEG_IDField;
			}
			else
			{
				AliasVariables.Add("NEG_IDField" ,NEG_IDField);
			}
			CLI_NOMEField = Convert.ToString(Item["CLI_NOME"].GetValue(),CultureInfo.CurrentCulture);
			if (AliasVariables.ContainsKey("CLI_NOMEField"))
			{
				AliasVariables["CLI_NOMEField"] = CLI_NOMEField;
			}
			else
			{
				AliasVariables.Add("CLI_NOMEField" ,CLI_NOMEField);
			}
			CLI_FONEField = Convert.ToString(Item["CLI_FONE"].GetValue(),CultureInfo.CurrentCulture);
			if (AliasVariables.ContainsKey("CLI_FONEField"))
			{
				AliasVariables["CLI_FONEField"] = CLI_FONEField;
			}
			else
			{
				AliasVariables.Add("CLI_FONEField" ,CLI_FONEField);
			}
			CLI_CELULARField = Convert.ToString(Item["CLI_CELULAR"].GetValue(),CultureInfo.CurrentCulture);
			if (AliasVariables.ContainsKey("CLI_CELULARField"))
			{
				AliasVariables["CLI_CELULARField"] = CLI_CELULARField;
			}
			else
			{
				AliasVariables.Add("CLI_CELULARField" ,CLI_CELULARField);
			}
			CLI_EMAILField = Convert.ToString(Item["CLI_EMAIL"].GetValue(),CultureInfo.CurrentCulture);
			if (AliasVariables.ContainsKey("CLI_EMAILField"))
			{
				AliasVariables["CLI_EMAILField"] = CLI_EMAILField;
			}
			else
			{
				AliasVariables.Add("CLI_EMAILField" ,CLI_EMAILField);
			}
			CLI_SKYPEField = Convert.ToString(Item["CLI_SKYPE"].GetValue(),CultureInfo.CurrentCulture);
			if (AliasVariables.ContainsKey("CLI_SKYPEField"))
			{
				AliasVariables["CLI_SKYPEField"] = CLI_SKYPEField;
			}
			else
			{
				AliasVariables.Add("CLI_SKYPEField" ,CLI_SKYPEField);
			}
		}
		
		public override void GetTableIdentity()
		{
		}


}
	}

}

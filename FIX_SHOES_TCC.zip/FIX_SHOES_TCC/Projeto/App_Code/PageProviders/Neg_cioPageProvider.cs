using System;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Data;
using System.Globalization;
using PROJETO;
using COMPONENTS;
using COMPONENTS.Data;
using COMPONENTS.Security;
using COMPONENTS.Configuration;
using System.IO;
using System.Web;
using System.Web.UI;
using PROJETO.DataProviders;
using PROJETO.DataPages;
using Telerik.Web.UI;


namespace PROJETO.DataProviders
{
	/// <summary>
	/// Classe de provider usada para a tabela auxiliar
	/// </summary>
	public class Neg_cioPageProvider : GeneralProvider
	{
		public Neg_cio_Grid1GridDataProvider Neg_cio_Grid1Provider;
		public CRMSSI_TB_FASEDataProvider PAR_FASE1Provider;
		public CRMSSI_TB_FASEDataProvider PAR_FASE2Provider;
		public CRMSSI_TB_FASEDataProvider PAR_FASE3Provider;
		public CRMSSI_TB_FASEDataProvider PAR_FASE4Provider;
		public CRMSSI_TB_FASEDataProvider PAR_FASE5Provider;
		public CRMSSI_TB_CLIENTEDataProvider AUX_Neg_cio_TB_CLIENTEProvider;
		public List<RadComboBoxDataItem> ComboBox4Items
		{
			get
			{
				return new List<RadComboBoxDataItem>()
				{
					new RadComboBoxDataItem(HttpContext.GetLocalResourceObject(((Page)MainProvider).AppRelativeVirtualPath, "GComboBoxItem1").ToString(), "Preço"),
					new RadComboBoxDataItem(HttpContext.GetLocalResourceObject(((Page)MainProvider).AppRelativeVirtualPath, "GComboBoxItem2").ToString(), "Prazo"),
					new RadComboBoxDataItem(HttpContext.GetLocalResourceObject(((Page)MainProvider).AppRelativeVirtualPath, "GComboBoxItem3").ToString(), "Produto/Serviço"),
					new RadComboBoxDataItem(HttpContext.GetLocalResourceObject(((Page)MainProvider).AppRelativeVirtualPath, "GComboBoxItem4").ToString(), "Desistência"),
				};
			}
		}

		public Neg_cioPageProvider(IGeneralDataProvider Provider)
		{
			MainProvider = Provider;
			MainProvider.DataProvider = new CRMSSI_TB_NEGOCIODataProvider(MainProvider, MainProvider.TableName, MainProvider.DatabaseName, "PK_TB_NEGOCIO", "Neg_cio");
			MainProvider.DataProvider.PageProvider = this;
			PAR_FASE1Provider = new CRMSSI_TB_FASEDataProvider(MainProvider, "TB_FASE", "CRMSSI", "PK_FASE", "PAR_FASE1");
			PAR_FASE2Provider = new CRMSSI_TB_FASEDataProvider(MainProvider, "TB_FASE", "CRMSSI", "PK_FASE", "PAR_FASE2");
			PAR_FASE3Provider = new CRMSSI_TB_FASEDataProvider(MainProvider, "TB_FASE", "CRMSSI", "PK_FASE", "PAR_FASE3");
			PAR_FASE4Provider = new CRMSSI_TB_FASEDataProvider(MainProvider, "TB_FASE", "CRMSSI", "PK_FASE", "PAR_FASE4");
			PAR_FASE5Provider = new CRMSSI_TB_FASEDataProvider(MainProvider, "TB_FASE", "CRMSSI", "PK_FASE", "PAR_FASE5");
			AUX_Neg_cio_TB_CLIENTEProvider = new CRMSSI_TB_CLIENTEDataProvider(MainProvider, "TB_CLIENTE", "CRMSSI", "PK_TB_CLIENTE", "AUX_Neg_cio_TB_CLIENTE");
			Neg_cio_Grid1Provider = new Neg_cio_Grid1GridDataProvider(this);
			Neg_cio_Grid1Provider.SetRelationFields += new GeneralGridProvider.SetRelationFieldsEventHandler(Neg_cio_Grid1Provider_SetRelationFields);
		}


		private void Neg_cio_Grid1Provider_SetRelationFields(object sender, GeneralDataProviderItem Item)
		{
			try
			{
				if (MainProvider.DataProvider.Item == null)
				{
					MainProvider.DataProvider.Item = MainProvider.LoadItemFromControl(false);
				}
				Neg_cio_Grid1Provider.AliasVariables = new Dictionary<string, object>();
				Neg_cio_Grid1Provider.AliasVariables.Add("NEG_COMENTARIO_PERDAField", MainProvider.DataProvider.Item["NEG_COMENTARIO_PERDA"].Value);
				Neg_cio_Grid1Provider.AliasVariables.Add("NEG_TITULOField", MainProvider.DataProvider.Item["NEG_TITULO"].Value);
				Neg_cio_Grid1Provider.AliasVariables.Add("NEG_VALORTOTALField", MainProvider.DataProvider.Item["NEG_VALORTOTAL"].Value);
				Neg_cio_Grid1Provider.AliasVariables.Add("NEG_VALORULTField", MainProvider.DataProvider.Item["NEG_VALORULT"].Value);
				Neg_cio_Grid1Provider.AliasVariables.Add("NEG_MOTIVOPERDAField", MainProvider.DataProvider.Item["NEG_MOTIVOPERDA"].Value);
				Neg_cio_Grid1Provider.AliasVariables.Add("CLI_IDField", MainProvider.DataProvider.Item["CLI_ID"].Value);
				Neg_cio_Grid1Provider.AliasVariables.Add("NEG_RESPONSAVELField", MainProvider.DataProvider.Item["NEG_RESPONSAVEL"].Value);
				Neg_cio_Grid1Provider.AliasVariables.Add("PROD_IDField", MainProvider.DataProvider.Item["PROD_ID"].Value);
				Neg_cio_Grid1Provider.AliasVariables.Add("NEG_DATAINICIALField", MainProvider.DataProvider.Item["NEG_DATAINICIAL"].Value);
				Neg_cio_Grid1Provider.AliasVariables.Add("NEG_DATACONCLUSAOField", MainProvider.DataProvider.Item["NEG_DATACONCLUSAO"].Value);
			}
			catch (Exception)
			{
			}
		}



		public override GeneralDataProviderItem GetDataProviderItem(GeneralDataProvider Provider)
		{
			if (Provider == MainProvider.DataProvider)
			{ 
				return new CRMSSI_TB_NEGOCIOItem(MainProvider.DatabaseName);
			}
			else if (Provider.Name == "PAR_FASE1")
			{
				return new CRMSSI_TB_FASEItem("CRMSSI");
			}
			else if (Provider.Name == "PAR_FASE2")
			{
				return new CRMSSI_TB_FASEItem("CRMSSI");
			}
			else if (Provider.Name == "PAR_FASE3")
			{
				return new CRMSSI_TB_FASEItem("CRMSSI");
			}
			else if (Provider.Name == "PAR_FASE4")
			{
				return new CRMSSI_TB_FASEItem("CRMSSI");
			}
			else if (Provider.Name == "PAR_FASE5")
			{
				return new CRMSSI_TB_FASEItem("CRMSSI");
			}
			else if (Provider.Name == "AUX_Neg_cio_TB_CLIENTE")
			{
				return new CRMSSI_TB_CLIENTEItem("CRMSSI");
			}
			return null;
		}

		public override void FillAuxiliarTables()
		{
			MainProvider.SetParametersValues(PAR_FASE1Provider);
			PAR_FASE1Provider.Dao = MainProvider.DataProvider.Dao;
			PAR_FASE1Provider.SelectItem(1, FormPositioningEnum.First,true);
			MainProvider.SetParametersValues(PAR_FASE2Provider);
			PAR_FASE2Provider.Dao = MainProvider.DataProvider.Dao;
			PAR_FASE2Provider.SelectItem(1, FormPositioningEnum.First,true);
			MainProvider.SetParametersValues(PAR_FASE3Provider);
			PAR_FASE3Provider.Dao = MainProvider.DataProvider.Dao;
			PAR_FASE3Provider.SelectItem(1, FormPositioningEnum.First,true);
			MainProvider.SetParametersValues(PAR_FASE4Provider);
			PAR_FASE4Provider.Dao = MainProvider.DataProvider.Dao;
			PAR_FASE4Provider.SelectItem(1, FormPositioningEnum.First,true);
			MainProvider.SetParametersValues(PAR_FASE5Provider);
			PAR_FASE5Provider.Dao = MainProvider.DataProvider.Dao;
			PAR_FASE5Provider.SelectItem(1, FormPositioningEnum.First,true);
			MainProvider.SetParametersValues(AUX_Neg_cio_TB_CLIENTEProvider);
			AUX_Neg_cio_TB_CLIENTEProvider.Dao = MainProvider.DataProvider.Dao;
			AUX_Neg_cio_TB_CLIENTEProvider.SelectItem(1, FormPositioningEnum.First,true);
		}

		public override int GetMaxProcessLanc()
		{
			return 7;
		}
		
		public override void GetTableIdentity()
		{
			MainProvider.DataProvider.FindRecord("PK_TB_NEGOCIO", false,new string[] { MainProvider.DataProvider.Dao.GetIdentity(MainProvider.TableName , "NEG_ID") });
		}

		public override string CreateProcessBeforeInsert(string FieldName)
		{
			if(FieldName == "FASE_ID")
			{
				if(!(ServerValidation.CheckNotEmpty(AliasVariables["FASE_IDField"])))
				{
					return MainProvider.DataProvider.Dao.ToSql(new LongField("",EnvironmentVariable.CRMSSI.TB_PARAMETRO.PAR_FASE1).GetFormattedValue(""),FieldType.Long);
				}
			}
			if(FieldName == "FASE_PAR")
			{
				if(!(ServerValidation.CheckNotEmpty(AliasVariables["FASE_PARField"])))
				{
					return MainProvider.DataProvider.Dao.ToSql(new LongField("","1").GetFormattedValue(""),FieldType.Long);
				}
			}
			if(FieldName == "NEG_STATUS")
			{
				if(!(ServerValidation.CheckNotEmpty(AliasVariables["NEG_STATUSField"])))
				{
					return MainProvider.DataProvider.Dao.ToSql(new TextField("","Em andamento").GetFormattedValue(""),FieldType.Text);
				}
			}
			return "";
		}

		public override void CreateProcess(int Pos)
		{
			CreateProcess("",true, Pos);
		}

		public void ExecuteSingleProcess(string ProcessName)
        {
            CreateProcess(ProcessName, false);
            List<Process> ProcList = new List<Process>(Process.Values);
            if (ProcList.Count > 0)
                DataProcessEntry.ExecuteProcess(ProcList, MainProvider.DataProvider.Dao);
        }
		
		public void CreateProcess(string ProcessName, bool AllProcess)
		{
			CreateProcess(ProcessName, AllProcess, -1);
		}

		public void CreateProcess(string ProcessName, bool AllProcess, int Pos)
		{
			string RelationField = "";
			object ValueField = "";
			object RawValue = "";
			GeneralDataProviderItem Item;
			Process = new Dictionary<string, Process>();
			Process.Clear();
		}

		public override void CreateReverseProcess(int Pos , string SituationProcess)
		{
			string RelationField = "";
			object ValueField = "";
			object RawValue = "";
			GeneralDataProviderItem Item;
			ReverseProcess = new Dictionary<string, Process>();
			ReverseProcess.Clear();
			var situationP = new Dictionary<string, bool>();
		}
		
		public DataRow ComboBox4_GetComboItem(string Value)
		{
			try
			{
				return ComboBox4Items.Find(i => i.Value == Value).ToDataRow();
			}
			catch
			{
				return null;
			}
		}
		
		public bool FillComboBox4(RadComboBox ComboBox, int NumberOfItems, string TextFilter, bool AllowFilter)
		{
			if (AllowFilter && !String.IsNullOrEmpty(TextFilter))
			{
				return Utility.FillComboBoxItems(ComboBox, 15, ComboBox4Items.FindAll(c => c.Text.ToLower().Contains(TextFilter.ToLower())));
			}
			return Utility.FillComboBoxItems(ComboBox, 15, ComboBox4Items);
		}
		
		public DataRow ComboBox1_GetComboItem(string Value)
		{
			try
			{
				DataAccessObject Dao = Settings.GetDataAccessObject(((Databases)HttpContext.Current.Application["Databases"])["CRMSSI"]);
				DataRow dr = Dao.RunSql(String.Format("SELECT TOP 1 " +  Dao.PoeColAspas("CLI_NOME") +  " as DISPLAY_FIELD, " + Dao.PoeColAspas("CLI_ID") + " FROM " + Dao.PoeColAspas("TB_CLIENTE") + " WHERE " + Dao.PoeColAspas("CLI_ID") + " = '{0}'", Value)).Tables[0].Rows[0];
				Dao.CloseConnection();
				Dao.Dispose();
				return dr;
			}
			catch
			{
				return null;
			}
		}
		
		public bool FillComboBox1(RadComboBox ComboBox, int NumberOfItems, string TextFilter, bool AllowFilter)
		{
			DataAccessObject Dao = Settings.GetDataAccessObject(((Databases)HttpContext.Current.Application["Databases"])["CRMSSI"]);
			string DisplayFields =  Dao.PoeColAspas("CLI_NOME");
			return Utility.FillComboBox(ComboBox, NumberOfItems, TextFilter, AllowFilter, 15, "TB_CLIENTE", DisplayFields, "CLI_ID", Dao, false, "", GComboBoxOnDemandStyle.Contains,  "");
		}
		
		public DataRow ComboBox2_GetComboItem(string Value)
		{
			try
			{
				DataAccessObject Dao = Settings.GetDataAccessObject(((Databases)HttpContext.Current.Application["Databases"])["CRMSSI"]);
				DataRow dr = Dao.RunSql(String.Format("SELECT TOP 1 " +  Dao.PoeColAspas("LOGIN_USER_LOGIN") +  " as DISPLAY_FIELD, " + Dao.PoeColAspas("LOGIN_USER_LOGIN") + " FROM " + Dao.PoeColAspas("TB_LOGIN_USER") + " WHERE " + Dao.PoeColAspas("LOGIN_USER_LOGIN") + " = '{0}'", Value)).Tables[0].Rows[0];
				Dao.CloseConnection();
				Dao.Dispose();
				return dr;
			}
			catch
			{
				return null;
			}
		}
		
		public bool FillComboBox2(RadComboBox ComboBox, int NumberOfItems, string TextFilter, bool AllowFilter)
		{
			DataAccessObject Dao = Settings.GetDataAccessObject(((Databases)HttpContext.Current.Application["Databases"])["CRMSSI"]);
			string DisplayFields =  Dao.PoeColAspas("LOGIN_USER_LOGIN");
			return Utility.FillComboBox(ComboBox, NumberOfItems, TextFilter, AllowFilter, 15, "TB_LOGIN_USER", DisplayFields, "LOGIN_USER_LOGIN", Dao, true, "", GComboBoxOnDemandStyle.Contains,  Dao.PoeColAspas("LOGIN_USER_LOGIN") + " Asc");
		}
		
		public DataRow ComboBox5_GetComboItem(string Value)
		{
			try
			{
				DataAccessObject Dao = Settings.GetDataAccessObject(((Databases)HttpContext.Current.Application["Databases"])["CRMSSI"]);
				DataRow dr = Dao.RunSql(String.Format("SELECT TOP 1 " +  Dao.PoeColAspas("PROD_NOME") +  " as DISPLAY_FIELD, " + Dao.PoeColAspas("PROD_ID") + " FROM " + Dao.PoeColAspas("TB_PRODUTO") + " WHERE " + Dao.PoeColAspas("PROD_ID") + " = '{0}'", Value)).Tables[0].Rows[0];
				Dao.CloseConnection();
				Dao.Dispose();
				return dr;
			}
			catch
			{
				return null;
			}
		}
		
		public bool FillComboBox5(RadComboBox ComboBox, int NumberOfItems, string TextFilter, bool AllowFilter)
		{
			DataAccessObject Dao = Settings.GetDataAccessObject(((Databases)HttpContext.Current.Application["Databases"])["CRMSSI"]);
			string DisplayFields =  Dao.PoeColAspas("PROD_NOME");
			return Utility.FillComboBox(ComboBox, NumberOfItems, TextFilter, AllowFilter, 15, "TB_PRODUTO", DisplayFields, "PROD_ID", Dao, false, "", GComboBoxOnDemandStyle.Contains,  Dao.PoeColAspas("PROD_NOME") + " Asc");
		}



		/// <summary>
		/// Valida se todos os campos foram preenchidos corretamente
		/// </summary>
		/// <param name="provider">Provider que vai ser usado para carregar os itens da p?gina</param>
		public override bool Validate(GeneralDataProviderItem ProviderItem)
		{
			bool Accepted = false;
			try
			{
				Accepted =(ServerValidation.CheckNotEmpty(AliasVariables["NEG_TITULOField"]));
			}
			catch (Exception)
			{
				Accepted = false;
			}
			if (!Accepted) { ProviderItem.Errors.Add("ServerValidationError", "NEG_TITULO não pode ser vazio!");}
			try
			{
				Accepted =(ServerValidation.CheckNotEmpty(AliasVariables["NEG_RESPONSAVELField"]));
			}
			catch (Exception)
			{
				Accepted = false;
			}
			if (!Accepted) { ProviderItem.Errors.Add("ServerValidationError", "NEG_RESPONSAVEL não pode ser vazio!");}
			try
			{
				Accepted =(ServerValidation.CheckNotEmpty(AliasVariables["CLI_IDField"]));
			}
			catch (Exception)
			{
				Accepted = false;
			}
			if (!Accepted) { ProviderItem.Errors.Add("ServerValidationError", "CLI_ID não pode ser vazio!");}
			try
			{
				Accepted =(ServerValidation.CheckNotEmpty(AliasVariables["NEG_DATAINICIALField"]));
			}
			catch (Exception)
			{
				Accepted = false;
			}
			if (!Accepted) { ProviderItem.Errors.Add("ServerValidationError", "NEG_DATAINICIAL não pode ser vazio!");}
			return (ProviderItem.Errors.Count == 0);
		}
		


	}
	/// <summary>
	/// Classe de provider usada para acessar a tabela principal do grid
	/// </summary>
	public class Neg_cio_Grid1GridDataProvider : GeneralGridProvider
	{
		public string TipoField;
		public DateTime DataField;
		public string DescricaoField;
		public string NEG_TITULOField;
		public string TAR_DESCField;
		public string IDField;
		public bool FinalizadoField;
		public long NEG_IDField;
		public string CLI_NOMEField;
		public string CLI_FONEField;
		public string CLI_CELULARField;
		public string CLI_EMAILField;
		public string CLI_SKYPEField;

		#region GeneralGridProvider Members

		public override int GetMaxProcessLanc()
		{
			return 7;
		}

		private CRMSSI_VIEW_DB_TAREFADataProvider _DataProvider;
		
		public override GeneralDataProvider DataProvider
		{
			get
			{
				return _DataProvider;
			}
			set
			{
				_DataProvider = value as CRMSSI_VIEW_DB_TAREFADataProvider;
			}
		}

		public Neg_cioPageProvider ParentPageProvider;

		public CRMSSI_TB_FASEDataProvider PAR_FASE1Provider;
		public CRMSSI_TB_FASEDataProvider PAR_FASE2Provider;
		public CRMSSI_TB_FASEDataProvider PAR_FASE3Provider;
		public CRMSSI_TB_FASEDataProvider PAR_FASE4Provider;
		public CRMSSI_TB_FASEDataProvider PAR_FASE5Provider;
		public CRMSSI_TB_CLIENTEDataProvider AUX_Neg_cio_TB_CLIENTEProvider;
		
		public override string TableName { get { return "VIEW_DB_TAREFA"; } }

		public override string DatabaseName { get { return "CRMSSI"; } }

		public override string FormID { get { return "28712"; } }
		
		public override void SetOldParameters(GeneralDataProviderItem Item)
		{
		}

		/// <summary>
		/// Valida se todos os campos do GRID foram preenchidos corretamente
		/// </summary>
		/// <param name="provider">Provider que vai ser usado para carregar os itens da página</param>
		public override bool Validate(GeneralDataProviderItem ProviderItem)
		{
			return (ProviderItem.Errors.Count == 0);
		}		
		
		#endregion

		public Neg_cio_Grid1GridDataProvider(Neg_cioPageProvider ParentProvider)
		{
			ParentPageProvider = ParentProvider;
			DataProvider = new CRMSSI_VIEW_DB_TAREFADataProvider(this, TableName, DatabaseName, "", "Neg_cio_Grid1");
			MainProvider = this;
			MainProvider.DataProvider.PageProvider = this;
			PAR_FASE1Provider = new CRMSSI_TB_FASEDataProvider(MainProvider, "TB_FASE", "CRMSSI", "PK_FASE", "TB_FASE");
			PAR_FASE1Provider.Dao = MainProvider.DataProvider.Dao;
			PAR_FASE2Provider = new CRMSSI_TB_FASEDataProvider(MainProvider, "TB_FASE", "CRMSSI", "PK_FASE", "TB_FASE");
			PAR_FASE2Provider.Dao = MainProvider.DataProvider.Dao;
			PAR_FASE3Provider = new CRMSSI_TB_FASEDataProvider(MainProvider, "TB_FASE", "CRMSSI", "PK_FASE", "TB_FASE");
			PAR_FASE3Provider.Dao = MainProvider.DataProvider.Dao;
			PAR_FASE4Provider = new CRMSSI_TB_FASEDataProvider(MainProvider, "TB_FASE", "CRMSSI", "PK_FASE", "TB_FASE");
			PAR_FASE4Provider.Dao = MainProvider.DataProvider.Dao;
			PAR_FASE5Provider = new CRMSSI_TB_FASEDataProvider(MainProvider, "TB_FASE", "CRMSSI", "PK_FASE", "TB_FASE");
			PAR_FASE5Provider.Dao = MainProvider.DataProvider.Dao;
			AUX_Neg_cio_TB_CLIENTEProvider = new CRMSSI_TB_CLIENTEDataProvider(MainProvider, "TB_CLIENTE", "CRMSSI", "PK_TB_CLIENTE", "TB_CLIENTE");
			AUX_Neg_cio_TB_CLIENTEProvider.Dao = MainProvider.DataProvider.Dao;
		}

		public CRMSSI_VIEW_DB_TAREFAItem GetDataProviderItem()
		{
			return GetDataProviderItem(MainProvider.DataProvider) as CRMSSI_VIEW_DB_TAREFAItem;
		}

		public override GeneralDataProviderItem GetDataProviderItem(GeneralDataProvider Provider)
		{
			if (Provider.Name == "Neg_cio_Grid1")
			{
				return new CRMSSI_VIEW_DB_TAREFAItem(DatabaseName);
			}
			else if (Provider is CRMSSI_TB_FASEDataProvider)
			{
				return new CRMSSI_TB_FASEItem("CRMSSI");
			}
			else if (Provider is CRMSSI_TB_FASEDataProvider)
			{
				return new CRMSSI_TB_FASEItem("CRMSSI");
			}
			else if (Provider is CRMSSI_TB_FASEDataProvider)
			{
				return new CRMSSI_TB_FASEItem("CRMSSI");
			}
			else if (Provider is CRMSSI_TB_FASEDataProvider)
			{
				return new CRMSSI_TB_FASEItem("CRMSSI");
			}
			else if (Provider is CRMSSI_TB_FASEDataProvider)
			{
				return new CRMSSI_TB_FASEItem("CRMSSI");
			}
			else if (Provider is CRMSSI_TB_CLIENTEDataProvider)
			{
				return new CRMSSI_TB_CLIENTEItem("CRMSSI");
			}
			return null;
		}

		public override void FillAuxiliarTables()
		{
			MainProvider.SetParametersValues(PAR_FASE1Provider);
			PAR_FASE1Provider.SelectItem(1, FormPositioningEnum.First);
			MainProvider.SetParametersValues(PAR_FASE2Provider);
			PAR_FASE2Provider.SelectItem(1, FormPositioningEnum.First);
			MainProvider.SetParametersValues(PAR_FASE3Provider);
			PAR_FASE3Provider.SelectItem(1, FormPositioningEnum.First);
			MainProvider.SetParametersValues(PAR_FASE4Provider);
			PAR_FASE4Provider.SelectItem(1, FormPositioningEnum.First);
			MainProvider.SetParametersValues(PAR_FASE5Provider);
			PAR_FASE5Provider.SelectItem(1, FormPositioningEnum.First);
			MainProvider.SetParametersValues(AUX_Neg_cio_TB_CLIENTEProvider);
			AUX_Neg_cio_TB_CLIENTEProvider.SelectItem(1, FormPositioningEnum.First);
		}

		public override void RefreshParentProvider(GeneralProvider ParentProvider)
		{
		ParentPageProvider = (Neg_cioPageProvider)ParentProvider;
		}

		public override void InitializeAlias(GeneralDataProviderItem Item)
		{
			if (AliasVariables == null)
			{
				AliasVariables = new Dictionary<string, object>();
			}
			TipoField = Convert.ToString(Item["Tipo"].GetValue(),CultureInfo.CurrentCulture);
			if (AliasVariables.ContainsKey("TipoField"))
			{
				AliasVariables["TipoField"] = TipoField;
			}
			else
			{
				AliasVariables.Add("TipoField" ,TipoField);
			}
			DataField = Convert.ToDateTime(Item["Data"].GetValue(),CultureInfo.CurrentCulture);
			if (AliasVariables.ContainsKey("DataField"))
			{
				AliasVariables["DataField"] = DataField;
			}
			else
			{
				AliasVariables.Add("DataField" ,DataField);
			}
			DescricaoField = Convert.ToString(Item["Descricao"].GetValue(),CultureInfo.CurrentCulture);
			if (AliasVariables.ContainsKey("DescricaoField"))
			{
				AliasVariables["DescricaoField"] = DescricaoField;
			}
			else
			{
				AliasVariables.Add("DescricaoField" ,DescricaoField);
			}
			NEG_TITULOField = Convert.ToString(Item["NEG_TITULO"].GetValue(),CultureInfo.CurrentCulture);
			if (AliasVariables.ContainsKey("NEG_TITULOField"))
			{
				AliasVariables["NEG_TITULOField"] = NEG_TITULOField;
			}
			else
			{
				AliasVariables.Add("NEG_TITULOField" ,NEG_TITULOField);
			}
			TAR_DESCField = Convert.ToString(Item["TAR_DESC"].GetValue(),CultureInfo.CurrentCulture);
			if (AliasVariables.ContainsKey("TAR_DESCField"))
			{
				AliasVariables["TAR_DESCField"] = TAR_DESCField;
			}
			else
			{
				AliasVariables.Add("TAR_DESCField" ,TAR_DESCField);
			}
			IDField = Convert.ToString(Item["ID"].GetValue(),CultureInfo.CurrentCulture);
			if (AliasVariables.ContainsKey("IDField"))
			{
				AliasVariables["IDField"] = IDField;
			}
			else
			{
				AliasVariables.Add("IDField" ,IDField);
			}
			FinalizadoField = Convert.ToBoolean(Item["Finalizado"].GetValue(),CultureInfo.CurrentCulture);
			if (AliasVariables.ContainsKey("FinalizadoField"))
			{
				AliasVariables["FinalizadoField"] = FinalizadoField;
			}
			else
			{
				AliasVariables.Add("FinalizadoField" ,FinalizadoField);
			}
			NEG_IDField = Convert.ToInt64(Item["NEG_ID"].GetValue(),CultureInfo.CurrentCulture);
			if (AliasVariables.ContainsKey("NEG_IDField"))
			{
				AliasVariables["NEG_IDField"] = NEG_IDField;
			}
			else
			{
				AliasVariables.Add("NEG_IDField" ,NEG_IDField);
			}
			CLI_NOMEField = Convert.ToString(Item["CLI_NOME"].GetValue(),CultureInfo.CurrentCulture);
			if (AliasVariables.ContainsKey("CLI_NOMEField"))
			{
				AliasVariables["CLI_NOMEField"] = CLI_NOMEField;
			}
			else
			{
				AliasVariables.Add("CLI_NOMEField" ,CLI_NOMEField);
			}
			CLI_FONEField = Convert.ToString(Item["CLI_FONE"].GetValue(),CultureInfo.CurrentCulture);
			if (AliasVariables.ContainsKey("CLI_FONEField"))
			{
				AliasVariables["CLI_FONEField"] = CLI_FONEField;
			}
			else
			{
				AliasVariables.Add("CLI_FONEField" ,CLI_FONEField);
			}
			CLI_CELULARField = Convert.ToString(Item["CLI_CELULAR"].GetValue(),CultureInfo.CurrentCulture);
			if (AliasVariables.ContainsKey("CLI_CELULARField"))
			{
				AliasVariables["CLI_CELULARField"] = CLI_CELULARField;
			}
			else
			{
				AliasVariables.Add("CLI_CELULARField" ,CLI_CELULARField);
			}
			CLI_EMAILField = Convert.ToString(Item["CLI_EMAIL"].GetValue(),CultureInfo.CurrentCulture);
			if (AliasVariables.ContainsKey("CLI_EMAILField"))
			{
				AliasVariables["CLI_EMAILField"] = CLI_EMAILField;
			}
			else
			{
				AliasVariables.Add("CLI_EMAILField" ,CLI_EMAILField);
			}
			CLI_SKYPEField = Convert.ToString(Item["CLI_SKYPE"].GetValue(),CultureInfo.CurrentCulture);
			if (AliasVariables.ContainsKey("CLI_SKYPEField"))
			{
				AliasVariables["CLI_SKYPEField"] = CLI_SKYPEField;
			}
			else
			{
				AliasVariables.Add("CLI_SKYPEField" ,CLI_SKYPEField);
			}
			FillAuxiliarTables();
		}
		
		
		public override void GetTableIdentity()
		{
		}

		public override string CreateProcessBeforeInsert(string FieldName)
		{
			return "";
		}

		public override void CreateProcess(int Pos)
		{
			CreateProcess("",true, Pos);
		}

		public void CreateProcess(string ProcessName, bool AllProcess)
		{
			CreateProcess(ProcessName, AllProcess, -1);
		}

		public void CreateProcess(string ProcessName, bool AllProcess, int Pos)
		{
			string RelationField = "";
			object ValueField = "";
			object RawValue = "";
			GeneralDataProviderItem Item;
			Process = new Dictionary<string, Process>();
			Process.Clear();
			InitializeAlias(MainProvider.DataProvider.Item);
		}

		public override void CreateReverseProcess(int Pos, string SituationProcess)
		{
			CreateReverseProcess("", true, Pos, SituationProcess);
		}

		public void CreateReverseProcess(string ProcessName, bool AllProcess, int Pos, string SituationProcess)
		{
			string RelationField = "";
			object ValueField = "";
			object RawValue = "";
			GeneralDataProviderItem Item;
			ReverseProcess = new Dictionary<string, Process>();
			ReverseProcess.Clear();
			var situationP = new Dictionary<string, bool>();
		}


}

}

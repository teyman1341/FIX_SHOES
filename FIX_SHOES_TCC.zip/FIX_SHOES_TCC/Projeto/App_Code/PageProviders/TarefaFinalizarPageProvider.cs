using System;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Data;
using System.Globalization;
using PROJETO;
using COMPONENTS;
using COMPONENTS.Data;
using COMPONENTS.Security;
using COMPONENTS.Configuration;
using System.IO;
using System.Web;
using System.Web.UI;
using PROJETO.DataProviders;
using PROJETO.DataPages;

namespace PROJETO.DataProviders
{

	/// <summary>
	/// Classe de provider usada para a tabela auxiliar
	/// </summary>
	public class TarefaFinalizarProcessProvider : GeneralProvider
	{
		public TB_TAREFAProcessProvider TB_TAREFAPreDefProvider;

		public TarefaFinalizarProcessProvider(IGeneralDataProvider Provider)
		{
			MainProvider = Provider;
			TB_TAREFAPreDefProvider = new TB_TAREFAProcessProvider(MainProvider, "TB_TAREFA", "CRMSSI");
		}


		public override GeneralDataProviderItem GetDataProviderItem(GeneralDataProvider Provider)
		{
			return null;
		}

		private DataAccessObject _DaoCRMSSI;
		public DataAccessObject DaoCRMSSI
		{
			get
			{
				if (_DaoCRMSSI == null) _DaoCRMSSI = Settings.GetDataAccessObject(((Databases)HttpContext.Current.Application["Databases"])["CRMSSI"]);
				return _DaoCRMSSI;
			}
			set
			{
				_DaoCRMSSI = value;
			}
		}
		
		public void ExecutePreDefinedProcess()
		{
			bool HasTransaction = false;
			try
			{
				Dictionary<string, DataAccessObject> allDaos = new Dictionary<string, DataAccessObject>();
				DaoCRMSSI.OpenConnection();
				DaoCRMSSI.BeginTrans();
				HasTransaction = true;
				allDaos.Add("CRMSSI", DaoCRMSSI);
				HttpContext.Current.Session["AllDaos"] = allDaos;
				TB_TAREFAPreDefProvider.ExecutePreDefinedProcess(null, AliasVariables, allDaos);
				DaoCRMSSI.CommitTrans();
				HttpContext.Current.Session.Remove("AllDaos");
			}
			catch (Exception ex)
			{
				HttpContext.Current.Session.Remove("AllDaos");
				if (HasTransaction)
				{
				DaoCRMSSI.RollBack();
				}
				throw ex;
			}
		}

		public override void FillAuxiliarTables()
		{
		}
	}
}

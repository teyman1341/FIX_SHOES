using System;
using System.Collections;
using System.ComponentModel;
using System.Web;
using System.IO;
using System.Text;
using System.Web.SessionState;
using System.Resources;
using System.Globalization;
using System.Web.UI.WebControls;
using System.Collections.Specialized;
using System.Text.RegularExpressions;
using COMPONENTS;
using COMPONENTS.Data;
using COMPONENTS.Configuration;
using System.Web.Security;
using System.Configuration;
using System.Web.UI;
using System.Data;
using PROJETO.DataProviders;
using System.Collections.Generic;

namespace PROJETO
{
	public static class EnvironmentVariable
    {

        public static string LoggedIdUser
        {
            get
            {
				try
				{
					return Crypt.Decripta(HttpContext.Current.Session[GMembershipProvider.Default.UserIdSessionVariable].ToString());
				}
				catch
				{
					return "";
				}
            }
        }

        public static string LoggedLoginUser
        {
            get
            {
                try
				{

					return Crypt.Decripta(HttpContext.Current.Session[GMembershipProvider.Default.UserLoginSessionVariable].ToString());
				}
				catch
				{
					return "";
				}
            }
        }

        public static string LoggedNameUser
        {
            get
            {
                try
				{
					return Crypt.Decripta(HttpContext.Current.Session[GMembershipProvider.Default.UserNameSessionVariable].ToString());
				}
				catch
				{
					return "";
				}
            }
        }

        public static string LoggedObsUser
        {
            get
            {
                try
				{
					return Crypt.Decripta(HttpContext.Current.Session[GMembershipProvider.Default.UserObsSessionVariable].ToString());
				}
				catch
				{
					return "";
				}
            }
        }

        public static string LoggedIdGroup
        {
            get
            {
                try
				{
					return Crypt.Decripta(HttpContext.Current.Session[GMembershipProvider.Default.GroupIdSessionVariable].ToString());
				}
				catch
				{
					return "";
				}
            }
        }

        public static string LoggedNameGroup
        {
            get
            {
                try
				{
					return Crypt.Decripta(HttpContext.Current.Session[GMembershipProvider.Default.GroupNameSessionVariable].ToString());
				}
				catch
				{
					return "";
				}
            }
        }
        
        public static string LoggedIsAdminGroup
        {
            get
            {
                try
				{
					return HttpContext.Current.Session[GMembershipProvider.Default.GroupIsAdminSessionVariable].ToString();
				}
				catch
				{
					return "";
				}
            }
        }
        public static string CompanyName
        {
            get
            {
                return ConfigurationManager.AppSettings["CompanyName"];
            }
        }

        public static string DeveloperName
        {
            get
            {
                return ConfigurationManager.AppSettings["DeveloperName"];
            }
        }

        public static string ProjectVersion
        {
            get
            {
                return ConfigurationManager.AppSettings["ProjectVersion"];
            }
        }

        public static string ProjectCopyright
        {
            get
            {
                return ConfigurationManager.AppSettings["ProjectCopyright"];
            }
        }

		public static DateTime ActualDate
        {
            get
            {
                return System.DateTime.Today;
            }
        }

		public static DateTime ActualDateTime
        {
            get
            {
                return System.DateTime.Now;
            }
        }

		public static int ActualDay
		{
			get
			{
				return System.DateTime.Now.Day;
			}
		}

		public static int ActualMonth
		{
			get
			{
				return System.DateTime.Now.Month;
			}
		}

		public static int ActualYear
		{
			get
			{
				return System.DateTime.Now.Year;
			}
		}

		public static string ActualTime
        {
            get
            {
                return System.DateTime.Now.ToLongTimeString();
            }
        }
		
		public static class CRMSSI 
		{
			public static class TB_PARAMETRO 
			{
				public static string PAR_EMPRESA
				{
					get
					{
						DataAccessObject Dao = null;
						if (HttpContext.Current.Session["AllDaos"] != null)
						{
							if ((((Dictionary<string, COMPONENTS.Data.DataAccessObject>)(HttpContext.Current.Session["AllDaos"]))).ContainsKey("CRMSSI"))
							{
								Dao = (((Dictionary<string, COMPONENTS.Data.DataAccessObject>)(HttpContext.Current.Session["AllDaos"])))["CRMSSI"];
							}
						}
						if (Dao == null)  Dao = Settings.GetDataAccessObject(((Databases)HttpContext.Current.Application["Databases"])["CRMSSI"]);
							return Dao.RunSql("SELECT TOP 1  " +  Dao.PoeColAspas("PAR_EMPRESA") + "  FROM " +  Dao.PoeColAspas("TB_PARAMETRO")).Tables[0].Rows[0][0].ToString();
					}
				}
				public static long PAR_FASE1
				{
					get
					{
						DataAccessObject Dao = null;
						if (HttpContext.Current.Session["AllDaos"] != null)
						{
							if ((((Dictionary<string, COMPONENTS.Data.DataAccessObject>)(HttpContext.Current.Session["AllDaos"]))).ContainsKey("CRMSSI"))
							{
								Dao = (((Dictionary<string, COMPONENTS.Data.DataAccessObject>)(HttpContext.Current.Session["AllDaos"])))["CRMSSI"];
							}
						}
						if (Dao == null)  Dao = Settings.GetDataAccessObject(((Databases)HttpContext.Current.Application["Databases"])["CRMSSI"]);
							return Convert.ToInt64(Dao.RunSql("SELECT TOP 1  " +  Dao.PoeColAspas("PAR_FASE1") + "  FROM " +  Dao.PoeColAspas("TB_PARAMETRO")).Tables[0].Rows[0][0]);
					}
				}
				public static long PAR_FASE2
				{
					get
					{
						DataAccessObject Dao = null;
						if (HttpContext.Current.Session["AllDaos"] != null)
						{
							if ((((Dictionary<string, COMPONENTS.Data.DataAccessObject>)(HttpContext.Current.Session["AllDaos"]))).ContainsKey("CRMSSI"))
							{
								Dao = (((Dictionary<string, COMPONENTS.Data.DataAccessObject>)(HttpContext.Current.Session["AllDaos"])))["CRMSSI"];
							}
						}
						if (Dao == null)  Dao = Settings.GetDataAccessObject(((Databases)HttpContext.Current.Application["Databases"])["CRMSSI"]);
							return Convert.ToInt64(Dao.RunSql("SELECT TOP 1  " +  Dao.PoeColAspas("PAR_FASE2") + "  FROM " +  Dao.PoeColAspas("TB_PARAMETRO")).Tables[0].Rows[0][0]);
					}
				}
				public static long PAR_FASE3
				{
					get
					{
						DataAccessObject Dao = null;
						if (HttpContext.Current.Session["AllDaos"] != null)
						{
							if ((((Dictionary<string, COMPONENTS.Data.DataAccessObject>)(HttpContext.Current.Session["AllDaos"]))).ContainsKey("CRMSSI"))
							{
								Dao = (((Dictionary<string, COMPONENTS.Data.DataAccessObject>)(HttpContext.Current.Session["AllDaos"])))["CRMSSI"];
							}
						}
						if (Dao == null)  Dao = Settings.GetDataAccessObject(((Databases)HttpContext.Current.Application["Databases"])["CRMSSI"]);
							return Convert.ToInt64(Dao.RunSql("SELECT TOP 1  " +  Dao.PoeColAspas("PAR_FASE3") + "  FROM " +  Dao.PoeColAspas("TB_PARAMETRO")).Tables[0].Rows[0][0]);
					}
				}
				public static long PAR_FASE4
				{
					get
					{
						DataAccessObject Dao = null;
						if (HttpContext.Current.Session["AllDaos"] != null)
						{
							if ((((Dictionary<string, COMPONENTS.Data.DataAccessObject>)(HttpContext.Current.Session["AllDaos"]))).ContainsKey("CRMSSI"))
							{
								Dao = (((Dictionary<string, COMPONENTS.Data.DataAccessObject>)(HttpContext.Current.Session["AllDaos"])))["CRMSSI"];
							}
						}
						if (Dao == null)  Dao = Settings.GetDataAccessObject(((Databases)HttpContext.Current.Application["Databases"])["CRMSSI"]);
							return Convert.ToInt64(Dao.RunSql("SELECT TOP 1  " +  Dao.PoeColAspas("PAR_FASE4") + "  FROM " +  Dao.PoeColAspas("TB_PARAMETRO")).Tables[0].Rows[0][0]);
					}
				}
				public static long PAR_FASE5
				{
					get
					{
						DataAccessObject Dao = null;
						if (HttpContext.Current.Session["AllDaos"] != null)
						{
							if ((((Dictionary<string, COMPONENTS.Data.DataAccessObject>)(HttpContext.Current.Session["AllDaos"]))).ContainsKey("CRMSSI"))
							{
								Dao = (((Dictionary<string, COMPONENTS.Data.DataAccessObject>)(HttpContext.Current.Session["AllDaos"])))["CRMSSI"];
							}
						}
						if (Dao == null)  Dao = Settings.GetDataAccessObject(((Databases)HttpContext.Current.Application["Databases"])["CRMSSI"]);
							return Convert.ToInt64(Dao.RunSql("SELECT TOP 1  " +  Dao.PoeColAspas("PAR_FASE5") + "  FROM " +  Dao.PoeColAspas("TB_PARAMETRO")).Tables[0].Rows[0][0]);
					}
				}
			}
		}

    }
}

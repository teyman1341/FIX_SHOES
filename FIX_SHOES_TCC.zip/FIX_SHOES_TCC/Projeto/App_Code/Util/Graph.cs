using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using Telerik.Web.UI;
using System.Drawing;

namespace PROJETO
{
	public static class Graph
	{
		public static GraphType GetEnumGraphType(string sType)
		{
			switch (sType)
			{
				case "Bar":
					return GraphType.Bar;
				case "StackedBar":
					return GraphType.StackedBar;
				case "Column":
					return GraphType.Column;
				case "StackedColumn":
					return GraphType.StackedColumn;
				case "Pie":
					return GraphType.Pie;
				case "Line":
					return GraphType.Line;
				case "Donut":
					return GraphType.Donut;
				case "Area":
					return GraphType.Area;
				case "Funnel":
					return GraphType.Funnel;
				default:
					return GraphType.Pie;
			}
		}		
		public enum GraphType
		{
			Bar = 1,
			StackedBar = 2,
			Column = 3,
			StackedColumn = 4,
			Pie = 5,
			Line = 6,
			Donut = 7,
			Area = 8,
			Funnel = 9
		}

		#region SeriesMode FIXED

		public static void SetGraphFixed(RadHtmlChart objGraphControl, GraphType type, string labelTooltipAppearance, DataTable data, string FieldX, bool fieldxIsLegend)
		{
			objGraphControl.PlotArea.Series.Clear();
			objGraphControl.PlotArea.XAxis.Items.Clear();

			//Seta a coluna FieldX para a primeira coluna
			data.Columns[FieldX].SetOrdinal(0);

			switch (type)
			{
				case GraphType.Bar:
					RenderGraphFixed(objGraphControl, new BarSeries(), false, labelTooltipAppearance, data, fieldxIsLegend);										
					break;
				case GraphType.StackedBar:
					RenderGraphFixed(objGraphControl, new BarSeries(), true, labelTooltipAppearance, data, fieldxIsLegend);
					break;
				case GraphType.Column:
					RenderGraphFixed(objGraphControl, new ColumnSeries(), false, labelTooltipAppearance, data, fieldxIsLegend);
					break;
				case GraphType.StackedColumn:
					RenderGraphFixed(objGraphControl, new ColumnSeries(), true, labelTooltipAppearance, data, fieldxIsLegend);
					break;
				case GraphType.Pie:
					RenderPieWithLegend(objGraphControl, labelTooltipAppearance, data);
					break;
				case GraphType.Donut:
					RenderDonutWithLegend(objGraphControl, labelTooltipAppearance, data);
					break;
				case GraphType.Line:
                    RenderGraphFixed(objGraphControl, new LineSeries(), false, labelTooltipAppearance, data, fieldxIsLegend);
                    break;
                case GraphType.Area:
                    RenderGraphFixed(objGraphControl, new AreaSeries(), false, labelTooltipAppearance, data, fieldxIsLegend);
                    break;
                case GraphType.Funnel:
                    RenderFunnelWithLegend(objGraphControl, labelTooltipAppearance, data);
                    break;
				default:
					break;
			}
		}

		public static void RenderGraphFixed(RadHtmlChart objGraphControl, BarSeries series, bool stacked, string labelTooltipAppearance, DataTable data, bool fieldxIsLegend)
		{
			if (fieldxIsLegend)			
				RenderGraphFieldxAsLegend(objGraphControl, series, stacked, labelTooltipAppearance, data);			
			else			
				RenderGraphXYFixed(objGraphControl, series, stacked, labelTooltipAppearance, data);						
		}

        public static void RenderGraphFixed(RadHtmlChart objGraphControl, AreaSeries series, bool stacked, string labelTooltipAppearance, DataTable data, bool fieldxIsLegend)
		{
			if (fieldxIsLegend)			
				RenderGraphFieldxAsLegend(objGraphControl, series, stacked, labelTooltipAppearance, data);			
			else			
				RenderGraphXYFixed(objGraphControl, series, stacked, labelTooltipAppearance, data);						
		}

        public static void RenderGraphFixed(RadHtmlChart objGraphControl, LineSeries series, bool stacked, string labelTooltipAppearance, DataTable data, bool fieldxIsLegend)
		{
			if (fieldxIsLegend)			
				RenderGraphFieldxAsLegend(objGraphControl, series, stacked, labelTooltipAppearance, data);			
			else			
				RenderGraphXYFixed(objGraphControl, series, stacked, labelTooltipAppearance, data);						
		}
		
		private static void RenderGraphFieldxAsLegend(RadHtmlChart objGraphControl, BarSeries series, bool stacked, string labelTooltipAppearance, DataTable data)
		{
			bool axisDataReady = false;

			int contador = 0;

			foreach (System.Data.DataRow row in data.Rows)
			{
				if (series is ColumnSeries) series = new ColumnSeries();
				else if (series is BarSeries) series = new BarSeries();

				//Valores da Legenda
				series.Name = row[0].ToString();
				if (string.IsNullOrEmpty(labelTooltipAppearance))
				{
					series.LabelsAppearance.DataFormatString = "{0}";
					series.TooltipsAppearance.DataFormatString = "{0}";
				}
				else
				{
					series.LabelsAppearance.DataFormatString = labelTooltipAppearance;
					series.TooltipsAppearance.DataFormatString = labelTooltipAppearance;
				}

				series.Name = row[0].ToString();

				for (int i = 1; i < data.Columns.Count; i++)
				{
					//Valores do Gráfico
					series.Items.Add(Convert.ToDecimal(row[data.Columns[i].ColumnName.ToString()]));

					if (!axisDataReady)
					{
						//Valores do eixo X
						AxisItem item = new AxisItem(data.Columns[i].ColumnName.ToString());
						objGraphControl.PlotArea.XAxis.Items.Add(item);
					}
				}
				axisDataReady = true;
				series.Stacked = stacked;

				if (stacked)
					series.LabelsAppearance.Position = Telerik.Web.UI.HtmlChart.BarColumnLabelsPosition.Center;

				series.Appearance.FillStyle.BackgroundColor = StaticColors.GetColor(contador);
				objGraphControl.PlotArea.Series.Add(series);

				//objGraphControl.PlotArea.XAxis.TitleAppearance.Text = "Período";
				//objGraphControl.PlotArea.YAxis.TitleAppearance.Text = "Vendas (R$)";

				contador++;
			}
		}
		
		private static void RenderGraphXYFixed(RadHtmlChart objGraphControl, BarSeries series, bool stacked, string labelTooltipAppearance, DataTable data)
		{
			bool axisDataReady = false;
			int contador = 0;
			for (int i = 1; i < data.Columns.Count; i++)
			{
				if (series is ColumnSeries) series = new ColumnSeries();
				else if (series is BarSeries) series = new BarSeries();

				//Valores da legenda
				series.Name = data.Columns[i].Caption;

				if (string.IsNullOrEmpty(labelTooltipAppearance))
				{
					series.LabelsAppearance.DataFormatString = "{0}";
					series.TooltipsAppearance.DataFormatString = "{0}";
				}
				else
				{
					series.LabelsAppearance.DataFormatString = labelTooltipAppearance;
					series.TooltipsAppearance.DataFormatString = labelTooltipAppearance;
				}

				for (int x = 0; x < data.Rows.Count; x++)
				{
					//valores do Gráfico
					series.Items.Add(Convert.ToDecimal(data.Rows[x][i].ToString()));

					if (!axisDataReady)
					{
						//Itens do eixo X
						for (int j = 0; j < data.Rows.Count; j++)
						{
							AxisItem item = new AxisItem(data.Rows[j][0].ToString());
							objGraphControl.PlotArea.XAxis.Items.Add(item);
						}
					}
					axisDataReady = true;
				}

				series.Stacked = stacked;

				if (stacked)
					series.LabelsAppearance.Position = Telerik.Web.UI.HtmlChart.BarColumnLabelsPosition.Center;

				series.Appearance.FillStyle.BackgroundColor = StaticColors.GetColor(contador);
				objGraphControl.PlotArea.Series.Add(series);		
				contador++;		
			}
		}

		private static void RenderGraphFieldxAsLegend(RadHtmlChart objGraphControl, LineSeries series, bool stacked, string labelTooltipAppearance, DataTable data)
		{
			bool axisDataReady = false;

			int contador = 0;

			foreach (System.Data.DataRow row in data.Rows)
			{

				//Valores da Legenda
				series.Name = row[0].ToString();
				if (string.IsNullOrEmpty(labelTooltipAppearance))
				{
					series.LabelsAppearance.DataFormatString = "{0}";
					series.TooltipsAppearance.DataFormatString = "{0}";
				}
				else
				{
					series.LabelsAppearance.DataFormatString = labelTooltipAppearance;
					series.TooltipsAppearance.DataFormatString = labelTooltipAppearance;
				}

				series.Name = row[0].ToString();

				for (int i = 1; i < data.Columns.Count; i++)
				{
					//Valores do Gráfico
					series.Items.Add(Convert.ToDecimal(row[data.Columns[i].ColumnName.ToString()]));

					if (!axisDataReady)
					{
						//Valores do eixo X
						AxisItem item = new AxisItem(data.Columns[i].ColumnName.ToString());
						objGraphControl.PlotArea.XAxis.Items.Add(item);
					}
				}
				axisDataReady = true;
				series.Stacked = stacked;

				if (stacked)
					series.LabelsAppearance.Position = Telerik.Web.UI.HtmlChart.LineAndScatterLabelsPosition.Above;

				series.Appearance.FillStyle.BackgroundColor = StaticColors.GetColor(contador);
				objGraphControl.PlotArea.Series.Add(series);

				//objGraphControl.PlotArea.XAxis.TitleAppearance.Text = "Período";
				//objGraphControl.PlotArea.YAxis.TitleAppearance.Text = "Vendas (R$)";

				contador++;
			}
		}
		
		private static void RenderGraphFieldxAsLegend(RadHtmlChart objGraphControl, AreaSeries series, bool stacked, string labelTooltipAppearance, DataTable data)
        {
            bool axisDataReady = false;

            int contador = 0;

            foreach (System.Data.DataRow row in data.Rows)
            {

                //Valores da Legenda
                series.Name = row[0].ToString();
                if (string.IsNullOrEmpty(labelTooltipAppearance))
                {
                    series.LabelsAppearance.DataFormatString = "{0}";
                    series.TooltipsAppearance.DataFormatString = "{0}";
                }
                else
                {
                    series.LabelsAppearance.DataFormatString = labelTooltipAppearance;
                    series.TooltipsAppearance.DataFormatString = labelTooltipAppearance;
                }

                series.Name = row[0].ToString();

                for (int i = 1; i < data.Columns.Count; i++)
                {
                    //Valores do GrÃ¡fico
                    series.Items.Add(Convert.ToDecimal(row[data.Columns[i].ColumnName.ToString()]));

                    if (!axisDataReady)
                    {
                        //Valores do eixo X
                        AxisItem item = new AxisItem(data.Columns[i].ColumnName.ToString());
                        objGraphControl.PlotArea.XAxis.Items.Add(item);
                    }
                }
                axisDataReady = true;
                series.Stacked = stacked;

                if (stacked)
                    series.LabelsAppearance.Position = Telerik.Web.UI.HtmlChart.LineAndScatterLabelsPosition.Above;

                series.Appearance.FillStyle.BackgroundColor = StaticColors.GetColor(contador);
                objGraphControl.PlotArea.Series.Add(series);

                //objGraphControl.PlotArea.XAxis.TitleAppearance.Text = "PerÃ­odo";
                //objGraphControl.PlotArea.YAxis.TitleAppearance.Text = "Vendas (R$)";

                contador++;
            }
        }

		private static void RenderGraphXYFixed(RadHtmlChart objGraphControl, LineSeries series, bool stacked, string labelTooltipAppearance, DataTable data)
		{
			bool axisDataReady = false;
			int contador = 0;
			for (int i = 1; i < data.Columns.Count; i++)
			{

				//Valores da legenda
				series.Name = data.Columns[i].Caption;

				if (string.IsNullOrEmpty(labelTooltipAppearance))
				{
					series.LabelsAppearance.DataFormatString = "{0}";
					series.TooltipsAppearance.DataFormatString = "{0}";
				}
				else
				{
					series.LabelsAppearance.DataFormatString = labelTooltipAppearance;
					series.TooltipsAppearance.DataFormatString = labelTooltipAppearance;
				}

				for (int x = 0; x < data.Rows.Count; x++)
				{
					//valores do Gráfico
					series.Items.Add(Convert.ToDecimal(data.Rows[x][i].ToString()));

					if (!axisDataReady)
					{
						//Itens do eixo X
						for (int j = 0; j < data.Rows.Count; j++)
						{
							AxisItem item = new AxisItem(data.Rows[j][0].ToString());
							objGraphControl.PlotArea.XAxis.Items.Add(item);
						}
					}
					axisDataReady = true;
				}

				series.Stacked = stacked;

				if (stacked)
					series.LabelsAppearance.Position = Telerik.Web.UI.HtmlChart.LineAndScatterLabelsPosition.Above;

				series.Appearance.FillStyle.BackgroundColor = StaticColors.GetColor(contador);
				objGraphControl.PlotArea.Series.Add(series);		
				contador++;		
			}
		}

        private static void RenderGraphXYFixed(RadHtmlChart objGraphControl, AreaSeries series, bool stacked, string labelTooltipAppearance, DataTable data)
        {
            bool axisDataReady = false;
            int contador = 0;
            for (int i = 1; i < data.Columns.Count; i++)
            {

                //Valores da legenda
                series.Name = data.Columns[i].Caption;

                if (string.IsNullOrEmpty(labelTooltipAppearance))
                {
                    series.LabelsAppearance.DataFormatString = "{0}";
                    series.TooltipsAppearance.DataFormatString = "{0}";
                }
                else
                {
                    series.LabelsAppearance.DataFormatString = labelTooltipAppearance;
                    series.TooltipsAppearance.DataFormatString = labelTooltipAppearance;
                }

                for (int x = 0; x < data.Rows.Count; x++)
                {
                    //valores do GrÃ¡fico
                    series.Items.Add(Convert.ToDecimal(data.Rows[x][i].ToString()));

                    if (!axisDataReady)
                    {
                        //Itens do eixo X
                        for (int j = 0; j < data.Rows.Count; j++)
                        {
                            AxisItem item = new AxisItem(data.Rows[j][0].ToString());
                            objGraphControl.PlotArea.XAxis.Items.Add(item);
                        }
                    }
                    axisDataReady = true;
                }

                series.Stacked = stacked;

                if (stacked)
                    series.LabelsAppearance.Position = Telerik.Web.UI.HtmlChart.LineAndScatterLabelsPosition.Above;

                series.Appearance.FillStyle.BackgroundColor = StaticColors.GetColor(contador);
                objGraphControl.PlotArea.Series.Add(series);
                contador++;
            }
        }

		private static void RenderPieWithLegend(RadHtmlChart objGraphControl, string labelTooltipAppearance, DataTable data)
		{
			PieSeries pieSeries = new PieSeries();

			if (string.IsNullOrEmpty(labelTooltipAppearance))
			{
				pieSeries.LabelsAppearance.DataFormatString = "{0}";
				pieSeries.TooltipsAppearance.DataFormatString = "{0}";
			}
			else
			{
				pieSeries.LabelsAppearance.DataFormatString = labelTooltipAppearance;
				pieSeries.TooltipsAppearance.DataFormatString = labelTooltipAppearance;
			}

			int contador = 0;
			foreach (System.Data.DataRow row in data.Rows)
			{
				SeriesItem series = new SeriesItem();
				series.Name = row[0].ToString();
				series.YValue = Convert.ToDecimal(row[1].ToString());
				series.BackgroundColor = StaticColors.GetColor(contador);
				pieSeries.Items.Add(series);
				contador++;
			}
			objGraphControl.PlotArea.Series.Add(pieSeries);
		}				

		private static void RenderDonutWithLegend(RadHtmlChart objGraphControl, string labelTooltipAppearance, DataTable data)
		{
			DonutSeries pieSeries = new DonutSeries();

			if (string.IsNullOrEmpty(labelTooltipAppearance))
			{
				pieSeries.LabelsAppearance.DataFormatString = "{0}";
				pieSeries.TooltipsAppearance.DataFormatString = "{0}";
			}
			else
			{
				pieSeries.LabelsAppearance.DataFormatString = labelTooltipAppearance;
				pieSeries.TooltipsAppearance.DataFormatString = labelTooltipAppearance;
			}

			int contador = 0;
			foreach (System.Data.DataRow row in data.Rows)
			{
				SeriesItem series = new SeriesItem();
				series.Name = row[0].ToString();
				series.YValue = Convert.ToDecimal(row[1].ToString());
				series.BackgroundColor = StaticColors.GetColor(contador);
				pieSeries.Items.Add(series);
				contador++;
			}
			objGraphControl.PlotArea.Series.Add(pieSeries);
		}				

        private static void RenderFunnelWithLegend(RadHtmlChart objGraphControl, string labelTooltipAppearance, DataTable data)
        {
            FunnelSeries funnelSeries = new FunnelSeries();

            if (string.IsNullOrEmpty(labelTooltipAppearance))
            {
                funnelSeries.LabelsAppearance.DataFormatString = "{0}";
                funnelSeries.TooltipsAppearance.DataFormatString = "{0}";
            }
            else
            {
                funnelSeries.LabelsAppearance.DataFormatString = labelTooltipAppearance;
                funnelSeries.TooltipsAppearance.DataFormatString = labelTooltipAppearance;
            }

            int contador = 0;
            foreach (System.Data.DataRow row in data.Rows)
            {
                FunnelSeriesItem series = new FunnelSeriesItem();
                series.Name = row[0].ToString();
                series.Y = Convert.ToDecimal(row[1].ToString());
                series.BackgroundColor = StaticColors.GetColor(contador);
                funnelSeries.SeriesItems.Add(series);
                contador++;
            }
            objGraphControl.PlotArea.Series.Add(funnelSeries);
        }
		
		#endregion

		#region SeriesMode DYNAMIC

		public static void SetGraphDynamic(RadHtmlChart objGraphControl, GraphType type, string labelTooltipAppearance, DataTable data, string fieldX, string fieldY, string fieldLegenda)
		{
			objGraphControl.PlotArea.Series.Clear();
			objGraphControl.PlotArea.XAxis.Items.Clear();

			switch (type)
			{
				case GraphType.Bar:
					RenderGraphXY(objGraphControl, new BarSeries(), false, labelTooltipAppearance, data, fieldX, fieldY, fieldLegenda);
					break;
				case GraphType.StackedBar:
					RenderGraphXY(objGraphControl, new BarSeries(), true, labelTooltipAppearance, data, fieldX, fieldY, fieldLegenda);
					break;
				case GraphType.Column:
					RenderGraphXY(objGraphControl, new ColumnSeries(), false, labelTooltipAppearance, data, fieldX, fieldY, fieldLegenda);
					break;
				case GraphType.StackedColumn:
					RenderGraphXY(objGraphControl, new ColumnSeries(), true, labelTooltipAppearance, data, fieldX, fieldY, fieldLegenda);
					break;
				case GraphType.Pie:
					RenderPieWithLegend(objGraphControl, labelTooltipAppearance, data);
					break;
				default:
					break;
			}
		}
		private static void RenderGraphXY(RadHtmlChart objGraphControl, BarSeries series, bool stacked, string labelTooltipAppearance, DataTable data, string fieldX, string fieldY, string fieldLegenda)
		{
			bool axisDataReady = false;

			string dataX = fieldX;
			string dataY = fieldLegenda;
			string dataValue = fieldY;

			DataTable dtDataY = ExtractDistinctData(data, dataY);

			for (int i = 0; i < dtDataY.Rows.Count; i++)
			{
				if (series is ColumnSeries) series = new ColumnSeries();
				else if (series is BarSeries) series = new BarSeries();

				//Valores da legenda
				//series.Name = data.Columns[i].Caption;
				series.Name = dtDataY.Rows[i][dataY].ToString();

				if (string.IsNullOrEmpty(labelTooltipAppearance))
				{
					series.LabelsAppearance.DataFormatString = "{0}";
					series.TooltipsAppearance.DataFormatString = "{0}";
				}
				else
				{
					series.LabelsAppearance.DataFormatString = labelTooltipAppearance;
					series.TooltipsAppearance.DataFormatString = labelTooltipAppearance;
				}

				DataTable dtGraphValues = ExtractValue(data, dataX, dataY, series.Name, dataValue);

				for (int x = 0; x < dtGraphValues.Rows.Count; x++)
				{
					//valores do Gráfico
					series.Items.Add(Convert.ToDecimal(dtGraphValues.Rows[x][dataValue].ToString()));

					if (!axisDataReady)
					{
						DataTable dtDataX = ExtractDistinctData(data, dataX);
						//Itens do eixo X
						for (int j = 0; j < dtDataX.Rows.Count; j++)
						{
							AxisItem item = new AxisItem(dtDataX.Rows[j][dataX].ToString());
							objGraphControl.PlotArea.XAxis.Items.Add(item);
						}
					}
					axisDataReady = true;
				}

				series.Stacked = stacked;

				if (stacked)
					series.LabelsAppearance.Position = Telerik.Web.UI.HtmlChart.BarColumnLabelsPosition.Center;

				series.Appearance.FillStyle.BackgroundColor = StaticColors.GetColor(i);
				objGraphControl.PlotArea.Series.Add(series);
			}
		}				
		static DataTable ExtractDistinctData(DataTable data, string column)
		{
            if (data.Rows.Count > 0)
            {
                var resultProductGroup = from tabela in data.AsEnumerable() group tabela by tabela[column] into g select g.First();
                return resultProductGroup.CopyToDataTable();
            }
            else
            {
                return data;
            }			
		}				
		static DataTable ExtractValue(DataTable data, string columnX, string columnY, string dataColumnSerie, string dataValue)
		{
			DataTable dtTemp = InicializaTableTemp(data, columnX, dataValue);

			//Filtra dados
			DataRow [] result = data.Select(columnY + " = '" + dataColumnSerie + "'");

			foreach (var itemComValor in result)
			{
				foreach (DataRow itemZerado in dtTemp.Rows)
				{
					//se nomes iguais, atualiza o valor
					if (itemComValor[columnX].ToString() == itemZerado[columnX].ToString())
					{
						itemZerado[dataValue] = itemComValor[dataValue];
						break;
					}
				}
			}
			return dtTemp;
		}	
		static DataTable InicializaTableTemp(DataTable data, string campo, string valor)
		{
			//agrupa campo
			var resultProductGroup = from tabela in data.AsEnumerable() //group tabela by tabela.Field<string>(campo) into g
									 group tabela by tabela[campo] into g
									 select g.First();

			DataTable dtDataTemp = new DataTable();
			dtDataTemp = resultProductGroup.CopyToDataTable();
			foreach (DataRow item in dtDataTemp.Rows) { item[valor] = 0; }
			return dtDataTemp;
		}
				
		#endregion		
	}

	public static class StaticColors
	{
		public static Color GetColor(int index)
		{
			return colors[index % colors.Length];
		}

		private static readonly Color[] colors = 
		{
			Color.Orange,
			Color.LimeGreen,
			Color.DeepSkyBlue,
			Color.DarkViolet,
			Color.RosyBrown,			
			Color.Red,
			Color.LightSalmon,
			Color.Aquamarine,			
			Color.Olive,
			Color.MediumSeaGreen,			
			Color.Lime,
			Color.DarkTurquoise,
			Color.Navy,
			Color.Tan,
			Color.Silver,
			Color.Blue,
			Color.Maroon,
			Color.Yellow,
			Color.Pink,
			Color.LightGray,
			Color.Sienna,
			Color.DarkSlateGray,
			Color.DarkKhaki,
			Color.MediumAquamarine,
			Color.LawnGreen,
			Color.LightGoldenrodYellow,
			Color.Gold,
			Color.Indigo,
			Color.CadetBlue,
			Color.SpringGreen,
			Color.Cyan
		};
	}
}


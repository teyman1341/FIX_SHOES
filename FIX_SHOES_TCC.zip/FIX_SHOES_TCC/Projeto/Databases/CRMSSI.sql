﻿/*------------------------------------------------------------*/
/*   Esquema para a criação do banco de dados da aplicação    */
/*                           CRMSSI                           */
/*------------------------------------------------------------*/

/*------------------------------------------------------------*/
/*                     Exclusão de Triggers                   */
/*------------------------------------------------------------*/

IF EXISTS (SELECT * FROM sysobjects WHERE id = object_id('TB_LOGIN_GROUP_RULE') AND sysstat & 0xf = 11)
ALTER TABLE [TB_LOGIN_RULE]
DROP CONSTRAINT [TB_LOGIN_GROUP_RULE]
GO

IF EXISTS (SELECT * FROM sysobjects WHERE id = object_id('TB_LOGIN_GROUP_USER') AND sysstat & 0xf = 11)
ALTER TABLE [TB_LOGIN_USER]
DROP CONSTRAINT [TB_LOGIN_GROUP_USER]
GO

/*------------------------------------------------------------*/
/*                     Exclusão de Views                      */
/*------------------------------------------------------------*/

IF EXISTS (SELECT * FROM sysobjects WHERE id = object_id('VIEW_DB_TAREFA') AND sysstat & 0xf = 2)
DROP VIEW [VIEW_DB_TAREFA]
GO

IF EXISTS (SELECT * FROM sysobjects WHERE id = object_id('VIEW_GRAFICO') AND sysstat & 0xf = 2)
DROP VIEW [VIEW_GRAFICO]
GO

IF EXISTS (SELECT * FROM sysobjects WHERE id = object_id('VIEW_LISTANEGOCIO') AND sysstat & 0xf = 2)
DROP VIEW [VIEW_LISTANEGOCIO]
GO

IF EXISTS (SELECT * FROM sysobjects WHERE id = object_id('VIEW_REL_PEDIDO') AND sysstat & 0xf = 2)
DROP VIEW [VIEW_REL_PEDIDO]
GO

/*------------------------------------------------------------*/
/*                     Exclusão de tabelas                    */
/*------------------------------------------------------------*/

IF EXISTS (SELECT * FROM sysobjects WHERE id = object_id('TB_CATEGORIA') AND sysstat & 0xf = 3)
DROP TABLE [TB_CATEGORIA]
GO

IF EXISTS (SELECT * FROM sysobjects WHERE id = object_id('TB_CLIENTE') AND sysstat & 0xf = 3)
DROP TABLE [TB_CLIENTE]
GO

IF EXISTS (SELECT * FROM sysobjects WHERE id = object_id('TB_DEPARTAMENTO') AND sysstat & 0xf = 3)
DROP TABLE [TB_DEPARTAMENTO]
GO

IF EXISTS (SELECT * FROM sysobjects WHERE id = object_id('TB_FASE') AND sysstat & 0xf = 3)
DROP TABLE [TB_FASE]
GO

IF EXISTS (SELECT * FROM sysobjects WHERE id = object_id('TB_LOGIN_GROUP') AND sysstat & 0xf = 3)
DROP TABLE [TB_LOGIN_GROUP]
GO

IF EXISTS (SELECT * FROM sysobjects WHERE id = object_id('TB_LOGIN_RULE') AND sysstat & 0xf = 3)
DROP TABLE [TB_LOGIN_RULE]
GO

IF EXISTS (SELECT * FROM sysobjects WHERE id = object_id('TB_LOGIN_USER') AND sysstat & 0xf = 3)
DROP TABLE [TB_LOGIN_USER]
GO

IF EXISTS (SELECT * FROM sysobjects WHERE id = object_id('TB_NEGOCIO') AND sysstat & 0xf = 3)
DROP TABLE [TB_NEGOCIO]
GO

IF EXISTS (SELECT * FROM sysobjects WHERE id = object_id('TB_PARAMETRO') AND sysstat & 0xf = 3)
DROP TABLE [TB_PARAMETRO]
GO

IF EXISTS (SELECT * FROM sysobjects WHERE id = object_id('TB_PRODUTO') AND sysstat & 0xf = 3)
DROP TABLE [TB_PRODUTO]
GO

IF EXISTS (SELECT * FROM sysobjects WHERE id = object_id('TB_TAREFA') AND sysstat & 0xf = 3)
DROP TABLE [TB_TAREFA]
GO

/*------------------------------------------------------------*/
/*                     Criação das tabelas                    */
/*------------------------------------------------------------*/

/*------------------------------------------------------------*/
/*    Criação de Tabelas, Indices e Atribuição de Default    */
/*      TB_CATEGORIA      */
/*------------------------------------------------------------*/

 CREATE TABLE [TB_CATEGORIA](
	[CAT_ID]                               bigint               IDENTITY(1,1) NOT NULL,
	[CAT_DESC]                             varchar (200)        NOT NULL
		CONSTRAINT [PK_TB_CATEGORIA] PRIMARY KEY CLUSTERED
		(
			[CAT_ID]
		) WITH FILLFACTOR = 90
)
GO

/*------------------------------------------------------------*/
/*    Criação de Tabelas, Indices e Atribuição de Default    */
/*     TB_CLIENTE     */
/*------------------------------------------------------------*/

 CREATE TABLE [TB_CLIENTE](
	[CLI_ID]                               bigint               IDENTITY(1,1) NOT NULL,
	[CLI_NOME]                             varchar (200)        NOT NULL,
	[CLI_CNPJ]                             varchar (100)        NULL,
	[CLI_FONE]                             varchar (14)         NULL,
	[CLI_CELULAR]                          varchar (15)         NULL,
	[CLI_EMAIL]                            varchar (100)        NULL,
	[CLI_SKYPE]                            varchar (50)         NULL,
	[CLI_OBS]                              text                 NULL,
	[CLI_CONTATO]                          varchar (200)        NULL
		CONSTRAINT [PK_TB_CLIENTE] PRIMARY KEY CLUSTERED
		(
			[CLI_ID]
		) WITH FILLFACTOR = 90
)
GO

/*------------------------------------------------------------*/
/*    Criação de Tabelas, Indices e Atribuição de Default    */
/*       TB_DEPARTAMENTO       */
/*------------------------------------------------------------*/

 CREATE TABLE [TB_DEPARTAMENTO](
	[DEP_ID]                               bigint               IDENTITY(1,1) NOT NULL,
	[DEP_NOME]                             varchar (200)        NOT NULL
		CONSTRAINT [PK_TB_DEPARTAMENTO] PRIMARY KEY CLUSTERED
		(
			[DEP_ID]
		) WITH FILLFACTOR = 90
)
GO

/*------------------------------------------------------------*/
/*    Criação de Tabelas, Indices e Atribuição de Default    */
/*   TB_FASE   */
/*------------------------------------------------------------*/

 CREATE TABLE [TB_FASE](
	[FASE_ID]                              bigint               IDENTITY(1,1) NOT NULL,
	[FASE_NOME]                            varchar (200)        NOT NULL
		CONSTRAINT [PK_FASE] PRIMARY KEY CLUSTERED
		(
			[FASE_ID]
		) WITH FILLFACTOR = 90
)
GO

/*------------------------------------------------------------*/
/*    Criação de Tabelas, Indices e Atribuição de Default    */
/*       TB_LOGIN_GROUP       */
/*------------------------------------------------------------*/

 CREATE TABLE [TB_LOGIN_GROUP](
	[LOGIN_GROUP_NAME]                     varchar (60)         NOT NULL,
	[LOGIN_GROUP_IS_ADMIN]                 bit                  NOT NULL
		CONSTRAINT [LOGIN_GROUP_PK] PRIMARY KEY CLUSTERED
		(
			[LOGIN_GROUP_NAME]
		) WITH FILLFACTOR = 90
)
GO

/*------------------------------------------------------------*/
/*    Criação de Tabelas, Indices e Atribuição de Default    */
/*      TB_LOGIN_RULE      */
/*------------------------------------------------------------*/

 CREATE TABLE [TB_LOGIN_RULE](
	[LOGIN_RULE_PROJECT]                   varchar (8)          NOT NULL,
	[LOGIN_GROUP_NAME]                     varchar (60)         NOT NULL,
	[LOGIN_RULE_OBJECT]                    varchar (100)        NOT NULL,
	[LOGIN_RULE_PERMISSIONS]               varchar (100)        NOT NULL
		CONSTRAINT [LOGIN_RULE_PK] PRIMARY KEY CLUSTERED
		(
			[LOGIN_RULE_PROJECT],[LOGIN_GROUP_NAME],[LOGIN_RULE_OBJECT]
		) WITH FILLFACTOR = 90
)
GO

/*------------------------------------------------------------*/
/*    Criação de Tabelas, Indices e Atribuição de Default    */
/*      TB_LOGIN_USER      */
/*------------------------------------------------------------*/

 CREATE TABLE [TB_LOGIN_USER](
	[LOGIN_GROUP_NAME]                     varchar (60)         NOT NULL,
	[LOGIN_USER_LOGIN]                     varchar (40)         NOT NULL,
	[LOGIN_USER_PASSWORD]                  varchar (40)         NOT NULL,
	[LOGIN_USER_NAME]                      varchar (60)         NULL,
	[LOGIN_USER_OBS]                       text                 NOT NULL,
	[LOGIN_USER_CARGO]                     varchar (150)        NULL,
	[LOGIN_USER_FOTO]                      varchar (10)         NULL
		CONSTRAINT [LOGIN_USER_PK] PRIMARY KEY CLUSTERED
		(
			[LOGIN_USER_LOGIN]
		) WITH FILLFACTOR = 90
)
GO

/*------------------------------------------------------------*/
/*    Criação de Tabelas, Indices e Atribuição de Default    */
/*     TB_NEGOCIO     */
/*------------------------------------------------------------*/

 CREATE TABLE [TB_NEGOCIO](
	[NEG_ID]                               bigint               IDENTITY(1,1) NOT NULL,
	[NEG_TITULO]                           varchar (300)        NOT NULL,
	[CLI_ID]                               bigint               DEFAULT 0 NOT NULL,
	[NEG_RESPONSAVEL]                      varchar (40)         NOT NULL,
	[NEG_VALORTOTAL]                       decimal (10,2)       DEFAULT 0.00 NULL,
	[NEG_VALORULT]                         decimal (10,2)       DEFAULT 0.00 NULL,
	[NEG_DATAINICIAL]                      date                 NOT NULL,
	[NEG_DATACONCLUSAO]                    date                 NULL,
	[NEG_DESCRICAO]                        text                 NULL,
	[NEG_STATUS]                           varchar (100)        DEFAULT '0' NULL,
	[NEG_MOTIVOPERDA]                      varchar (255)        NULL,
	[FASE_ID]                              bigint               NULL,
	[FASE_PAR]                             bigint               DEFAULT 0 NULL,
	[NEG_COMENTARIO_PERDA]                 varchar (500)        NULL,
	[PROD_ID]                              bigint               NULL,
	[NEG_CORPOPROP]                        text                 NULL
		CONSTRAINT [PK_TB_NEGOCIO] PRIMARY KEY CLUSTERED
		(
			[NEG_ID]
		) WITH FILLFACTOR = 90
)
GO

/*------------------------------------------------------------*/
/*    Criação de Tabelas, Indices e Atribuição de Default    */
/*      TB_PARAMETRO      */
/*------------------------------------------------------------*/

 CREATE TABLE [TB_PARAMETRO](
	[PAR_EMPRESA]                          varchar (300)        NULL,
	[PAR_FASE1]                            bigint               DEFAULT 0 NULL,
	[PAR_FASE2]                            bigint               DEFAULT 0 NULL,
	[PAR_FASE3]                            bigint               DEFAULT 0 NULL,
	[PAR_FASE4]                            bigint               DEFAULT 0 NULL,
	[PAR_FASE5]                            bigint               DEFAULT 0 NULL
)
GO

/*------------------------------------------------------------*/
/*    Criação de Tabelas, Indices e Atribuição de Default    */
/*     TB_PRODUTO     */
/*------------------------------------------------------------*/

 CREATE TABLE [TB_PRODUTO](
	[PROD_ID]                              bigint               IDENTITY(1,1) NOT NULL,
	[PROD_NOME]                            varchar (200)        NOT NULL
		CONSTRAINT [PK_TB_PRODUTO] PRIMARY KEY CLUSTERED
		(
			[PROD_ID]
		) WITH FILLFACTOR = 90
)
GO

/*------------------------------------------------------------*/
/*    Criação de Tabelas, Indices e Atribuição de Default    */
/*    TB_TAREFA    */
/*------------------------------------------------------------*/

 CREATE TABLE [TB_TAREFA](
	[TAR_ID]                               bigint               IDENTITY(1,1) NOT NULL,
	[TAR_TIPO]                             varchar (200)        NOT NULL,
	[TAR_DESC]                             varchar (4000)       NULL,
	[NEG_ID]                               bigint               NULL,
	[TAR_RESPONSAVEL]                      varchar (50)         NOT NULL,
	[CLI_ID]                               bigint               DEFAULT 0 NULL,
	[TAR_FINALIZADO]                       bit                  DEFAULT 0 NOT NULL,
	[TAR_DATAHORA]                         datetime             NULL
		CONSTRAINT [PK_TB_TAREFA] PRIMARY KEY CLUSTERED
		(
			[TAR_ID]
		) WITH FILLFACTOR = 90
)
GO

/*------------------------------------------------------------*/
/*                      Criação de VIEW                      */
/*        VIEW_LISTANEGOCIO        */
/*------------------------------------------------------------*/

 CREATE VIEW [VIEW_LISTANEGOCIO]AS(
SELECT NEG_ID,NEG_TITULO,N.CLI_ID,C.CLI_NOME,C.CLI_CONTATO,N.FASE_ID,F.FASE_NOME,N.PROD_ID,P.PROD_NOME,N.NEG_STATUS,N.NEG_VALORTOTAL,NEG_DATAINICIAL,NEG_VALORULT
FROM TB_NEGOCIO AS N
INNER JOIN TB_CLIENTE AS C ON N.CLI_ID = C.CLI_ID
LEFT JOIN TB_FASE AS F ON N.FASE_ID = F.FASE_ID
LEFT JOIN TB_PRODUTO AS P ON N.PROD_ID = P.PROD_ID

)
GO

/*------------------------------------------------------------*/
/*                      Criação de VIEW                      */
/*      VIEW_GRAFICO      */
/*------------------------------------------------------------*/

 CREATE VIEW [VIEW_GRAFICO]AS(
SELECT [Status],[Quantidade],[Mes] from (

 SELECT 'PERDIDO' AS [Status],SUM(TB.QUANTIDADE_P) AS [Quantidade], TB.MES FROM (

 SELECT COUNT(NEG_ID) AS QUANTIDADE_P, 0 AS QUANTIDADE_A, 0 AS QUANTIDADE_C, month(NEG_DATAINICIAL) AS MES  FROM TB_NEGOCIO WHERE NEG_STATUS = 'Perdido' GROUP BY month(NEG_DATAINICIAL)
 union all
 SELECT 0 AS QUANTIDADE_P, COUNT(NEG_ID) AS QUANTIDADE_A, 0 AS QUANTIDADE_C, month(NEG_DATAINICIAL) AS MES  FROM TB_NEGOCIO WHERE NEG_STATUS = 'Em andamento'GROUP BY month(NEG_DATAINICIAL)
 union all
 SELECT 0 AS QUANTIDADE_P, 0 AS QUANTIDADE_A, COUNT(NEG_ID) AS QUANTIDADE_C, month(NEG_DATAINICIAL) AS MES  FROM TB_NEGOCIO WHERE NEG_STATUS = 'Concluído'GROUP BY month(NEG_DATAINICIAL)

 ) AS TB
 GROUP BY MES

 UNION ALL

 SELECT 'EM ANDAMENTO' AS [Status],SUM(TB.QUANTIDADE_A) AS [Quantidade], TB.MES FROM (

 SELECT COUNT(NEG_ID) AS QUANTIDADE_P, 0 AS QUANTIDADE_A, 0 AS QUANTIDADE_C, month(NEG_DATAINICIAL) AS MES  FROM TB_NEGOCIO WHERE NEG_STATUS = 'Perdido' GROUP BY month(NEG_DATAINICIAL)
 union all
 SELECT 0 AS QUANTIDADE_P, COUNT(NEG_ID) AS QUANTIDADE_A, 0 AS QUANTIDADE_C, month(NEG_DATAINICIAL) AS MES  FROM TB_NEGOCIO WHERE NEG_STATUS = 'Em andamento'GROUP BY month(NEG_DATAINICIAL)
 union all
 SELECT 0 AS QUANTIDADE_P, 0 AS QUANTIDADE_A, COUNT(NEG_ID) AS QUANTIDADE_C, month(NEG_DATAINICIAL) AS MES  FROM TB_NEGOCIO WHERE NEG_STATUS = 'Concluído'GROUP BY month(NEG_DATAINICIAL)

 ) AS TB
 GROUP BY MES

 UNION ALL

 SELECT 'CONCLUÍDO' AS [Status], SUM(TB.QUANTIDADE_C)  AS [Quantidade], TB.MES FROM (

 SELECT COUNT(NEG_ID) AS QUANTIDADE_P, 0 AS QUANTIDADE_A, 0 AS QUANTIDADE_C, month(NEG_DATAINICIAL) AS MES  FROM TB_NEGOCIO WHERE NEG_STATUS = 'Perdido' GROUP BY month(NEG_DATAINICIAL)
 union all
 SELECT 0 AS QUANTIDADE_P, COUNT(NEG_ID) AS QUANTIDADE_A, 0 AS QUANTIDADE_C, month(NEG_DATAINICIAL) AS MES  FROM TB_NEGOCIO WHERE NEG_STATUS = 'Em andamento'GROUP BY month(NEG_DATAINICIAL)
 union all
 SELECT 0 AS QUANTIDADE_P, 0 AS QUANTIDADE_A, COUNT(NEG_ID) AS QUANTIDADE_C, month(NEG_DATAINICIAL) AS MES  FROM TB_NEGOCIO WHERE NEG_STATUS = 'Concluído'GROUP BY month(NEG_DATAINICIAL)

 ) AS TB
 GROUP BY MES


) as TB
)
GO

/*------------------------------------------------------------*/
/*                      Criação de VIEW                      */
/*       VIEW_DB_TAREFA       */
/*------------------------------------------------------------*/

 CREATE VIEW [VIEW_DB_TAREFA]AS(
SELECT TAR_ID AS ID,N.neg_titulo,t.NEG_ID, TAR_TIPO AS TIPO,SUBSTRING(TAR_DESC,1,50)+'...' AS DESCRICAO,TAR_DESC,TAR_FINALIZADO AS FINALIZADO, TAR_DATAHORA AS DATA,
C.CLI_NOME,C.CLI_FONE, CLI_CELULAR,CLI_EMAIL,CLI_SKYPE
FROM TB_TAREFA AS T
LEFT JOIN TB_NEGOCIO N ON N.NEG_ID = T.NEG_ID
LEFT JOIN TB_CLIENTE C ON C.CLI_ID = N.CLI_ID
)
GO

/*------------------------------------------------------------*/
/*                      Criação de VIEW                      */
/*       VIEW_REL_PEDIDO       */
/*------------------------------------------------------------*/

 CREATE VIEW [VIEW_REL_PEDIDO]AS(
SELECT NEG_ID,NEG_TITULO, NEG_DATAINICIAL, NEG_VALORULT,
NEG_VALORTOTAL, NEG_DESCRICAO, CLI_NOME, CLI_CNPJ,CLI_FONE, 
CLI_CELULAR , CLI_EMAIL, CLI_SKYPE, CLI_CONTATO, PROD_NOME,
NEG_CORPOPROP,PAR_EMPRESA
FROM TB_NEGOCIO AS N
INNER JOIN TB_CLIENTE AS C ON C.CLI_ID = N.CLI_ID
LEFT JOIN TB_PRODUTO AS P ON P.PROD_ID = N.PROD_ID
CROSS JOIN TB_PARAMETRO
)
GO

ALTER TABLE [TB_LOGIN_RULE] ADD CONSTRAINT [TB_LOGIN_GROUP_RULE]
	FOREIGN KEY
		([LOGIN_GROUP_NAME])
	REFERENCES [TB_LOGIN_GROUP]
		([LOGIN_GROUP_NAME])
	ON DELETE CASCADE
GO

ALTER TABLE [TB_LOGIN_USER] ADD CONSTRAINT [TB_LOGIN_GROUP_USER]
	FOREIGN KEY
		([LOGIN_GROUP_NAME])
	REFERENCES [TB_LOGIN_GROUP]
		([LOGIN_GROUP_NAME])
	ON DELETE CASCADE
GO


using System;
using System.Collections;
using System.Collections.Specialized;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Web;
using System.IO;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.Security;
using System.Text.RegularExpressions;
using System.Globalization;
using System.Configuration;
using System.Linq;
using PROJETO;
using COMPONENTS;
using COMPONENTS.Data;
using COMPONENTS.Configuration;
using COMPONENTS.Security;
using PROJETO.DataProviders;
using PROJETO.DataPages;
using Telerik.Web.UI;

namespace PROJETO.DataPages
{
	public partial class Cadastro_Cliente : GeneralDataPage
	{
		protected Cadastro_ClientePageProvider PageProvider;
	
		public string CLI_NOMEField = "";
		public string CLI_CNPJField = "";
		public string CLI_FONEField = "";
		public string CLI_CELULARField = "";
		public string CLI_EMAILField = "";
		public string CLI_SKYPEField = "";
		public string CLI_OBSField = "";
		public string CLI_CONTATOField = "";
		public long CLI_IDField = 0;
		
		public override string FormID { get { return "28720"; } }
		public override string TableName { get { return "TB_CLIENTE"; } }
		public override string DatabaseName { get { return "CRMSSI"; } }
		public override string PageName { get { return "Cadastro_Cliente.aspx"; } }
		public override string ProjectID { get { return "1DB2E771"; } }
		public override string TableParameters { get { return "false"; } }
		public override bool PageInsert { get { return true;}}
		public override bool CanEdit { get { return true && UpdateValidation(); }}
		public override bool CanInsert  { get { return true && InsertValidation(); } }
		public override bool CanDelete { get { return true && DeleteValidation(); } }
		public override bool CanView { get { return true; } }
		public override bool OpenInEditMode { get { return true; } }
		


		public string Par_IDCliente = "";

		public override void SetStartFilter()
		{
			try
			{
				if (!String.IsNullOrEmpty(Par_IDCliente))
				{
					PageProvider.MainProvider.DataProvider.StartFilter = Dao.PoeColAspas("CLI_ID") + " = " + Dao.ToSql(Par_IDCliente.ToString(), FieldType.Integer);
				}
				else
				{
					PageProvider.MainProvider.DataProvider.StartFilter = "1 = 2";
				}
			}
			catch
			{
				PageProvider.MainProvider.DataProvider.StartFilter = "1 = 2";
			}
		}
		
		public override void CreateProvider()
		{
			PageProvider = new Cadastro_ClientePageProvider(this);
		}
		
		private void InitializePageContent()
		{
		}

		/// <summary>
        /// onInit Vamos Carregar o Painel de Ajax e Label de erros da página
        /// </summary>
		protected override void OnInit(EventArgs e)
		{
			Par_IDCliente = HttpContext.Current.Request.QueryString["Par_IDCliente"];
			try { if (string.IsNullOrEmpty(Par_IDCliente)) Par_IDCliente = HttpContext.Current.Session["Par_IDCliente"].ToString();} catch {} 
			if (string.IsNullOrEmpty(Par_IDCliente)) Par_IDCliente = "0";
			AjaxPanel = MainAjaxPanel;
			if (IsPostBack)
			{
				AjaxPanel.ResponseScripts.Add("setTimeout(\"InitializeClient();\",100);");
			}
			AjaxPanel.ResponseScripts.Add("setTimeout(\"RegisterClientValidateScript();\",100);");
			ErrorLabel = labError;
			if (!PageInsert )
				DisableEnableContros(false);

			base.OnInit(e);
		}
		

		/// <summary>
		/// Carrega os objetos de Item de acordo com os controles
		/// </summary>
		public override void UpdateItemFromControl(GeneralDataProviderItem  Item)
		{
			// só vamos permitir a carga dos itens de acordo com os controles de tela caso esteja ocorrendo
			// um postback pois em caso contrário a página está sendo aberta em modo de inclusão/edição
			// e dessa forma não teve alteração de usuário nos dados do formulário
			if (PageState != FormStateEnum.Navigation && this.IsPostBack)
			{
				Item.SetFieldValue(Item["CLI_NOME"], RadTextBox1.Text, false);
				Item.SetFieldValue(Item["CLI_CNPJ"], RadTextBox2.Text, false);
				Item.SetFieldValue(Item["CLI_FONE"], RadTextBox3.Text, false);
				Item.SetFieldValue(Item["CLI_CELULAR"], RadTextBox4.Text, false);
				Item.SetFieldValue(Item["CLI_EMAIL"], RadTextBox5.Text, false);
				Item.SetFieldValue(Item["CLI_SKYPE"], RadTextBox6.Text, false);
				Item.SetFieldValue(Item["CLI_OBS"], RadTextBox7.Text, false);
				Item.SetFieldValue(Item["CLI_CONTATO"], RadTextBox8.Text, false);
			}
			InitializeAlias(Item);
		}

		/// <summary>
		/// Carrega os objetos de tela para o Item Provider da página
		/// </summary>

		public override GeneralDataProviderItem LoadItemFromControl(bool EnableValidation)
		{
			GeneralDataProviderItem Item = PageProvider.GetDataProviderItem(DataProvider);
			if (PageState != FormStateEnum.Navigation)
			{
				Item.SetFieldValue(Item["CLI_NOME"], RadTextBox1.Text, false);
				Item.SetFieldValue(Item["CLI_CNPJ"], RadTextBox2.Text, false);
				Item.SetFieldValue(Item["CLI_FONE"], RadTextBox3.Text, false);
				Item.SetFieldValue(Item["CLI_CELULAR"], RadTextBox4.Text, false);
				Item.SetFieldValue(Item["CLI_EMAIL"], RadTextBox5.Text, false);
				Item.SetFieldValue(Item["CLI_SKYPE"], RadTextBox6.Text, false);
				Item.SetFieldValue(Item["CLI_OBS"], RadTextBox7.Text, false);
				Item.SetFieldValue(Item["CLI_CONTATO"], RadTextBox8.Text, false);
			}
			else
			{
				Item = PageProvider.MainProvider.DataProvider.SelectItem(PageNumber, FormPositioningEnum.Current);
			}
			if (EnableValidation)
			{
				InitializeAlias(Item);
				if (PageState == FormStateEnum.Insert)
				{
					FillAuxiliarTables();
				}
				PageProvider.Validate(Item); 
			}
			if (Item!=null) PageErrors.Add(Item.Errors);
			return Item;
		}
		

		/// <summary>
		/// Define a Máscara para cada campo na tela
		/// </summary>
		public override void DefineMask()
		{
			Mask.SetMask(RadTextBox3, "(99) 9999-9999", 14, false);
			Mask.SetMask(RadTextBox4, "(99) 99999-9999", 15, false);
		}

		public override void DefineStartScripts()
		{
			Utility.SetControlTabOnEnter(RadTextBox1);
			Utility.SetControlTabOnEnter(RadTextBox2);
			Utility.SetControlTabOnEnter(RadTextBox5);
			Utility.SetControlTabOnEnter(RadTextBox6);
			Utility.SetControlTabOnEnter(RadTextBox7);
			Utility.SetControlTabOnEnter(RadTextBox8);
		}
		
		public override void DisableEnableContros(bool Action)
		{
			RadTextBox1.Attributes.Add("EnableEdit", "True");
			RadTextBox2.Attributes.Add("EnableEdit", "True");
			RadTextBox3.Attributes.Add("EnableEdit", "True");
			RadTextBox4.Attributes.Add("EnableEdit", "True");
			RadTextBox5.Attributes.Add("EnableEdit", "True");
			RadTextBox6.Attributes.Add("EnableEdit", "True");
			RadTextBox7.Attributes.Add("EnableEdit", "True");
			RadTextBox8.Attributes.Add("EnableEdit", "True");
		}

		/// <summary>
		/// Limpa Campos na tela
		/// </summary>
		public override void ClearFields(bool ShouldClearFields)
		{
			if (ShouldClearFields)
			{
				RadTextBox1.Text = "";
				RadTextBox2.Text = "";
				RadTextBox3.Text = "";
				RadTextBox4.Text = "";
				RadTextBox5.Text = "";
				RadTextBox6.Text = "";
				RadTextBox7.Text = "";
				RadTextBox8.Text = "";
			}
			if (!PageInsert && PageState == FormStateEnum.Navigation)
				DisableEnableContros(false);				
			else
				DisableEnableContros(true);				
		}		

		public override void ShowInitialValues()
		{
		}

		public override void PageEdit()
		{
			base.PageEdit(); 
		}

		public override void ShowFormulas()
		{
			Label1.Text = Label1.Text.Replace("<", "&lt;");
			Label1.Text = Label1.Text.Replace(">", "&gt;");
			Label2.Text = Label2.Text.Replace("<", "&lt;");
			Label2.Text = Label2.Text.Replace(">", "&gt;");
			Label3.Text = Label3.Text.Replace("<", "&lt;");
			Label3.Text = Label3.Text.Replace(">", "&gt;");
			Label4.Text = Label4.Text.Replace("<", "&lt;");
			Label4.Text = Label4.Text.Replace(">", "&gt;");
			Label5.Text = Label5.Text.Replace("<", "&lt;");
			Label5.Text = Label5.Text.Replace(">", "&gt;");
			Label6.Text = Label6.Text.Replace("<", "&lt;");
			Label6.Text = Label6.Text.Replace(">", "&gt;");
			Label7.Text = Label7.Text.Replace("<", "&lt;");
			Label7.Text = Label7.Text.Replace(">", "&gt;");
			Label8.Text = Label8.Text.Replace("<", "&lt;");
			Label8.Text = Label8.Text.Replace(">", "&gt;");
			Label9.Text = Label9.Text.Replace("<", "&lt;");
			Label9.Text = Label9.Text.Replace(">", "&gt;");
		}
		
		/// <summary>
		/// Define conteudo dos objetos de Tela
		/// </summary>
		public override void DefinePageContent(GeneralDataProviderItem Item)
		{
			try { RadTextBox1.Text = Item["CLI_NOME"].GetFormattedValue(); }
			catch { RadTextBox1.Text = ""; }
			try { RadTextBox2.Text = Item["CLI_CNPJ"].GetFormattedValue(); }
			catch { RadTextBox2.Text = ""; }
			try { RadTextBox3.Text = Item["CLI_FONE"].GetFormattedValue(); }
			catch { RadTextBox3.Text = ""; }
			try { RadTextBox4.Text = Item["CLI_CELULAR"].GetFormattedValue(); }
			catch { RadTextBox4.Text = ""; }
			try { RadTextBox5.Text = Item["CLI_EMAIL"].GetFormattedValue(); }
			catch { RadTextBox5.Text = ""; }
			try { RadTextBox6.Text = Item["CLI_SKYPE"].GetFormattedValue(); }
			catch { RadTextBox6.Text = ""; }
			try { RadTextBox7.Text = Item["CLI_OBS"].GetFormattedValue(); }
			catch { RadTextBox7.Text = ""; }
			try { RadTextBox8.Text = Item["CLI_CONTATO"].GetFormattedValue(); }
			catch { RadTextBox8.Text = ""; }
			ApplyMasks(RadTextBox1);
			ApplyMasks(RadTextBox2);
			ApplyMasks(RadTextBox3);
			ApplyMasks(RadTextBox4);
			ApplyMasks(RadTextBox5);
			ApplyMasks(RadTextBox6);
			ApplyMasks(RadTextBox7);
			ApplyMasks(RadTextBox8);
			InitializePageContent();
			base.DefinePageContent(Item);
		}
		
		/// <summary>
		/// Define apelidos da Página
		/// </summary>
		public override void InitializeAlias(GeneralDataProviderItem Item)
        {
			PageProvider.AliasVariables = new Dictionary<string, object>();
			PageProvider.AliasVariables.Clear();
			
			try
			{
				CLI_NOMEField = Item["CLI_NOME"].GetFormattedValue();
			}
			catch
			{
				CLI_NOMEField = "";
			}
			try
			{
				CLI_CNPJField = Item["CLI_CNPJ"].GetFormattedValue();
			}
			catch
			{
				CLI_CNPJField = "";
			}
			try
			{
				CLI_FONEField = Item["CLI_FONE"].GetFormattedValue();
			}
			catch
			{
				CLI_FONEField = "";
			}
			try
			{
				CLI_CELULARField = Item["CLI_CELULAR"].GetFormattedValue();
			}
			catch
			{
				CLI_CELULARField = "";
			}
			try
			{
				CLI_EMAILField = Item["CLI_EMAIL"].GetFormattedValue();
			}
			catch
			{
				CLI_EMAILField = "";
			}
			try
			{
				CLI_SKYPEField = Item["CLI_SKYPE"].GetFormattedValue();
			}
			catch
			{
				CLI_SKYPEField = "";
			}
			try
			{
				CLI_OBSField = Item["CLI_OBS"].GetFormattedValue();
			}
			catch
			{
				CLI_OBSField = "";
			}
			try
			{
				CLI_CONTATOField = Item["CLI_CONTATO"].GetFormattedValue();
			}
			catch
			{
				CLI_CONTATOField = "";
			}
			try
			{
				CLI_IDField = long.Parse(Item["CLI_ID"].GetFormattedValue(), CultureInfo.CurrentCulture);
			}
			catch
			{
				CLI_IDField = 0;
			}
			PageProvider.AliasVariables.Add("CLI_NOMEField", CLI_NOMEField);
			PageProvider.AliasVariables.Add("CLI_CNPJField", CLI_CNPJField);
			PageProvider.AliasVariables.Add("CLI_FONEField", CLI_FONEField);
			PageProvider.AliasVariables.Add("CLI_CELULARField", CLI_CELULARField);
			PageProvider.AliasVariables.Add("CLI_EMAILField", CLI_EMAILField);
			PageProvider.AliasVariables.Add("CLI_SKYPEField", CLI_SKYPEField);
			PageProvider.AliasVariables.Add("CLI_OBSField", CLI_OBSField);
			PageProvider.AliasVariables.Add("CLI_CONTATOField", CLI_CONTATOField);
			PageProvider.AliasVariables.Add("CLI_IDField", CLI_IDField);
			PageProvider.AliasVariables.Add("Par_IDCliente", Par_IDCliente);
			PageProvider.AliasVariables.Add("BasePage", this);
        }

		protected void ___Form1_OnSaveSucceeded(GeneralDataProviderItem Item)
		{
			bool ActionSucceeded_1 = true;
			try
			{
				AjaxPanel.ResponseScripts.Add("try {getParentPage().GetRadWindowManager().GetActiveWindow().Caller.Refresh();} catch (e) {}");
			}
			catch (Exception ex)
			{
				ActionSucceeded_1 = false;
				PageErrors.Add("Error", ex.Message);
				ShowErrors();
			}
			bool ActionSucceeded_2 = true;
			try
			{
					AjaxPanel.Alert("Salvo com Sucesso!");
			}
			catch (Exception ex)
			{
				ActionSucceeded_2 = false;
				PageErrors.Add("Error", ex.Message);
				ShowErrors();
			}
		}

		protected void ___Form1_OnRemoveSucceeded(GeneralDataProviderItem Item)
		{
			bool ActionSucceeded_1 = true;
			try
			{
				AjaxPanel.ResponseScripts.Add("try {getParentPage().GetRadWindowManager().GetActiveWindow().Caller.Refresh();} catch (e) {}");
			}
			catch (Exception ex)
			{
				ActionSucceeded_1 = false;
				PageErrors.Add("Error", ex.Message);
				ShowErrors();
			}
			bool ActionSucceeded_2 = true;
			try
			{
					AjaxPanel.Alert("Removido com Sucesso!");
			}
			catch (Exception ex)
			{
				ActionSucceeded_2 = false;
				PageErrors.Add("Error", ex.Message);
				ShowErrors();
			}
		}





		public override void ExecuteServerCommandRequest(string CommandName, string TargetName, string[] Parameters)
		{
			ExecuteLocalCommandRequest(CommandName, TargetName, Parameters);
		}		





		public override void OnRemoveSucceeded(GeneralDataProviderItem Item)
		{
			___Form1_OnRemoveSucceeded(Item);
		}
		public override void SaveSucceeded(GeneralDataProviderItem Item)
		{
			___Form1_OnSaveSucceeded(Item);
		}
	}
}

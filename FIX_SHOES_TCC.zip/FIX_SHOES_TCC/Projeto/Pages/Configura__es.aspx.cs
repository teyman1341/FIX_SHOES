using System;
using System.Collections;
using System.Collections.Specialized;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Web;
using System.IO;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.Security;
using System.Text.RegularExpressions;
using System.Globalization;
using System.Configuration;
using System.Linq;
using PROJETO;
using COMPONENTS;
using COMPONENTS.Data;
using COMPONENTS.Configuration;
using COMPONENTS.Security;
using PROJETO.DataProviders;
using PROJETO.DataPages;
using Telerik.Web.UI;

namespace PROJETO.DataPages
{
	public partial class Configura__es : GeneralDataPage
	{
		protected Configura__esPageProvider PageProvider;
	
		public long PAR_FASE1Field = 0;
		public long PAR_FASE2Field = 0;
		public long PAR_FASE3Field = 0;
		public long PAR_FASE4Field = 0;
		public long PAR_FASE5Field = 0;
		public string PAR_EMPRESAField = "";
		
		public override string FormID { get { return "28710"; } }
		public override string TableName { get { return "TB_PARAMETRO"; } }
		public override string DatabaseName { get { return "CRMSSI"; } }
		public override string PageName { get { return "Configura__es.aspx"; } }
		public override string ProjectID { get { return "1DB2E771"; } }
		public override string TableParameters { get { return "true"; } }
		public override bool PageInsert { get { return false;}}
		public override bool CanEdit { get { return true && UpdateValidation(); }}
		public override bool CanInsert  { get { return false && InsertValidation(); } }
		public override bool CanDelete { get { return true && DeleteValidation(); } }
		public override bool CanView { get { return true; } }
		public override bool OpenInEditMode { get { return false; } }
		



		
		public override void CreateProvider()
		{
			PageProvider = new Configura__esPageProvider(this);
		}
		
		private void InitializePageContent()
		{
		}

		/// <summary>
        /// onInit Vamos Carregar o Painel de Ajax e Label de erros da página
        /// </summary>
		protected override void OnInit(EventArgs e)
		{
			AjaxPanel = MainAjaxPanel;
			if (IsPostBack)
			{
				AjaxPanel.ResponseScripts.Add("setTimeout(\"InitializeClient();\",100);");
			}
			ErrorLabel = labError;
			if (!PageInsert )
				DisableEnableContros(false);

			base.OnInit(e);
		}
		

		/// <summary>
		/// Carrega os objetos de Item de acordo com os controles
		/// </summary>
		public override void UpdateItemFromControl(GeneralDataProviderItem  Item)
		{
			// só vamos permitir a carga dos itens de acordo com os controles de tela caso esteja ocorrendo
			// um postback pois em caso contrário a página está sendo aberta em modo de inclusão/edição
			// e dessa forma não teve alteração de usuário nos dados do formulário
			if (PageState != FormStateEnum.Navigation && this.IsPostBack)
			{
				Item.SetFieldValue(Item["PAR_FASE1"], ComboBox1.SelectedValue);
				Item.SetFieldValue(Item["PAR_FASE2"], ComboBox2.SelectedValue);
				Item.SetFieldValue(Item["PAR_FASE3"], ComboBox3.SelectedValue);
				Item.SetFieldValue(Item["PAR_FASE4"], ComboBox4.SelectedValue);
				Item.SetFieldValue(Item["PAR_FASE5"], ComboBox5.SelectedValue);
				Item.SetFieldValue(Item["PAR_EMPRESA"], RadTextBox1.Text, false);
			}
			InitializeAlias(Item);
		}

		/// <summary>
		/// Carrega os objetos de tela para o Item Provider da página
		/// </summary>

		public override GeneralDataProviderItem LoadItemFromControl(bool EnableValidation)
		{
			GeneralDataProviderItem Item = PageProvider.GetDataProviderItem(DataProvider);
			if (PageState != FormStateEnum.Navigation)
			{
				Item.SetFieldValue(Item["PAR_FASE1"], ComboBox1.SelectedValue);
				Item.SetFieldValue(Item["PAR_FASE2"], ComboBox2.SelectedValue);
				Item.SetFieldValue(Item["PAR_FASE3"], ComboBox3.SelectedValue);
				Item.SetFieldValue(Item["PAR_FASE4"], ComboBox4.SelectedValue);
				Item.SetFieldValue(Item["PAR_FASE5"], ComboBox5.SelectedValue);
				Item.SetFieldValue(Item["PAR_EMPRESA"], RadTextBox1.Text, false);
			}
			else
			{
				Item = PageProvider.MainProvider.DataProvider.SelectItem(PageNumber, FormPositioningEnum.Current);
			}
			if (EnableValidation)
			{
				InitializeAlias(Item);
				if (PageState == FormStateEnum.Insert)
				{
					FillAuxiliarTables();
				}
				PageProvider.Validate(Item); 
			}
			if (Item!=null) PageErrors.Add(Item.Errors);
			return Item;
		}
		

		/// <summary>
		/// Define a Máscara para cada campo na tela
		/// </summary>
		public override void DefineMask()
		{
		}

		public override void DefineStartScripts()
		{
			Utility.SetControlTabOnEnter(ComboBox1);
			Utility.SetControlTabOnEnter(ComboBox2);
			Utility.SetControlTabOnEnter(ComboBox3);
			Utility.SetControlTabOnEnter(ComboBox4);
			Utility.SetControlTabOnEnter(ComboBox5);
			Utility.SetControlTabOnEnter(RadTextBox1);
		}
		
		public override void DisableEnableContros(bool Action)
		{
			ComboBox1.Attributes.Add("EnableEdit", "True");
			ComboBox2.Attributes.Add("EnableEdit", "True");
			ComboBox3.Attributes.Add("EnableEdit", "True");
			ComboBox4.Attributes.Add("EnableEdit", "True");
			ComboBox5.Attributes.Add("EnableEdit", "True");
			RadTextBox1.Attributes.Add("EnableEdit", "True");
		}

		/// <summary>
		/// Limpa Campos na tela
		/// </summary>
		public override void ClearFields(bool ShouldClearFields)
		{
				ComboBox1.SelectedIndex = -1;
				ComboBox1.Text = "";
				ComboBox2.SelectedIndex = -1;
				ComboBox2.Text = "";
				ComboBox3.SelectedIndex = -1;
				ComboBox3.Text = "";
				ComboBox4.SelectedIndex = -1;
				ComboBox4.Text = "";
				ComboBox5.SelectedIndex = -1;
				ComboBox5.Text = "";
				RadTextBox1.Text = "";
			if (ShouldClearFields)
			{
			}
			if (!PageInsert && PageState == FormStateEnum.Navigation)
				DisableEnableContros(false);				
			else
				DisableEnableContros(true);				
		}		

		public override void ShowInitialValues()
		{
		}

		public override void PageEdit()
		{
			base.PageEdit(); 
		}

		public override void ShowFormulas()
		{
			Label3.Text = Label3.Text.Replace("<", "&lt;");
			Label3.Text = Label3.Text.Replace(">", "&gt;");
			Label4.Text = Label4.Text.Replace("<", "&lt;");
			Label4.Text = Label4.Text.Replace(">", "&gt;");
			Label5.Text = Label5.Text.Replace("<", "&lt;");
			Label5.Text = Label5.Text.Replace(">", "&gt;");
			Label6.Text = Label6.Text.Replace("<", "&lt;");
			Label6.Text = Label6.Text.Replace(">", "&gt;");
			Label7.Text = Label7.Text.Replace("<", "&lt;");
			Label7.Text = Label7.Text.Replace(">", "&gt;");
			Label1.Text = Label1.Text.Replace("<", "&lt;");
			Label1.Text = Label1.Text.Replace(">", "&gt;");
			Label2.Text = Label2.Text.Replace("<", "&lt;");
			Label2.Text = Label2.Text.Replace(">", "&gt;");
			Label8.Text = Label8.Text.Replace("<", "&lt;");
			Label8.Text = Label8.Text.Replace(">", "&gt;");
		}
		
		/// <summary>
		/// Define conteudo dos objetos de Tela
		/// </summary>
		public override void DefinePageContent(GeneralDataProviderItem Item)
		{
			try
			{
				string Val = Item["PAR_FASE1"].GetFormattedValue();
				if (ComboBox1.Items.Count == 0)
				{
					DataRow row = PageProvider.ComboBox1_GetComboItem(Val);
					ComboBox1.Text = row["DISPLAY_FIELD"].ToString();
					ComboBox1.SelectedValue = row["FASE_ID"].ToString();
					ComboBox1.Attributes.Add("AllowFilter", "False");
				}
			}
			catch
			{
				ComboBox1.SelectedValue = "";
				ComboBox1.Text = "";
			}
			try
			{
				string Val = Item["PAR_FASE2"].GetFormattedValue();
				if (ComboBox2.Items.Count == 0)
				{
					DataRow row = PageProvider.ComboBox2_GetComboItem(Val);
					ComboBox2.Text = row["DISPLAY_FIELD"].ToString();
					ComboBox2.SelectedValue = row["FASE_ID"].ToString();
					ComboBox2.Attributes.Add("AllowFilter", "False");
				}
			}
			catch
			{
				ComboBox2.SelectedValue = "";
				ComboBox2.Text = "";
			}
			try
			{
				string Val = Item["PAR_FASE3"].GetFormattedValue();
				if (ComboBox3.Items.Count == 0)
				{
					DataRow row = PageProvider.ComboBox3_GetComboItem(Val);
					ComboBox3.Text = row["DISPLAY_FIELD"].ToString();
					ComboBox3.SelectedValue = row["FASE_ID"].ToString();
					ComboBox3.Attributes.Add("AllowFilter", "False");
				}
			}
			catch
			{
				ComboBox3.SelectedValue = "";
				ComboBox3.Text = "";
			}
			try
			{
				string Val = Item["PAR_FASE4"].GetFormattedValue();
				if (ComboBox4.Items.Count == 0)
				{
					DataRow row = PageProvider.ComboBox4_GetComboItem(Val);
					ComboBox4.Text = row["DISPLAY_FIELD"].ToString();
					ComboBox4.SelectedValue = row["FASE_ID"].ToString();
					ComboBox4.Attributes.Add("AllowFilter", "False");
				}
			}
			catch
			{
				ComboBox4.SelectedValue = "";
				ComboBox4.Text = "";
			}
			try
			{
				string Val = Item["PAR_FASE5"].GetFormattedValue();
				if (ComboBox5.Items.Count == 0)
				{
					DataRow row = PageProvider.ComboBox5_GetComboItem(Val);
					ComboBox5.Text = row["DISPLAY_FIELD"].ToString();
					ComboBox5.SelectedValue = row["FASE_ID"].ToString();
					ComboBox5.Attributes.Add("AllowFilter", "False");
				}
			}
			catch
			{
				ComboBox5.SelectedValue = "";
				ComboBox5.Text = "";
			}
			try { RadTextBox1.Text = Item["PAR_EMPRESA"].GetFormattedValue(); }
			catch { RadTextBox1.Text = ""; }
			ApplyMasks(RadTextBox1);
			InitializePageContent();
			base.DefinePageContent(Item);
		}
		
		/// <summary>
		/// Define apelidos da Página
		/// </summary>
		public override void InitializeAlias(GeneralDataProviderItem Item)
        {
			PageProvider.AliasVariables = new Dictionary<string, object>();
			PageProvider.AliasVariables.Clear();
			
			try
			{
				PAR_FASE1Field = long.Parse(Item["PAR_FASE1"].GetFormattedValue());
			}
			catch
			{
				PAR_FASE1Field = 0;
			}
			try
			{
				PAR_FASE2Field = long.Parse(Item["PAR_FASE2"].GetFormattedValue());
			}
			catch
			{
				PAR_FASE2Field = 0;
			}
			try
			{
				PAR_FASE3Field = long.Parse(Item["PAR_FASE3"].GetFormattedValue());
			}
			catch
			{
				PAR_FASE3Field = 0;
			}
			try
			{
				PAR_FASE4Field = long.Parse(Item["PAR_FASE4"].GetFormattedValue());
			}
			catch
			{
				PAR_FASE4Field = 0;
			}
			try
			{
				PAR_FASE5Field = long.Parse(Item["PAR_FASE5"].GetFormattedValue());
			}
			catch
			{
				PAR_FASE5Field = 0;
			}
			try
			{
				PAR_EMPRESAField = Item["PAR_EMPRESA"].GetFormattedValue();
			}
			catch
			{
				PAR_EMPRESAField = "";
			}
			PageProvider.AliasVariables.Add("PAR_FASE1Field", PAR_FASE1Field);
			PageProvider.AliasVariables.Add("PAR_FASE2Field", PAR_FASE2Field);
			PageProvider.AliasVariables.Add("PAR_FASE3Field", PAR_FASE3Field);
			PageProvider.AliasVariables.Add("PAR_FASE4Field", PAR_FASE4Field);
			PageProvider.AliasVariables.Add("PAR_FASE5Field", PAR_FASE5Field);
			PageProvider.AliasVariables.Add("PAR_EMPRESAField", PAR_EMPRESAField);
			PageProvider.AliasVariables.Add("BasePage", this);
        }





		public override void ExecuteServerCommandRequest(string CommandName, string TargetName, string[] Parameters)
		{
			ExecuteLocalCommandRequest(CommandName, TargetName, Parameters);
		}		





		protected void ___ComboBox1_OnItemsRequested(object sender, RadComboBoxItemsRequestedEventArgs e)
		{
			KeyValuePair<string, object> AllowFilterContext = e.Context.FirstOrDefault(c => c.Key == "AllowFilter");
			bool AllowFilter = false;
			if (AllowFilterContext.Value != null) AllowFilter = Convert.ToBoolean(AllowFilterContext.Value);
		
			KeyValuePair<string, object> IsRefreshContext = e.Context.FirstOrDefault(c => c.Key == "IsRefresh");
			bool IsRefresh = false;
			if (IsRefreshContext.Value != null) IsRefresh = Convert.ToBoolean(IsRefreshContext.Value);
		
			int ItemsCount = Convert.ToInt32(e.Context["ItemsCount"]);
			e.EndOfItems = PageProvider.FillComboBox1(sender as RadComboBox, e.NumberOfItems, e.Text, AllowFilter);
		}
		
		protected void ___ComboBox2_OnItemsRequested(object sender, RadComboBoxItemsRequestedEventArgs e)
		{
			KeyValuePair<string, object> AllowFilterContext = e.Context.FirstOrDefault(c => c.Key == "AllowFilter");
			bool AllowFilter = false;
			if (AllowFilterContext.Value != null) AllowFilter = Convert.ToBoolean(AllowFilterContext.Value);
		
			KeyValuePair<string, object> IsRefreshContext = e.Context.FirstOrDefault(c => c.Key == "IsRefresh");
			bool IsRefresh = false;
			if (IsRefreshContext.Value != null) IsRefresh = Convert.ToBoolean(IsRefreshContext.Value);
		
			int ItemsCount = Convert.ToInt32(e.Context["ItemsCount"]);
			e.EndOfItems = PageProvider.FillComboBox2(sender as RadComboBox, e.NumberOfItems, e.Text, AllowFilter);
		}
		
		protected void ___ComboBox3_OnItemsRequested(object sender, RadComboBoxItemsRequestedEventArgs e)
		{
			KeyValuePair<string, object> AllowFilterContext = e.Context.FirstOrDefault(c => c.Key == "AllowFilter");
			bool AllowFilter = false;
			if (AllowFilterContext.Value != null) AllowFilter = Convert.ToBoolean(AllowFilterContext.Value);
		
			KeyValuePair<string, object> IsRefreshContext = e.Context.FirstOrDefault(c => c.Key == "IsRefresh");
			bool IsRefresh = false;
			if (IsRefreshContext.Value != null) IsRefresh = Convert.ToBoolean(IsRefreshContext.Value);
		
			int ItemsCount = Convert.ToInt32(e.Context["ItemsCount"]);
			e.EndOfItems = PageProvider.FillComboBox3(sender as RadComboBox, e.NumberOfItems, e.Text, AllowFilter);
		}
		
		protected void ___ComboBox4_OnItemsRequested(object sender, RadComboBoxItemsRequestedEventArgs e)
		{
			KeyValuePair<string, object> AllowFilterContext = e.Context.FirstOrDefault(c => c.Key == "AllowFilter");
			bool AllowFilter = false;
			if (AllowFilterContext.Value != null) AllowFilter = Convert.ToBoolean(AllowFilterContext.Value);
		
			KeyValuePair<string, object> IsRefreshContext = e.Context.FirstOrDefault(c => c.Key == "IsRefresh");
			bool IsRefresh = false;
			if (IsRefreshContext.Value != null) IsRefresh = Convert.ToBoolean(IsRefreshContext.Value);
		
			int ItemsCount = Convert.ToInt32(e.Context["ItemsCount"]);
			e.EndOfItems = PageProvider.FillComboBox4(sender as RadComboBox, e.NumberOfItems, e.Text, AllowFilter);
		}
		
		protected void ___ComboBox5_OnItemsRequested(object sender, RadComboBoxItemsRequestedEventArgs e)
		{
			KeyValuePair<string, object> AllowFilterContext = e.Context.FirstOrDefault(c => c.Key == "AllowFilter");
			bool AllowFilter = false;
			if (AllowFilterContext.Value != null) AllowFilter = Convert.ToBoolean(AllowFilterContext.Value);
		
			KeyValuePair<string, object> IsRefreshContext = e.Context.FirstOrDefault(c => c.Key == "IsRefresh");
			bool IsRefresh = false;
			if (IsRefreshContext.Value != null) IsRefresh = Convert.ToBoolean(IsRefreshContext.Value);
		
			int ItemsCount = Convert.ToInt32(e.Context["ItemsCount"]);
			e.EndOfItems = PageProvider.FillComboBox5(sender as RadComboBox, e.NumberOfItems, e.Text, AllowFilter);
		}
	}
}

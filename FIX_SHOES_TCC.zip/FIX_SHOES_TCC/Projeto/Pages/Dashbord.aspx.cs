using System;
using System.Collections;
using System.Collections.Specialized;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Web;
using System.IO;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.Security;
using System.Text.RegularExpressions;
using System.Globalization;
using System.Configuration;
using System.Linq;
using PROJETO;
using COMPONENTS;
using COMPONENTS.Data;
using COMPONENTS.Configuration;
using COMPONENTS.Security;
using PROJETO.DataProviders;
using PROJETO.DataPages;
using Telerik.Web.UI;

namespace PROJETO.DataPages
{
	public partial class Dashbord : GeneralDataPage
	{
		protected DashbordPageProvider PageProvider;
	
		public string ATBFiltroField = "";
		public string PAR_EMPRESAField = "";
		public long PAR_FASE1Field = 0;
		public long PAR_FASE2Field = 0;
		public long PAR_FASE3Field = 0;
		public long PAR_FASE4Field = 0;
		public long PAR_FASE5Field = 0;
		
		public override string FormID { get { return "28718"; } }
		public override string TableName { get { return "TB_PARAMETRO"; } }
		public override string DatabaseName { get { return "CRMSSI"; } }
		public override string PageName { get { return "Dashbord.aspx"; } }
		public override string ProjectID { get { return "1DB2E771"; } }
		public override string TableParameters { get { return "true"; } }
		public override bool PageInsert { get { return false;}}
		public override bool CanEdit { get { return false && UpdateValidation(); }}
		public override bool CanInsert  { get { return false && InsertValidation(); } }
		public override bool CanDelete { get { return false && DeleteValidation(); } }
		public override bool CanView { get { return true; } }
		public override bool OpenInEditMode { get { return false; } }
		



		public override bool AuthenticationRequired { get { return false; } }
		
		public override void CreateProvider()
		{
			PageProvider = new DashbordPageProvider(this);
		}
		
		private void InitializePageContent()
		{
		}

		public override void GridRebind()
		{
			Grid1.CurrentPageIndex = 0;
			Grid1.DataSource = null;
			Grid1.Rebind();
			Grid2.CurrentPageIndex = 0;
			Grid2.DataSource = null;
			Grid2.Rebind();
		}

		/// <summary>
        /// onInit Vamos Carregar o Painel de Ajax e Label de erros da página
        /// </summary>
		protected override void OnInit(EventArgs e)
		{
			AjaxPanel = MainAjaxPanel;
			if (IsPostBack)
			{
				AjaxPanel.ResponseScripts.Add("setTimeout(\"InitializeClient();\",100);");
			}
			if (HttpContext.Current.Request.UrlReferrer == null)
			{
				HttpContext.Current.Response.Redirect(Utility.StartPageName);  
				return;
			}
			AjaxPanel.ResponseScripts.Add("setTimeout(\"RegisterClientValidateScript();\",100);");
			if (!IsPostBack)
			{
			}
			ErrorLabel = labError;
			if (!PageInsert )
				DisableEnableContros(false);
			this.Load += new EventHandler(PageLoad_SaveOnSession);

			base.OnInit(e);
		}

		private void PageLoad_SaveOnSession(object sender, EventArgs e)
		{
			if(IsPostBack)
			{
				Session["28718_TBFiltro"] = TBFiltro.Text;
			}
			else
			{
				try { TBFiltro.Text = (Session["28718_TBFiltro"]).ToString(); } catch { }
			}
		}

		

		/// <summary>
		/// Carrega os objetos de Item de acordo com os controles
		/// </summary>
		public override void UpdateItemFromControl(GeneralDataProviderItem  Item)
		{
			// só vamos permitir a carga dos itens de acordo com os controles de tela caso esteja ocorrendo
			// um postback pois em caso contrário a página está sendo aberta em modo de inclusão/edição
			// e dessa forma não teve alteração de usuário nos dados do formulário
			if (PageState != FormStateEnum.Navigation && this.IsPostBack)
			{
			}
			InitializeAlias(Item);
		}

		/// <summary>
		/// Carrega os objetos de tela para o Item Provider da página
		/// </summary>

		public override GeneralDataProviderItem LoadItemFromControl(bool EnableValidation)
		{
			GeneralDataProviderItem Item = PageProvider.GetDataProviderItem(DataProvider);
			if (PageState != FormStateEnum.Navigation)
			{
			}
			else
			{
				Item = PageProvider.MainProvider.DataProvider.SelectItem(PageNumber, FormPositioningEnum.Current);
			}
			if (EnableValidation)
			{
				InitializeAlias(Item);
				if (PageState == FormStateEnum.Insert)
				{
					FillAuxiliarTables();
				}
				PageProvider.Validate(Item); 
			}
			if (Item!=null) PageErrors.Add(Item.Errors);
			return Item;
		}
		

		/// <summary>
		/// Define a Máscara para cada campo na tela
		/// </summary>
		public override void DefineMask()
		{
		}

		public override void DefineStartScripts()
		{
			Utility.SetControlTabOnEnter(TBFiltro);
		}
		
		public override void DisableEnableContros(bool Action)
		{
		}

		/// <summary>
		/// Limpa Campos na tela
		/// </summary>
		public override void ClearFields(bool ShouldClearFields)
		{
			if (ShouldClearFields)
			{
			}
			if (!PageInsert && PageState == FormStateEnum.Navigation)
				DisableEnableContros(false);				
			else
				DisableEnableContros(true);				
		}		

		public override void ShowInitialValues()
		{
			try
			{
				TBFiltro.Text = ("P").ToString();
			}
			catch (Exception e)
			{
			}
		}

		public override void PageEdit()
		{
			DisableEnableContros(true); 
			base.PageEdit(); 
		}

		public override void ShowFormulas()
		{
			Label5.Text = Label5.Text.Replace("<", "&lt;");
			Label5.Text = Label5.Text.Replace(">", "&gt;");
			Label6.Text = Label6.Text.Replace("<", "&lt;");
			Label6.Text = Label6.Text.Replace(">", "&gt;");
			Label8.Text = Label8.Text.Replace("<", "&lt;");
			Label8.Text = Label8.Text.Replace(">", "&gt;");
			try { Label13.Text = Valores("Total"); }
			catch { Label13.Text = ""; }
			Label13.Text = Label13.Text.Replace(double.NaN.ToString(), "");
			Label13.Text = Label13.Text.Replace("<", "&lt;");
			Label13.Text = Label13.Text.Replace(">", "&gt;");
			Label10.Text = Label10.Text.Replace("<", "&lt;");
			Label10.Text = Label10.Text.Replace(">", "&gt;");
			try { Label15.Text = Valores("Andamento"); }
			catch { Label15.Text = ""; }
			Label15.Text = Label15.Text.Replace(double.NaN.ToString(), "");
			Label15.Text = Label15.Text.Replace("<", "&lt;");
			Label15.Text = Label15.Text.Replace(">", "&gt;");
			Label11.Text = Label11.Text.Replace("<", "&lt;");
			Label11.Text = Label11.Text.Replace(">", "&gt;");
			try { Label16.Text = Valores("Perdido"); }
			catch { Label16.Text = ""; }
			Label16.Text = Label16.Text.Replace(double.NaN.ToString(), "");
			Label16.Text = Label16.Text.Replace("<", "&lt;");
			Label16.Text = Label16.Text.Replace(">", "&gt;");
			Label12.Text = Label12.Text.Replace("<", "&lt;");
			Label12.Text = Label12.Text.Replace(">", "&gt;");
			try { Label14.Text = Valores("Ganho"); }
			catch { Label14.Text = ""; }
			Label14.Text = Label14.Text.Replace(double.NaN.ToString(), "");
			Label14.Text = Label14.Text.Replace("<", "&lt;");
			Label14.Text = Label14.Text.Replace(">", "&gt;");
			Label18.Text = Label18.Text.Replace("<", "&lt;");
			Label18.Text = Label18.Text.Replace(">", "&gt;");
			Label20.Text = Label20.Text.Replace("<", "&lt;");
			Label20.Text = Label20.Text.Replace(">", "&gt;");
		}
		
		/// <summary>
		/// Define conteudo dos objetos de Tela
		/// </summary>
		public override void DefinePageContent(GeneralDataProviderItem Item)
		{
			ApplyMasks(TBFiltro);
			InitializePageContent();
			base.DefinePageContent(Item);
		}
		
		/// <summary>
		/// Define apelidos da Página
		/// </summary>
		public override void InitializeAlias(GeneralDataProviderItem Item)
        {
			PageProvider.AliasVariables = new Dictionary<string, object>();
			PageProvider.AliasVariables.Clear();
			
			try
			{
				ATBFiltroField = TBFiltro.Text;
			}
			catch
			{
				ATBFiltroField = "";
			}
			try
			{
				PAR_EMPRESAField = Item["PAR_EMPRESA"].GetFormattedValue();
			}
			catch
			{
				PAR_EMPRESAField = "";
			}
			try
			{
				PAR_FASE1Field = long.Parse(Item["PAR_FASE1"].GetFormattedValue(), CultureInfo.CurrentCulture);
			}
			catch
			{
				PAR_FASE1Field = 0;
			}
			try
			{
				PAR_FASE2Field = long.Parse(Item["PAR_FASE2"].GetFormattedValue(), CultureInfo.CurrentCulture);
			}
			catch
			{
				PAR_FASE2Field = 0;
			}
			try
			{
				PAR_FASE3Field = long.Parse(Item["PAR_FASE3"].GetFormattedValue(), CultureInfo.CurrentCulture);
			}
			catch
			{
				PAR_FASE3Field = 0;
			}
			try
			{
				PAR_FASE4Field = long.Parse(Item["PAR_FASE4"].GetFormattedValue(), CultureInfo.CurrentCulture);
			}
			catch
			{
				PAR_FASE4Field = 0;
			}
			try
			{
				PAR_FASE5Field = long.Parse(Item["PAR_FASE5"].GetFormattedValue(), CultureInfo.CurrentCulture);
			}
			catch
			{
				PAR_FASE5Field = 0;
			}
			PageProvider.AliasVariables.Add("ATBFiltroField", ATBFiltroField);
			PageProvider.AliasVariables.Add("PAR_EMPRESAField", PAR_EMPRESAField);
			PageProvider.AliasVariables.Add("PAR_FASE1Field", PAR_FASE1Field);
			PageProvider.AliasVariables.Add("PAR_FASE2Field", PAR_FASE2Field);
			PageProvider.AliasVariables.Add("PAR_FASE3Field", PAR_FASE3Field);
			PageProvider.AliasVariables.Add("PAR_FASE4Field", PAR_FASE4Field);
			PageProvider.AliasVariables.Add("PAR_FASE5Field", PAR_FASE5Field);
			PageProvider.AliasVariables.Add("BasePage", this);
        }

		protected override void OnLoadComplete(EventArgs e)
		{
			try { PageProvider.Graph1GraphProvider.FiltroAtual = ""; }
			catch { PageProvider.Graph1GraphProvider.FiltroAtual = "1 = 2"; }
			Graph.SetGraphDynamic(Graph1, Graph.GraphType.Column, null, PageProvider.Graph1GraphProvider.SelectAllItems().Tables[0], "MES", "Quantidade", "Status");
			base.OnLoadComplete(e);
		}




		public override void ExecuteServerCommandRequest(string CommandName, string TargetName, string[] Parameters)
		{
			ExecuteLocalCommandRequest(CommandName, TargetName, Parameters);
		}		


		
		/// <summary>
		/// Carrega os objetos de tela para o Item Provider da grid
		/// </summary>
		public override GeneralDataProviderItem LoadItemFromGridControl(bool EnableValidation, string GridId)
		{
			GeneralDataProviderItem Item = null;
			switch (GridId)
			{
				case "Grid1":
					if (PageProvider.Dashbord_Grid1Provider.DataProvider.Item == null)
						Item = PageProvider.Dashbord_Grid1Provider.GetDataProviderItem();
					else
						Item = PageProvider.Dashbord_Grid1Provider.DataProvider.Item;
					PageProvider.Dashbord_Grid1Provider.RaiseSetRelationFields(PageProvider.Dashbord_Grid1Provider, Item);
					Item.SetFieldValue(Item["Tipo"], PageProvider.Dashbord_Grid1Provider.GridData["Tipo"]);
					Item.SetFieldValue(Item["Descricao"], PageProvider.Dashbord_Grid1Provider.GridData["Descricao"]);
					PageProvider.Dashbord_Grid1Provider.InitializeAlias(Item);
					if (EnableValidation)
					{
						PageProvider.Dashbord_Grid1Provider.Validate(Item);
					}
					break;
				case "Grid2":
					if (PageProvider.Dashbord_Grid2Provider.DataProvider.Item == null)
						Item = PageProvider.Dashbord_Grid2Provider.GetDataProviderItem();
					else
						Item = PageProvider.Dashbord_Grid2Provider.DataProvider.Item;
					PageProvider.Dashbord_Grid2Provider.RaiseSetRelationFields(PageProvider.Dashbord_Grid2Provider, Item);
					Item.SetFieldValue(Item["NEG_TITULO"], PageProvider.Dashbord_Grid2Provider.GridData["NEG_TITULO"]);
					PageProvider.Dashbord_Grid2Provider.InitializeAlias(Item);
					if (EnableValidation)
					{
						PageProvider.Dashbord_Grid2Provider.Validate(Item);
					}
					break;
			}

			return Item;
		}

		public override void setGridPerm()
		{
			if (!PageOperations.AllowInsert)
			{
				Grid1.MasterTableView.CommandItemDisplay = GridCommandItemDisplay.None;
			}
			if (Grid1.Columns[0] is GridEditCommandColumn && !PageOperations.AllowUpdate)
			{
				Grid1.Columns[0].Visible = false;
			}
			if (Grid1.Columns.Count != 0 && Grid1.Columns[Grid1.Columns.Count - 1] is GridButtonColumn && (Grid1.Columns[Grid1.Columns.Count - 1] as GridButtonColumn).CommandName == "Delete" && !PageOperations.AllowDelete)
			{
				Grid1.Columns[Grid1.Columns.Count - 1].Visible = false;
			}
			if (!PageOperations.AllowInsert)
			{
				Grid2.MasterTableView.CommandItemDisplay = GridCommandItemDisplay.None;
			}
			if (Grid2.Columns[0] is GridEditCommandColumn && !PageOperations.AllowUpdate)
			{
				Grid2.Columns[0].Visible = false;
			}
			if (Grid2.Columns.Count != 0 && Grid2.Columns[Grid2.Columns.Count - 1] is GridButtonColumn && (Grid2.Columns[Grid2.Columns.Count - 1] as GridButtonColumn).CommandName == "Delete" && !PageOperations.AllowDelete)
			{
				Grid2.Columns[Grid2.Columns.Count - 1].Visible = false;
			}
		}

		protected void Grid1_ItemCreated(object sender, GridItemEventArgs e)
		{
			if (e.Item is GridEditableItem && (e.Item.IsInEditMode))
			{
				if (Grid1.Columns[0].ColumnType == "GridEditCommandColumn" && PageOperations.AllowUpdate)
				{
					if (Grid1.Columns[0].HeaderStyle.Width == 20 && Grid1.Columns[0].Visible == true)
					{
						Grid1.Columns[0].HeaderStyle.Width = 70; 
					}
					else
					{
						Grid1.Columns[0].HeaderStyle.Width = 20; 
					}
				}
				GridEditableItem editableItem = (GridEditableItem)e.Item;
				TextBox txt;
				txt = (editableItem.EditManager.GetColumnEditor("GridColumn1") as GridTextBoxColumnEditor).TextBoxControl;
				txt.Width = 78;
				txt = (editableItem.EditManager.GetColumnEditor("GridColumn2") as GridTextBoxColumnEditor).TextBoxControl;
				txt.Width = 323;
				GridItemCreatedFinished(sender, e);
			}
		}
		
		protected void Grid2_ItemCreated(object sender, GridItemEventArgs e)
		{
			if (e.Item is GridEditableItem && (e.Item.IsInEditMode))
			{
				if (Grid2.Columns[0].ColumnType == "GridEditCommandColumn" && PageOperations.AllowUpdate)
				{
					if (Grid2.Columns[0].HeaderStyle.Width == 20 && Grid2.Columns[0].Visible == true)
					{
						Grid2.Columns[0].HeaderStyle.Width = 70; 
					}
					else
					{
						Grid2.Columns[0].HeaderStyle.Width = 20; 
					}
				}
				GridEditableItem editableItem = (GridEditableItem)e.Item;
				TextBox txt;
				txt = (editableItem.EditManager.GetColumnEditor("GridColumn4") as GridTextBoxColumnEditor).TextBoxControl;
				txt.Width = 418;
				txt.Attributes.Add("data-validation-engine", "validate[funcCall[GridColumn4_Validation]]");
				txt.Attributes.Add("data-validation-message", "Descricao não pode ser vazio!");
				AjaxPanel.ResponseScripts.Add("jQuery(\"#Grid2\").validationEngine();");
				GridItemCreatedFinished(sender, e);
			}
		}
		
		
		
		protected void Grid1_ItemDataBound(object sender, GridItemEventArgs e)
		{
			if (e.Item is GridPagerItem)
			{
				GridPagerItem pager = (GridPagerItem)e.Item;
				RadComboBox PageSizeComboBox = (RadComboBox)pager.FindControl("PageSizeComboBox");
				PageSizeComboBox.Visible = false;
				Label ChangePageSizeLabel = (Label)pager.FindControl("ChangePageSizeLabel");
				ChangePageSizeLabel.Visible = false;
			}
		}
		
		protected void Grid2_ItemDataBound(object sender, GridItemEventArgs e)
		{
			if (e.Item is GridPagerItem)
			{
				GridPagerItem pager = (GridPagerItem)e.Item;
				RadComboBox PageSizeComboBox = (RadComboBox)pager.FindControl("PageSizeComboBox");
				PageSizeComboBox.Visible = false;
				Label ChangePageSizeLabel = (Label)pager.FindControl("ChangePageSizeLabel");
				ChangePageSizeLabel.Visible = false;
			}
		}
		
		protected void Grid1_ItemCommand(object source, GridCommandEventArgs e)
		{
			RadGrid Grid = (RadGrid)source;
			if (e.CommandName == RadGrid.InitInsertCommandName)// If insert mode, disallow edit
			{
				Grid.MasterTableView.ClearEditItems();
			}
			if (e.CommandName == RadGrid.EditCommandName) // If edit mode, disallow insert
			{
				e.Item.OwnerTableView.IsItemInserted = false;
			}
			if (e.CommandName == RadGrid.ExpandCollapseCommandName) // Allow Expand/Collapse one row at a time
			{
				foreach (GridItem item in e.Item.OwnerTableView.Items)
				{
					if (item.Expanded && item != e.Item)
					{
						item.Expanded = false;
					}
				}
			}
			if (e.CommandName == Telerik.Web.UI.RadGrid.ExportToWordCommandName || e.CommandName == Telerik.Web.UI.RadGrid.ExportToPdfCommandName ||
				e.CommandName == Telerik.Web.UI.RadGrid.ExportToExcelCommandName || e.CommandName == Telerik.Web.UI.RadGrid.ExportToCsvCommandName)
			{
				Grid.AllowPaging = false;
				Grid.ExportSettings.IgnorePaging = true;
				Grid.ExportSettings.OpenInNewWindow = true;
			}
			if (e.Item is GridDataItem && !(e.Item is GridDataInsertItem) && e.CommandName != "Cancel" && e.CommandName != "Update" && e.CommandName != "Insert")
			{
				GeneralGridProvider Provider = GetGridProvider(Grid);
				Hashtable CurrentValues = new Hashtable();
				GridDataItem item = (GridDataItem)e.Item;
				if (e.CommandArgument != null && e.CommandArgument.ToString() != "")
				{
					int index = 0;
					if (int.TryParse(e.CommandArgument.ToString(), out index)) item = e.Item.OwnerTableView.Items[index];
				}
				item.ExtractValues(CurrentValues);
				InitializeGridData(Grid);
				string Filtro = "";
				Dictionary<string, FieldBase> Items = Provider.DataProvider.CreateItemFields();
				foreach (string key in item.OwnerTableView.DataKeyNames)
				{
					if(Provider.DataProvider.Item.GetFieldAliasByFieldName(key) != "")
						CurrentValues[Provider.DataProvider.Item.GetFieldAliasByFieldName(key)] = item.GetDataKeyValue(key);
					else
						CurrentValues[key] = item.GetDataKeyValue(key);
					FieldBase field = Provider.DataProvider.GetFieldByName(Items, key);
					FieldType fieldType = (field != null ? field.FieldType : FieldType.Text);
					if(Provider.DataProvider.Item.GetFieldAliasByFieldName(key) != "")
						Filtro += String.Format("[{0}] = {1} AND ", key, Dao.ToSql(CurrentValues[Provider.DataProvider.Item.GetFieldAliasByFieldName(key)].ToString(), fieldType));
					else
						Filtro += String.Format("[{0}] = {1} AND ", key, Dao.ToSql(CurrentValues[key].ToString(), fieldType));
				}
				if (Filtro.Length > 0)
				{
					if (String.IsNullOrEmpty(Provider.DataProvider.FiltroAtual))
						Provider.DataProvider.FiltroAtual = Filtro.Substring(0, Filtro.Length - 5);
					else
						Provider.DataProvider.FiltroAtual = String.Format("({0}) AND {1}", Provider.DataProvider.FiltroAtual, Filtro.Substring(0, Filtro.Length - 5));
				}
				Provider.SelectItem(this, Grid.ID, CurrentValues);
		
				switch (e.CommandName)
				{
					case "GridColumn3":
						bool ActionSucceeded_GridColumn3_1 = true;
						try
						{
							string UrlPage = ResolveUrl("~/Pages/Tarefas.aspx");
							UrlPage += '?' + "ParTarID=" + (Convert.ToString(Provider.DataProvider.Item["ID"].GetValue())).ToString();
							try
							{
								if (!IsPostBack)
								{
									ClientScript.RegisterStartupScript(this.GetType(), "OnLinkClick_GWindow", "<script>NavigateTargetByReference('" + UrlPage + "','GWindow', { Modal: true, Center: true });</script>");
								}
								else
								{
									AjaxPanel.ResponseScripts.Add("NavigateTargetByReference('" + UrlPage + "','GWindow', { Modal: true, Center: true });");
								}
							}
							catch(Exception ex)
							{
							}
						}
						catch (Exception ex)
						{
							ActionSucceeded_GridColumn3_1 = false;
							PageErrors.Add("Error", ex.Message);
							ShowErrors();
						}
					break;
				}
			}
		}
		protected void Grid2_ItemCommand(object source, GridCommandEventArgs e)
		{
			RadGrid Grid = (RadGrid)source;
			if (e.CommandName == RadGrid.InitInsertCommandName)// If insert mode, disallow edit
			{
				Grid.MasterTableView.ClearEditItems();
			}
			if (e.CommandName == RadGrid.EditCommandName) // If edit mode, disallow insert
			{
				e.Item.OwnerTableView.IsItemInserted = false;
			}
			if (e.CommandName == RadGrid.ExpandCollapseCommandName) // Allow Expand/Collapse one row at a time
			{
				foreach (GridItem item in e.Item.OwnerTableView.Items)
				{
					if (item.Expanded && item != e.Item)
					{
						item.Expanded = false;
					}
				}
			}
			if (e.CommandName == Telerik.Web.UI.RadGrid.ExportToWordCommandName || e.CommandName == Telerik.Web.UI.RadGrid.ExportToPdfCommandName ||
				e.CommandName == Telerik.Web.UI.RadGrid.ExportToExcelCommandName || e.CommandName == Telerik.Web.UI.RadGrid.ExportToCsvCommandName)
			{
				Grid.AllowPaging = false;
				Grid.ExportSettings.IgnorePaging = true;
				Grid.ExportSettings.OpenInNewWindow = true;
			}
			if (e.Item is GridDataItem && !(e.Item is GridDataInsertItem) && e.CommandName != "Cancel" && e.CommandName != "Update" && e.CommandName != "Insert")
			{
				GeneralGridProvider Provider = GetGridProvider(Grid);
				Hashtable CurrentValues = new Hashtable();
				GridDataItem item = (GridDataItem)e.Item;
				if (e.CommandArgument != null && e.CommandArgument.ToString() != "")
				{
					int index = 0;
					if (int.TryParse(e.CommandArgument.ToString(), out index)) item = e.Item.OwnerTableView.Items[index];
				}
				item.ExtractValues(CurrentValues);
				foreach (string key in item.OwnerTableView.DataKeyNames)
				{
					if(Provider.DataProvider.Item.GetFieldAliasByFieldName(key) != "")
						CurrentValues[Provider.DataProvider.Item.GetFieldAliasByFieldName(key)] = item.GetDataKeyValue(key);
					else
						CurrentValues[key] = item.GetDataKeyValue(key);
				}
				Provider.SelectItem(this, Grid.ID, CurrentValues);
		
				switch (e.CommandName)
				{
					case "GridColumn5":
						bool ActionSucceeded_GridColumn5_1 = true;
						try
						{
							string UrlPage = ResolveUrl("~/Pages/Neg_cio.aspx");
							UrlPage += '?' + "Par_NegID=" + (Convert.ToInt32(Provider.DataProvider.Item["NEG_ID"].GetValue())).ToString();
							try
							{
								if (!IsPostBack)
								{
									ClientScript.RegisterStartupScript(this.GetType(), "OnLinkClick_GWindow", "<script>NavigateTargetByReference('" + UrlPage + "','GWindow', { Modal: true, Center: true });</script>");
								}
								else
								{
									AjaxPanel.ResponseScripts.Add("NavigateTargetByReference('" + UrlPage + "','GWindow', { Modal: true, Center: true });");
								}
							}
							catch(Exception ex)
							{
							}
						}
						catch (Exception ex)
						{
							ActionSucceeded_GridColumn5_1 = false;
							PageErrors.Add("Error", ex.Message);
							ShowErrors();
						}
					break;
				}
			}
		}

		public override void RefreshOnNavigation()
		{
			Grid1.MasterTableView.ClearEditItems();
			Grid2.MasterTableView.ClearEditItems();
			Grid1.MasterTableView.IsItemInserted = false;
			Grid2.MasterTableView.IsItemInserted = false;
		}

		protected void Grid_Init(object sender, EventArgs e)
		{
			RadGrid Grid = (RadGrid)sender;
			GridFilterMenu menu = Grid.FilterMenu;
			int i = 0;
			while (i < menu.Items.Count)
			{
				if (menu.Items[i].Value == "Between" || menu.Items[i].Value == "NotBetween")
				{
					menu.Items.RemoveAt(i);
				}
				else
				{
					i++;
				}
			}
		}

		protected void Grid_NeedDataSource(object source, GridNeedDataSourceEventArgs e)
		{
			int TotalRecords = 0;
			string GridFilter = "";
			RadGrid Grid = (RadGrid)source;
			InitializeGridData(Grid);

			
			if (Grid.MasterTableView.SortExpressions.Count > 0)
			{
				string orderBy = "";
				foreach (GridSortExpression sort in Grid.MasterTableView.SortExpressions)
				{
					orderBy += GetGridProvider(Grid).DataProvider.Dao.PoeColAspas(sort.FieldName) + " " + sort.SortOrderAsString() + ", ";
				}
				GetGridProvider(Grid).DataProvider.OrderBy = orderBy.Remove(orderBy.Length - 2);
			}
			Grid.DataSource = GetGridProvider(Grid).DataProvider.SelectItems(Grid.CurrentPageIndex, Grid.PageSize, out TotalRecords);
			Grid.VirtualItemCount = TotalRecords;
		}
		 
		protected void Grid_UpdateCommand(object source, GridCommandEventArgs e)
		{
			var editableItem = (GridEditableItem)e.Item;
			RadGrid Grid = (RadGrid)source;
			Tuple<Hashtable, Hashtable> GridValues = FillGridValues(editableItem, Grid);
			GetGridProvider(Grid).UpdateItem(this, Grid.ID, DefineGridInsertValues(Grid.ID, GridValues.Item1), GridValues.Item2);
			 if (GetGridProvider(Grid).PageErrors != null)
            {
                e.Canceled = true;
                PageErrors.Add(GetGridProvider(Grid).PageErrors);
                return;
            }
			Grid.DataSource = null;
            Grid.Rebind();
			PageShow(FormPositioningEnum.Current, true, false, false);
		}

		protected void Grid_InsertCommand(object source, GridCommandEventArgs e)
		{
			var editableItem = (GridEditableItem)e.Item;
			RadGrid Grid = (RadGrid)source;
			Hashtable newValues = new Hashtable();
			e.Item.OwnerTableView.ExtractValuesFromItem(newValues, editableItem);
			GetGridProvider(Grid).InsertItem(this, Grid.ID, DefineGridInsertValues(Grid.ID, newValues));
			if (GetGridProvider(Grid).PageErrors != null)
            {
                e.Canceled = true;
                PageErrors.Add(GetGridProvider(Grid).PageErrors);
                return;
            }
			PageShow(FormPositioningEnum.Current, true, false, false);
		}

		protected void Grid_DeleteCommand(object source, GridCommandEventArgs e)
		{
			RadGrid Grid = (RadGrid)source;
            DeleteGrid(Grid, false, (GridEditableItem)e.Item);
			if (GetGridProvider(Grid).PageErrors != null)
			{
				e.Canceled = true;
				PageErrors.Add(GetGridProvider(Grid).PageErrors);
				return;
			}
			PageShow(FormPositioningEnum.Current, true, false, false);
		}

		public override void DeleteChildItens()
        {
            base.DeleteChildItens();
        }

		public void DeleteGrid(RadGrid Grid, bool DeleteAllItems, GridEditableItem SingleItem)
        {
			int StartIndex = 0;
            if (!DeleteAllItems) StartIndex = SingleItem.ItemIndex;
            else
            {
                Grid.DataSource = null;
                Grid.CurrentPageIndex = 0;
                Grid.Rebind();
            }
            while (Grid.Items.Count != 0 && PageErrors.Count == 0)
            {
                for (int i = StartIndex; Grid.MasterTableView.Items.Count > i; i++)
                {
                    switch (Grid.ID)
                    {
					}
                    Tuple<Hashtable, Hashtable> GridValues = FillGridValues(Grid.MasterTableView.Items[i], Grid);
                    GetGridProvider(Grid).DeleteItem(this, Grid.ID, GridValues.Item1, GridValues.Item2);
					if(GetGridProvider(Grid).PageErrors != null) PageErrors.Add(GetGridProvider(Grid).PageErrors);
                    if (!DeleteAllItems) break;
                }
				Grid.DataSource = null;
				if (DeleteAllItems) Grid.CurrentPageIndex = 0;
                if (!DeleteAllItems && Grid.Items.Count == 1 && Grid.CurrentPageIndex > 0) Grid.CurrentPageIndex--;
                Grid.Rebind();
				if (!DeleteAllItems) break;
            }
		}

		private Tuple<Hashtable, Hashtable> FillGridValues(GridEditableItem editableItem, RadGrid Grid)
		{
			Hashtable newValues = new Hashtable();
			editableItem.OwnerTableView.ExtractValuesFromItem(newValues, editableItem);
			Hashtable oldValues = newValues.Clone() as Hashtable;
			foreach (string key in Grid.MasterTableView.DataKeyNames)
			{
				string FdAlias = (from f in GetGridProvider(Grid).DataProvider.Item.Fields where f.Value.Name == key select f.Key).FirstOrDefault();
				if (!newValues.ContainsKey(key)) newValues.Add(key, editableItem.GetDataKeyValue(key));
				if (!oldValues.ContainsKey(FdAlias))
				{
					oldValues.Add(FdAlias, editableItem.GetDataKeyValue(key));
				}
				else
				{
					oldValues[FdAlias] = editableItem.GetDataKeyValue(key);
				}
			}
			return new Tuple<Hashtable, Hashtable>(newValues, oldValues);
		}
		
		private void InitializeGridData(RadGrid Grid)
		{
			switch (Grid.ID)
			{
				case "Grid1":
					try
					{
						if(GetGridProvider(Grid).DataProvider.FiltroAtual != null && GetGridProvider(Grid).DataProvider.FiltroAtual.Trim().Length > 0)
						{
							GetGridProvider(Grid).DataProvider.FiltroAtual = "(" + GetGridProvider(Grid).DataProvider.FiltroAtual + ") AND (" + Dao.PoeColAspas("Finalizado") + " = " + Dao.ToSql("false", FieldType.Boolean) + ")";
						}
						else
						{
							GetGridProvider(Grid).DataProvider.FiltroAtual = Dao.PoeColAspas("Finalizado") + " = " + Dao.ToSql("false", FieldType.Boolean);
						}
					}
					catch
					{
						GetGridProvider(Grid).DataProvider.FiltroAtual = "1 = 2";
					}
					GetGridProvider(Grid).DataProvider.OrderBy = "[Data] Asc";
					break;
				case "Grid2":
					try
					{
						if(GetGridProvider(Grid).DataProvider.FiltroAtual != null && GetGridProvider(Grid).DataProvider.FiltroAtual.Trim().Length > 0)
						{
							GetGridProvider(Grid).DataProvider.FiltroAtual = "(" + GetGridProvider(Grid).DataProvider.FiltroAtual + ") AND (" + Dao.PoeColAspas("NEG_STATUS") + " = " + Dao.ToSql("Em andamento", FieldType.Text) + ")";
						}
						else
						{
							GetGridProvider(Grid).DataProvider.FiltroAtual = Dao.PoeColAspas("NEG_STATUS") + " = " + Dao.ToSql("Em andamento", FieldType.Text);
						}
					}
					catch
					{
						GetGridProvider(Grid).DataProvider.FiltroAtual = "1 = 2";
					}
					break;
			}
		}
		
		public override GeneralGridProvider GetGridProvider(RadGrid Grid)
		{
			switch (Grid.ID)
		{
				case "Grid1":
					return PageProvider.Dashbord_Grid1Provider;
				case "Grid2":
					return PageProvider.Dashbord_Grid2Provider;
			}
			return null;
		}



#region CÓDIGO DE USUARIO
        private string Valores(string Tipo)
        {
            string valor = "0,00";

            if (Tipo == "Total")
            {
                valor = CRMSSI.SQLExecutaRetornoF9("SELECT isnull(SUM(NEG_VALORULT),'0,00') AS TOTAL FROM TB_NEGOCIO", "");
            }

            if (Tipo == "Andamento")
            {
                valor = CRMSSI.SQLExecutaRetornoF9("SELECT isnull(SUM(NEG_VALORULT),'0,00') AS TOTAL FROM TB_NEGOCIO WHERE NEG_STATUS = 'Em andamento'", "");
            }

            if (Tipo == "Perdido")
            {
                valor = CRMSSI.SQLExecutaRetornoF9("SELECT isnull(SUM(NEG_VALORULT),'0,00') AS TOTAL FROM TB_NEGOCIO WHERE NEG_STATUS = 'Perdido'", "");
            }

            if (Tipo == "Ganho")
            {
                valor = CRMSSI.SQLExecutaRetornoF9("SELECT isnull(SUM(NEG_VALORULT),'0,00') AS TOTAL FROM TB_NEGOCIO WHERE NEG_STATUS = 'Concluído'", "");
            }

            return valor;
        }
#endregion
	}
}

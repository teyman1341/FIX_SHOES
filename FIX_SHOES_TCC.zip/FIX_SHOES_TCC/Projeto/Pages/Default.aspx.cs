using System;
using System.Collections;
using System.Collections.Specialized;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Web;
using System.IO;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.Security;
using System.Text.RegularExpressions;
using System.Globalization;
using COMPONENTS;

namespace PROJETO
{
	public partial class Default:Page
	{
		
#region CÓDIGO DE USUARIO

		protected void Form1_LoadCompleted()
		{
            Div4.Attributes.Add("OnMouseOver", "HideControl('DivSubMenu');");
            IFrame1.Attributes.Add("OnMouseOver", "HideControl('DivSubMenu');");
		}
#endregion

		protected override void OnLoad(EventArgs e)
		{
			try
			{
				AjaxPanel1.ResponseScripts.Add("setTimeout(\"resizeIframe();\",100);");

				string argument = Page.Request["__EVENTTARGET"];
				if (argument == "LOGOFF")
				{
					SessionClose();
				}
				Utility.CheckAuthentication(this,true);
				InitializePageContent();
				Page.ClientScript.GetPostBackEventReference(new PostBackOptions(this));
			}
			catch (Exception ex)
			{
			}
		}


		public void ShowFormulas()
		{
			Label4.Text = Label4.Text.Replace("<", "&lt;");
			Label4.Text = Label4.Text.Replace(">", "&gt;");
			Label5.Text = Label5.Text.Replace("<", "&lt;");
			Label5.Text = Label5.Text.Replace(">", "&gt;");
			try { Label2.Text = (EnvironmentVariable.LoggedLoginUser).ToString(); }
			catch { Label2.Text = ""; }
			Label2.Text = Label2.Text.Replace(double.NaN.ToString(), "");
			Label2.Text = Label2.Text.Replace("<", "&lt;");
			Label2.Text = Label2.Text.Replace(">", "&gt;");
			Label3.Text = Label3.Text.Replace("<", "&lt;");
			Label3.Text = Label3.Text.Replace(">", "&gt;");
			Label6.Text = Label6.Text.Replace("<", "&lt;");
			Label6.Text = Label6.Text.Replace(">", "&gt;");
		}

		private void InitializePageContent()
		{
			ShowFormulas();
		}

			protected void ___Form1_LoadCompleted()
			{
				bool ActionSucceeded_1 = true;
				try
				{
					Form1_LoadCompleted();
				}
				catch (Exception ex)
				{
					ActionSucceeded_1 = false;
				}
			}

			protected void ___BtnInicio_OnClick(object sender, EventArgs e)
			{
				bool ActionSucceeded_1 = true;
				try
				{
					BtnInicio.Style["background-color"] = "#E7E7E7";
				}
				catch (Exception ex)
				{
					ActionSucceeded_1 = false;
				}
				bool ActionSucceeded_2 = true;
				try
				{
					BtnTarefa.Style["background-color"] = "#283848";
				}
				catch (Exception ex)
				{
					ActionSucceeded_2 = false;
				}
				bool ActionSucceeded_3 = true;
				try
				{
					BtnNegocio.Style["background-color"] = "#283848";
				}
				catch (Exception ex)
				{
					ActionSucceeded_3 = false;
				}
			}

			protected void ___BtnTarefa_OnClick(object sender, EventArgs e)
			{
				bool ActionSucceeded_1 = true;
				try
				{
					BtnInicio.Style["background-color"] = "#283848";
				}
				catch (Exception ex)
				{
					ActionSucceeded_1 = false;
				}
				bool ActionSucceeded_2 = true;
				try
				{
					BtnNegocio.Style["background-color"] = "#283848";
				}
				catch (Exception ex)
				{
					ActionSucceeded_2 = false;
				}
				bool ActionSucceeded_3 = true;
				try
				{
					BtnTarefa.Style["background-color"] = "#E7E7E7";
				}
				catch (Exception ex)
				{
					ActionSucceeded_3 = false;
				}
				bool ActionSucceeded_4 = true;
				try
				{
					string UrlPage = ResolveUrl("~/Pages/Lista___Tarefas.aspx");
					try
					{
					if (!IsPostBack) ClientScript.RegisterStartupScript(this.GetType(), "OnClick_IFrame1","<script>document.getElementById('IFrame1').contentWindow.location.href = '" + UrlPage + "';</script>");
					if (IsPostBack) AjaxPanel1.ResponseScripts.Add("document.getElementById('IFrame1').contentWindow.location.href = '" + UrlPage + "';");
					}
					catch(Exception ex)
					{
					}
				}
				catch (Exception ex)
				{
					ActionSucceeded_4 = false;
				}
			}

			protected void ___BtnNegocio_OnClick(object sender, EventArgs e)
			{
				bool ActionSucceeded_1 = true;
				try
				{
					BtnInicio.Style["background-color"] = "#283848";
				}
				catch (Exception ex)
				{
					ActionSucceeded_1 = false;
				}
				bool ActionSucceeded_2 = true;
				try
				{
					BtnTarefa.Style["background-color"] = "#283848";
				}
				catch (Exception ex)
				{
					ActionSucceeded_2 = false;
				}
				bool ActionSucceeded_3 = true;
				try
				{
					BtnNegocio.Style["background-color"] = "#E7E7E7";
				}
				catch (Exception ex)
				{
					ActionSucceeded_3 = false;
				}
				bool ActionSucceeded_4 = true;
				try
				{
					string UrlPage = ResolveUrl("~/Pages/Lista___Neg_cio.aspx");
					try
					{
					if (!IsPostBack) ClientScript.RegisterStartupScript(this.GetType(), "OnClick_IFrame1","<script>document.getElementById('IFrame1').contentWindow.location.href = '" + UrlPage + "';</script>");
					if (IsPostBack) AjaxPanel1.ResponseScripts.Add("document.getElementById('IFrame1').contentWindow.location.href = '" + UrlPage + "';");
					}
					catch(Exception ex)
					{
					}
				}
				catch (Exception ex)
				{
					ActionSucceeded_4 = false;
				}
			}

			protected void ___Button8_OnClick(object sender, EventArgs e)
			{
				bool ActionSucceeded_1 = true;
				try
				{
					string UrlPage = ResolveUrl("~/Pages/Access.aspx");
					try
					{
						if (!IsPostBack)
						{
							ClientScript.RegisterStartupScript(this.GetType(), "OnClick_GWindow", "<script>NavigateTargetByReference('" + UrlPage + "','GWindow', { Modal: true, Center: true });</script>");
						}
						else
						{
							AjaxPanel1.ResponseScripts.Add("NavigateTargetByReference('" + UrlPage + "','GWindow', { Modal: true, Center: true });");
						}
					}
					catch(Exception ex)
					{
					}
				}
				catch (Exception ex)
				{
					ActionSucceeded_1 = false;
				}
			}

			protected void ___Button9_OnClick(object sender, EventArgs e)
			{
				bool ActionSucceeded_1 = true;
				try
				{
					string UrlPage = ResolveUrl("~/Pages/Produtos.aspx");
					try
					{
						if (!IsPostBack)
						{
							ClientScript.RegisterStartupScript(this.GetType(), "OnClick_GWindow", "<script>NavigateTargetByReference('" + UrlPage + "','GWindow', { Modal: true, Center: true });</script>");
						}
						else
						{
							AjaxPanel1.ResponseScripts.Add("NavigateTargetByReference('" + UrlPage + "','GWindow', { Modal: true, Center: true });");
						}
					}
					catch(Exception ex)
					{
					}
				}
				catch (Exception ex)
				{
					ActionSucceeded_1 = false;
				}
			}

			protected void ___Button11_OnClick(object sender, EventArgs e)
			{
				bool ActionSucceeded_1 = true;
				try
				{
					string UrlPage = ResolveUrl("~/Pages/Fases.aspx");
					try
					{
						if (!IsPostBack)
						{
							ClientScript.RegisterStartupScript(this.GetType(), "OnClick_GWindow", "<script>NavigateTargetByReference('" + UrlPage + "','GWindow', { Modal: true, Center: true });</script>");
						}
						else
						{
							AjaxPanel1.ResponseScripts.Add("NavigateTargetByReference('" + UrlPage + "','GWindow', { Modal: true, Center: true });");
						}
					}
					catch(Exception ex)
					{
					}
				}
				catch (Exception ex)
				{
					ActionSucceeded_1 = false;
				}
			}

			protected void ___Button13_OnClick(object sender, EventArgs e)
			{
				bool ActionSucceeded_1 = true;
				try
				{
					string UrlPage = ResolveUrl("~/Pages/Configura__es.aspx");
					try
					{
						if (!IsPostBack)
						{
							ClientScript.RegisterStartupScript(this.GetType(), "OnClick_GWindow", "<script>NavigateTargetByReference('" + UrlPage + "','GWindow', { Modal: true, Center: true });</script>");
						}
						else
						{
							AjaxPanel1.ResponseScripts.Add("NavigateTargetByReference('" + UrlPage + "','GWindow', { Modal: true, Center: true });");
						}
					}
					catch(Exception ex)
					{
					}
				}
				catch (Exception ex)
				{
					ActionSucceeded_1 = false;
				}
			}

		protected override void InitializeCulture()
		{
			Utility.SetThreadCulture();  
		}
		protected override void OnLoadComplete(EventArgs e)
		{
			___Form1_LoadCompleted();
			base.OnLoadComplete(e);
		}

		private void SessionClose()
		{
			FormsAuthentication.SignOut();
			Session.Clear();
			Response.Redirect(Utility.StartPageName);
		}

	}

}

using System;
using System.Collections;
using System.Collections.Specialized;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Web;
using System.IO;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.Security;
using System.Text.RegularExpressions;
using System.Globalization;
using System.Configuration;
using System.Linq;
using PROJETO;
using COMPONENTS;
using COMPONENTS.Data;
using COMPONENTS.Configuration;
using COMPONENTS.Security;
using PROJETO.DataProviders;
using PROJETO.DataPages;
using Telerik.Web.UI;

namespace PROJETO.DataPages
{
	public partial class Detalhe_da_Tarefa : GeneralDataPage
	{
		protected Detalhe_da_TarefaPageProvider PageProvider;
	
		public long TAR_IDField = 0;
		public string TAR_TIPOField = "";
		public string TAR_DESCField = "";
		public long NEG_IDField = 0;
		public string TAR_RESPONSAVELField = "";
		public long CLI_IDField = 0;
		public bool TAR_FINALIZADOField = false;
		public DateTime ? TAR_DATAHORAField = null;
		
		public override string FormID { get { return "28723"; } }
		public override string TableName { get { return "TB_TAREFA"; } }
		public override string DatabaseName { get { return "CRMSSI"; } }
		public override string PageName { get { return "Detalhe_da_Tarefa.aspx"; } }
		public override string ProjectID { get { return "1DB2E771"; } }
		public override string TableParameters { get { return "false"; } }
		public override bool PageInsert { get { return false;}}
		public override bool CanEdit { get { return false && UpdateValidation(); }}
		public override bool CanInsert  { get { return false && InsertValidation(); } }
		public override bool CanDelete { get { return false && DeleteValidation(); } }
		public override bool CanView { get { return true; } }
		public override bool OpenInEditMode { get { return false; } }
		


		public string ParID = "";

		public override void SetStartFilter()
		{
			try
			{
				if (!String.IsNullOrEmpty(ParID))
				{
					PageProvider.MainProvider.DataProvider.StartFilter = Dao.PoeColAspas("TAR_ID") + " = " + Dao.ToSql(ParID.ToString(), FieldType.Integer);
				}
				else
				{
					PageProvider.MainProvider.DataProvider.StartFilter = "1 = 2";
				}
			}
			catch
			{
				PageProvider.MainProvider.DataProvider.StartFilter = "1 = 2";
			}
		}
		
		public override void CreateProvider()
		{
			PageProvider = new Detalhe_da_TarefaPageProvider(this);
		}
		
		private void InitializePageContent()
		{
		}

		/// <summary>
        /// onInit Vamos Carregar o Painel de Ajax e Label de erros da página
        /// </summary>
		protected override void OnInit(EventArgs e)
		{
			ParID = HttpContext.Current.Request.QueryString["ParID"];
			try { if (string.IsNullOrEmpty(ParID)) ParID = HttpContext.Current.Session["ParID"].ToString();} catch {} 
			if (string.IsNullOrEmpty(ParID)) ParID = "0";
			AjaxPanel = MainAjaxPanel;
			if (IsPostBack)
			{
				AjaxPanel.ResponseScripts.Add("setTimeout(\"InitializeClient();\",100);");
			}
			ErrorLabel = labError;
			if (!PageInsert )
				DisableEnableContros(false);

			base.OnInit(e);
		}
		

		/// <summary>
		/// Carrega os objetos de Item de acordo com os controles
		/// </summary>
		public override void UpdateItemFromControl(GeneralDataProviderItem  Item)
		{
			// só vamos permitir a carga dos itens de acordo com os controles de tela caso esteja ocorrendo
			// um postback pois em caso contrário a página está sendo aberta em modo de inclusão/edição
			// e dessa forma não teve alteração de usuário nos dados do formulário
			if (PageState != FormStateEnum.Navigation && this.IsPostBack)
			{
			}
			InitializeAlias(Item);
		}

		/// <summary>
		/// Carrega os objetos de tela para o Item Provider da página
		/// </summary>

		public override GeneralDataProviderItem LoadItemFromControl(bool EnableValidation)
		{
			GeneralDataProviderItem Item = PageProvider.GetDataProviderItem(DataProvider);
			if (PageState != FormStateEnum.Navigation)
			{
			}
			else
			{
				Item = PageProvider.MainProvider.DataProvider.SelectItem(PageNumber, FormPositioningEnum.Current);
			}
			if (EnableValidation)
			{
				InitializeAlias(Item);
				if (PageState == FormStateEnum.Insert)
				{
					FillAuxiliarTables();
				}
				PageProvider.Validate(Item); 
			}
			if (Item!=null) PageErrors.Add(Item.Errors);
			return Item;
		}
		

		/// <summary>
		/// Define a Máscara para cada campo na tela
		/// </summary>
		public override void DefineMask()
		{
		}

		public override void DefineStartScripts()
		{
		}
		
		public override void DisableEnableContros(bool Action)
		{
		}

		/// <summary>
		/// Limpa Campos na tela
		/// </summary>
		public override void ClearFields(bool ShouldClearFields)
		{
			if (ShouldClearFields)
			{
			}
			if (!PageInsert && PageState == FormStateEnum.Navigation)
				DisableEnableContros(false);				
			else
				DisableEnableContros(true);				
		}		

		public override void ShowInitialValues()
		{
		}

		public override void PageEdit()
		{
			DisableEnableContros(true); 
			base.PageEdit(); 
		}

		public override void ShowFormulas()
		{
			try { Label1.Text = (TAR_DESCField).ToString(); }
			catch { Label1.Text = ""; }
			Label1.Text = Label1.Text.Replace(double.NaN.ToString(), "");
			Label1.Text = Label1.Text.Replace("<", "&lt;");
			Label1.Text = Label1.Text.Replace(">", "&gt;");
		}
		
		/// <summary>
		/// Define conteudo dos objetos de Tela
		/// </summary>
		public override void DefinePageContent(GeneralDataProviderItem Item)
		{
			InitializePageContent();
			base.DefinePageContent(Item);
		}
		
		/// <summary>
		/// Define apelidos da Página
		/// </summary>
		public override void InitializeAlias(GeneralDataProviderItem Item)
        {
			PageProvider.AliasVariables = new Dictionary<string, object>();
			PageProvider.AliasVariables.Clear();
			
			try
			{
				TAR_IDField = long.Parse(Item["TAR_ID"].GetFormattedValue(), CultureInfo.CurrentCulture);
			}
			catch
			{
				TAR_IDField = 0;
			}
			try
			{
				TAR_TIPOField = Item["TAR_TIPO"].GetFormattedValue();
			}
			catch
			{
				TAR_TIPOField = "";
			}
			try
			{
				TAR_DESCField = Item["TAR_DESC"].GetFormattedValue();
			}
			catch
			{
				TAR_DESCField = "";
			}
			try
			{
				NEG_IDField = long.Parse(Item["NEG_ID"].GetFormattedValue(), CultureInfo.CurrentCulture);
			}
			catch
			{
				NEG_IDField = 0;
			}
			try
			{
				TAR_RESPONSAVELField = Item["TAR_RESPONSAVEL"].GetFormattedValue();
			}
			catch
			{
				TAR_RESPONSAVELField = "";
			}
			try
			{
				CLI_IDField = long.Parse(Item["CLI_ID"].GetFormattedValue(), CultureInfo.CurrentCulture);
			}
			catch
			{
				CLI_IDField = 0;
			}
			try
			{
				TAR_FINALIZADOField = Utility.StringConverterToBool(Item["TAR_FINALIZADO"].GetFormattedValue());
			}
			catch
			{
				TAR_FINALIZADOField = false;
			}
			try
			{
				TAR_DATAHORAField = DateTime.Parse(Item["TAR_DATAHORA"].GetFormattedValue(), CultureInfo.CurrentCulture);
			}
			catch
			{
				TAR_DATAHORAField = null;
			}
			PageProvider.AliasVariables.Add("TAR_IDField", TAR_IDField);
			PageProvider.AliasVariables.Add("TAR_TIPOField", TAR_TIPOField);
			PageProvider.AliasVariables.Add("TAR_DESCField", TAR_DESCField);
			PageProvider.AliasVariables.Add("NEG_IDField", NEG_IDField);
			PageProvider.AliasVariables.Add("TAR_RESPONSAVELField", TAR_RESPONSAVELField);
			PageProvider.AliasVariables.Add("CLI_IDField", CLI_IDField);
			PageProvider.AliasVariables.Add("TAR_FINALIZADOField", TAR_FINALIZADOField);
			PageProvider.AliasVariables.Add("TAR_DATAHORAField", TAR_DATAHORAField);
			PageProvider.AliasVariables.Add("ParID", ParID);
			PageProvider.AliasVariables.Add("BasePage", this);
        }





		public override void ExecuteServerCommandRequest(string CommandName, string TargetName, string[] Parameters)
		{
			ExecuteLocalCommandRequest(CommandName, TargetName, Parameters);
		}		





	}
}

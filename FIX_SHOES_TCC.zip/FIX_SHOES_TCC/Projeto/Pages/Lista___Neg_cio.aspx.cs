using System;
using System.Collections;
using System.Collections.Specialized;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Web;
using System.IO;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.Security;
using System.Text.RegularExpressions;
using System.Globalization;
using System.Configuration;
using System.Linq;
using PROJETO;
using COMPONENTS;
using COMPONENTS.Data;
using COMPONENTS.Configuration;
using COMPONENTS.Security;
using PROJETO.DataProviders;
using PROJETO.DataPages;
using Telerik.Web.UI;

namespace PROJETO.DataPages
{
	public partial class Lista___Neg_cio : GeneralDataPage
	{
		protected Lista___Neg_cioPageProvider PageProvider;
	
		public string ACBFiltroClienteField = "";
		public string ACBFiltroStatusField = "";
		public string ACBFiltroProdutoField = "";
		public string ACBFiltroFaseField = "";
		public string PAR_EMPRESAField = "";
		public long PAR_FASE1Field = 0;
		public long PAR_FASE2Field = 0;
		public long PAR_FASE3Field = 0;
		public long PAR_FASE4Field = 0;
		public long PAR_FASE5Field = 0;
		
		public override string FormID { get { return "28711"; } }
		public override string TableName { get { return "TB_PARAMETRO"; } }
		public override string DatabaseName { get { return "CRMSSI"; } }
		public override string PageName { get { return "Lista___Neg_cio.aspx"; } }
		public override string ProjectID { get { return "1DB2E771"; } }
		public override string TableParameters { get { return "true"; } }
		public override bool PageInsert { get { return false;}}
		public override bool CanEdit { get { return false && UpdateValidation(); }}
		public override bool CanInsert  { get { return false && InsertValidation(); } }
		public override bool CanDelete { get { return false && DeleteValidation(); } }
		public override bool CanView { get { return true; } }
		public override bool OpenInEditMode { get { return false; } }
		



		
		public override void CreateProvider()
		{
			PageProvider = new Lista___Neg_cioPageProvider(this);
		}
		
		private void InitializePageContent()
		{
		}

		/// <summary>
        /// onInit Vamos Carregar o Painel de Ajax e Label de erros da página
        /// </summary>
		protected override void OnInit(EventArgs e)
		{
			AjaxPanel = MainAjaxPanel;
			if (IsPostBack)
			{
				AjaxPanel.ResponseScripts.Add("setTimeout(\"InitializeClient();\",100);");
			}
			ErrorLabel = labError;
			if (!PageInsert )
				DisableEnableContros(false);
			this.Load += new EventHandler(PageLoad_SaveOnSession);
			this.Load += new EventHandler(DataPage_Load);

			base.OnInit(e);
		}

		private void PageLoad_SaveOnSession(object sender, EventArgs e)
		{
			if(IsPostBack)
			{
				Session["28711_CBFiltroCliente"] = CBFiltroCliente.SelectedValue;
				Session["28711_CBFiltroStatus"] = CBFiltroStatus.SelectedValue;
				Session["28711_CBFiltroProduto"] = CBFiltroProduto.SelectedValue;
				Session["28711_CBFiltroFase"] = CBFiltroFase.SelectedValue;
			}
			else
			{
				try
				{
					CBFiltroCliente.SelectedValue = (Session["28711_CBFiltroCliente"]).ToString();
					DataRow DR = PageProvider.CBFiltroCliente_GetComboItem(CBFiltroCliente.SelectedValue);
					CBFiltroCliente.Text = DR["DISPLAY_FIELD"].ToString()  ;
				}
				catch
				{ }
				try
				{
					CBFiltroStatus.SelectedValue = (Session["28711_CBFiltroStatus"]).ToString();
					CBFiltroStatus.Text = PageProvider.CBFiltroStatusItems.Where(p => p.Value == (Session["28711_CBFiltroStatus"]).ToString()).FirstOrDefault().Text;
				}
				catch
				{ }
				try
				{
					CBFiltroProduto.SelectedValue = (Session["28711_CBFiltroProduto"]).ToString();
					DataRow DR = PageProvider.CBFiltroProduto_GetComboItem(CBFiltroProduto.SelectedValue);
					CBFiltroProduto.Text = DR["DISPLAY_FIELD"].ToString()  ;
				}
				catch
				{ }
				try
				{
					CBFiltroFase.SelectedValue = (Session["28711_CBFiltroFase"]).ToString();
					DataRow DR = PageProvider.CBFiltroFase_GetComboItem(CBFiltroFase.SelectedValue);
					CBFiltroFase.Text = DR["DISPLAY_FIELD"].ToString()  ;
				}
				catch
				{ }
			}
		}

		

		/// <summary>
		/// Define os Parâmetros para acesso às tabelas auxiliares
		/// </summary>
		public override void SetParametersValues(GeneralDataProvider Provider)
		{
			try
			{
				if (Provider == PageProvider.PAR_FASE1Provider && Provider.IndexName == "PK_FASE")
				{
						Provider.Parameters["FASE_ID"].Parameter.SetValue(EnvironmentVariable.CRMSSI.TB_PARAMETRO.PAR_FASE1);
				}
				if (Provider == PageProvider.PAR_FASE2Provider && Provider.IndexName == "PK_FASE")
				{
						Provider.Parameters["FASE_ID"].Parameter.SetValue(EnvironmentVariable.CRMSSI.TB_PARAMETRO.PAR_FASE2);
				}
				if (Provider == PageProvider.PAR_FASE3Provider && Provider.IndexName == "PK_FASE")
				{
						Provider.Parameters["FASE_ID"].Parameter.SetValue(EnvironmentVariable.CRMSSI.TB_PARAMETRO.PAR_FASE3);
				}
				if (Provider == PageProvider.PAR_FASE4Provider && Provider.IndexName == "PK_FASE")
				{
						Provider.Parameters["FASE_ID"].Parameter.SetValue(EnvironmentVariable.CRMSSI.TB_PARAMETRO.PAR_FASE4);
				}
				if (Provider == PageProvider.PAR_FASE5Provider && Provider.IndexName == "PK_FASE")
				{
						Provider.Parameters["FASE_ID"].Parameter.SetValue(EnvironmentVariable.CRMSSI.TB_PARAMETRO.PAR_FASE5);
				}
			}
			catch
			{
			}
		}
		
		private void StartListControls()
		{
			DataList1Index = new Hashtable();
			PageProvider.DataList1DataListProvider.DataProvider.PrepareSelectCountCommands();
			PageProvider.DataList1DataListProvider.DataProvider.OrderBy = PageProvider.DataList1DataListProvider.DataProvider.Dao.PoeColAspas("NEG_ID") + " Desc";
			try
			{
				PageProvider.DataList1DataListProvider.DataProvider.FiltroAtual = Filtrar();
			}
			catch
			{
				PageProvider.DataList1DataListProvider.DataProvider.FiltroAtual = "1 = 2";
			}
			int __DataList1_PageNumber = DataList1_PageNumber;
			DataList1.DataSource = RepeaterPagerControler.ControlPagesButtons(Pager1, 5, 25, ref __DataList1_PageNumber, true, true, PageProvider.DataList1DataListProvider.DataProvider);
			DataList1_PageNumber = __DataList1_PageNumber;
			DataList1.ItemDataBound += new DataListItemEventHandler(DataList1_ItemDataBound);
			DataList1.DataBind();
		}

		public int DataList1_PageNumber
		{
			get
			{
				if (ViewState["DataList1_PageNumber"] != null)
					return (int)ViewState["DataList1_PageNumber"];
				return 0;
			}
			set
			{
				ViewState["DataList1_PageNumber"] = value;
			}
		}

		public void __Pager1__Click(object sender, EventArgs e)
		{
			switch (((Button)sender).CommandArgument.ToUpper())
			{
				case "F":
					DataList1_PageNumber = 0;
					break;
				case "P":
					if(DataList1_PageNumber > 0)
						DataList1_PageNumber--;
					break;
				case "N":
					DataList1_PageNumber++;
					break;
				case "L":
					DataList1_PageNumber = -1;
					break;
				default:
					int Num;
					if (int.TryParse(((Button)sender).CommandArgument, out Num))
					{
						DataList1_PageNumber = Num;
					}
					break;
			}
		}

		public Hashtable DataList1Index
		{
			get
			{
				if (ViewState["DataList1Index"] != null)
				{
					return (Hashtable)ViewState["DataList1Index"];
				}
				return null;
			}
			set
			{
				ViewState["DataList1Index"] = value;
			}
		}

		void DataList1_ItemDataBound(object sender, DataListItemEventArgs e)
		{
			object RowObj = e.Item.DataItem;
			if (RowObj is DataRowView) RowObj = ((DataRowView)RowObj).Row;
			DataRow row = RowObj as DataRow;
			if(row != null)
			{
				DataListProviderSinc(row, null, PageProvider.DataList1DataListProvider.DataProvider);
				DataList1Index[e.Item.UniqueID] = "NEG_ID=" + row["NEG_ID"].ToString();
			}
			switch (e.Item.ItemType)
			{
				case ListItemType.Item:
				case ListItemType.AlternatingItem:
					if(row != null)
					{
						RadLabel DListCtrLabel7 = e.Item.FindControl("Label7") as RadLabel;
						DListCtrLabel7.Text = row["NEG_TITULO"].ToString();
						DListCtrLabel7.Text = DListCtrLabel7.Text.Replace("<", "&lt;").Replace(">", "&gt;");
						RadLabel DListCtrLabel8 = e.Item.FindControl("Label8") as RadLabel;
						DListCtrLabel8.Text = row["CLI_NOME"].ToString();
						DListCtrLabel8.Text = DListCtrLabel8.Text.Replace("<", "&lt;").Replace(">", "&gt;");
						RadLabel DListCtrLabel10 = e.Item.FindControl("Label10") as RadLabel;
						DListCtrLabel10.Text = row["PROD_NOME"].ToString();
						DListCtrLabel10.Text = DListCtrLabel10.Text.Replace("<", "&lt;").Replace(">", "&gt;");
						RadLabel DListCtrLabel13 = e.Item.FindControl("Label13") as RadLabel;
						DListCtrLabel13.Text = row["FASE_NOME"].ToString();
						DListCtrLabel13.Text = DListCtrLabel13.Text.Replace("<", "&lt;").Replace(">", "&gt;");
						RadLabel DListCtrLabel15 = e.Item.FindControl("Label15") as RadLabel;
						DListCtrLabel15.Text = row["NEG_VALORULT"].ToString();
						DListCtrLabel15.Text = DListCtrLabel15.Text.Replace("<", "&lt;").Replace(">", "&gt;");
						DListCtrLabel15.Text = Mask.ApplyMask(DListCtrLabel15.Text, "99999999,99", "NUMBER");
						try { (e.Item.FindControl("Div6") as HtmlControl).Style["background-color"] = Concluido_2034728097(row); } catch { }
						try { (e.Item.FindControl("Div6") as HtmlControl).Style["background-color"] = Em_Andamento_1247227359(row); } catch { }
						try { (e.Item.FindControl("Div6") as HtmlControl).Style["background-color"] = Perdido2125763875(row); } catch { }
						try { (e.Item.FindControl("Image12") as System.Web.UI.WebControls.Image).Style["display"] = Concluido1816265400(row); } catch { }
						try { (e.Item.FindControl("Image13") as System.Web.UI.WebControls.Image).Style["display"] = EmAndamento_1942840065(row); } catch { }
						try { (e.Item.FindControl("Image14") as System.Web.UI.WebControls.Image).Style["display"] = Perdido_1292091882(row); } catch { }
					}
					break;
			}
		}

		public override void ResetDataList()
		{
			DataList1_PageNumber = 0;
		}

		/// <summary>
		/// Carrega os objetos de Item de acordo com os controles
		/// </summary>
		public override void UpdateItemFromControl(GeneralDataProviderItem  Item)
		{
			// só vamos permitir a carga dos itens de acordo com os controles de tela caso esteja ocorrendo
			// um postback pois em caso contrário a página está sendo aberta em modo de inclusão/edição
			// e dessa forma não teve alteração de usuário nos dados do formulário
			if (PageState != FormStateEnum.Navigation && this.IsPostBack)
			{
			}
			InitializeAlias(Item);
		}

		/// <summary>
		/// Carrega os objetos de tela para o Item Provider da página
		/// </summary>

		public override GeneralDataProviderItem LoadItemFromControl(bool EnableValidation)
		{
			GeneralDataProviderItem Item = PageProvider.GetDataProviderItem(DataProvider);
			if (PageState != FormStateEnum.Navigation)
			{
			}
			else
			{
				Item = PageProvider.MainProvider.DataProvider.SelectItem(PageNumber, FormPositioningEnum.Current);
			}
			if (EnableValidation)
			{
				InitializeAlias(Item);
				if (PageState == FormStateEnum.Insert)
				{
					FillAuxiliarTables();
				}
				PageProvider.Validate(Item); 
			}
			if (Item!=null) PageErrors.Add(Item.Errors);
			return Item;
		}
		
		public string Concluido_2034728097(DataRow row)
		{
			if((string)row["NEG_STATUS"] == "Concluído")
			{
				return ("#5AB211").ToString();
			}
			throw new Exception();
		}
		public string Em_Andamento_1247227359(DataRow row)
		{
			if((string)row["NEG_STATUS"] == "Em andamento")
			{
				return ("#FF9439").ToString();
			}
			throw new Exception();
		}
		public string Perdido2125763875(DataRow row)
		{
			if((string)row["NEG_STATUS"] == "Perdido")
			{
				return ("#ED3737").ToString();
			}
			throw new Exception();
		}
		public string Concluido1816265400(DataRow row)
		{
			if((string)row["NEG_STATUS"] != "Concluído")
			{
				return (bool.Parse(("false").ToString())?"inline-block":"none");
			}
			throw new Exception();
		}
		public string EmAndamento_1942840065(DataRow row)
		{
			if((string)row["NEG_STATUS"] != "Em andamento")
			{
				return (bool.Parse(("false").ToString())?"inline-block":"none");
			}
			throw new Exception();
		}
		public string Perdido_1292091882(DataRow row)
		{
			if((string)row["NEG_STATUS"] != "Perdido")
			{
				return (bool.Parse(("false").ToString())?"inline-block":"none");
			}
			throw new Exception();
		}

		/// <summary>
		/// Define a Máscara para cada campo na tela
		/// </summary>
		public override void DefineMask()
		{
		}

		public override void DefineStartScripts()
		{
			Utility.SetControlTabOnEnter(CBFiltroCliente);
			Utility.SetControlTabOnEnter(CBFiltroStatus);
			Utility.SetControlTabOnEnter(CBFiltroProduto);
			Utility.SetControlTabOnEnter(CBFiltroFase);
		}
		
		public override void DisableEnableContros(bool Action)
		{
		}

		/// <summary>
		/// Limpa Campos na tela
		/// </summary>
		public override void ClearFields(bool ShouldClearFields)
		{
			if (ShouldClearFields)
			{
			}
			if (!PageInsert && PageState == FormStateEnum.Navigation)
				DisableEnableContros(false);				
			else
				DisableEnableContros(true);				
		}		

		public override void ShowInitialValues()
		{
		}

		public override void PageEdit()
		{
			DisableEnableContros(true); 
			base.PageEdit(); 
		}

		public override void ShowFormulas()
		{
			Label6.Text = Label6.Text.Replace("<", "&lt;");
			Label6.Text = Label6.Text.Replace(">", "&gt;");
		}
		
		/// <summary>
		/// Define conteudo dos objetos de Tela
		/// </summary>
		public override void DefinePageContent(GeneralDataProviderItem Item)
		{
			InitializePageContent();
			base.DefinePageContent(Item);
		}
		
		/// <summary>
		/// Define apelidos da Página
		/// </summary>
		public override void InitializeAlias(GeneralDataProviderItem Item)
        {
			PageProvider.AliasVariables = new Dictionary<string, object>();
			PageProvider.AliasVariables.Clear();
			
			try
			{
				ACBFiltroClienteField = CBFiltroCliente.SelectedValue;
			}
			catch
			{
				ACBFiltroClienteField = "";
			}
			try
			{
				ACBFiltroStatusField = CBFiltroStatus.SelectedValue;
			}
			catch
			{
				ACBFiltroStatusField = "";
			}
			try
			{
				ACBFiltroProdutoField = CBFiltroProduto.SelectedValue;
			}
			catch
			{
				ACBFiltroProdutoField = "";
			}
			try
			{
				ACBFiltroFaseField = CBFiltroFase.SelectedValue;
			}
			catch
			{
				ACBFiltroFaseField = "";
			}
			try
			{
				PAR_EMPRESAField = Item["PAR_EMPRESA"].GetFormattedValue();
			}
			catch
			{
				PAR_EMPRESAField = "";
			}
			try
			{
				PAR_FASE1Field = long.Parse(Item["PAR_FASE1"].GetFormattedValue(), CultureInfo.CurrentCulture);
			}
			catch
			{
				PAR_FASE1Field = 0;
			}
			try
			{
				PAR_FASE2Field = long.Parse(Item["PAR_FASE2"].GetFormattedValue(), CultureInfo.CurrentCulture);
			}
			catch
			{
				PAR_FASE2Field = 0;
			}
			try
			{
				PAR_FASE3Field = long.Parse(Item["PAR_FASE3"].GetFormattedValue(), CultureInfo.CurrentCulture);
			}
			catch
			{
				PAR_FASE3Field = 0;
			}
			try
			{
				PAR_FASE4Field = long.Parse(Item["PAR_FASE4"].GetFormattedValue(), CultureInfo.CurrentCulture);
			}
			catch
			{
				PAR_FASE4Field = 0;
			}
			try
			{
				PAR_FASE5Field = long.Parse(Item["PAR_FASE5"].GetFormattedValue(), CultureInfo.CurrentCulture);
			}
			catch
			{
				PAR_FASE5Field = 0;
			}
			PageProvider.AliasVariables.Add("ACBFiltroClienteField", ACBFiltroClienteField);
			PageProvider.AliasVariables.Add("ACBFiltroStatusField", ACBFiltroStatusField);
			PageProvider.AliasVariables.Add("ACBFiltroProdutoField", ACBFiltroProdutoField);
			PageProvider.AliasVariables.Add("ACBFiltroFaseField", ACBFiltroFaseField);
			PageProvider.AliasVariables.Add("PAR_EMPRESAField", PAR_EMPRESAField);
			PageProvider.AliasVariables.Add("PAR_FASE1Field", PAR_FASE1Field);
			PageProvider.AliasVariables.Add("PAR_FASE2Field", PAR_FASE2Field);
			PageProvider.AliasVariables.Add("PAR_FASE3Field", PAR_FASE3Field);
			PageProvider.AliasVariables.Add("PAR_FASE4Field", PAR_FASE4Field);
			PageProvider.AliasVariables.Add("PAR_FASE5Field", PAR_FASE5Field);
			PageProvider.AliasVariables.Add("BasePage", this);
        }

		 public void ___Link1_OnClick(object sender, EventArgs e)
		{
			bool ActionSucceeded_1 = true;
			try
			{
				string UrlPage = ResolveUrl("~/Pages/Neg_cio.aspx");
				UrlPage += '?' + "Par_NegID=" + (Convert.ToInt32(PageProvider.DataList1DataListProvider.DataProvider.Item["NEG_ID"].GetValue())).ToString();
				try
				{
					if (!IsPostBack)
					{
						ClientScript.RegisterStartupScript(this.GetType(), "OnClick_GWindow", "<script>NavigateTargetByReference('" + UrlPage + "','GWindow', { Modal: false, Center: true });</script>");
					}
					else
					{
						AjaxPanel.ResponseScripts.Add("NavigateTargetByReference('" + UrlPage + "','GWindow', { Modal: false, Center: true });");
					}
				}
				catch(Exception ex)
				{
				}
			}
			catch (Exception ex)
			{
				ActionSucceeded_1 = false;
				PageErrors.Add("Error", ex.Message);
				ShowErrors();
			}
		}

		protected void ___Button2_OnClick(object sender, EventArgs e)
		{
			bool ActionSucceeded_1 = true;
			try
			{
				string UrlPage = ResolveUrl("~/Pages/Cadastro_Cliente.aspx");
				UrlPage += '?' + "Par_IDCliente=";
				try
				{
					if (!IsPostBack)
					{
						ClientScript.RegisterStartupScript(this.GetType(), "OnClick_GWindow", "<script>NavigateTargetByReference('" + UrlPage + "','GWindow', { Modal: true, Center: true });</script>");
					}
					else
					{
						AjaxPanel.ResponseScripts.Add("NavigateTargetByReference('" + UrlPage + "','GWindow', { Modal: true, Center: true });");
					}
				}
				catch(Exception ex)
				{
				}
			}
			catch (Exception ex)
			{
				ActionSucceeded_1 = false;
				PageErrors.Add("Error", ex.Message);
				ShowErrors();
			}
		}

		protected void ___Button4_OnClick(object sender, EventArgs e)
		{
			bool ActionSucceeded_1 = true;
			try
			{
				string UrlPage = ResolveUrl("~/Pages/Neg_cio.aspx");
				UrlPage += '?' + "Par_NegID=";
				try
				{
					if (!IsPostBack)
					{
						ClientScript.RegisterStartupScript(this.GetType(), "OnClick_GWindow", "<script>NavigateTargetByReference('" + UrlPage + "','GWindow', { Modal: true, Center: true });</script>");
					}
					else
					{
						AjaxPanel.ResponseScripts.Add("NavigateTargetByReference('" + UrlPage + "','GWindow', { Modal: true, Center: true });");
					}
				}
				catch(Exception ex)
				{
				}
			}
			catch (Exception ex)
			{
				ActionSucceeded_1 = false;
				PageErrors.Add("Error", ex.Message);
				ShowErrors();
			}
		}

		protected void ___Button8_OnClick(object sender, EventArgs e)
		{
			bool ActionSucceeded_1 = true;
			try
			{
				string UrlPage = ResolveUrl("~/Pages/Tarefas.aspx");
				UrlPage += '?' + "ParTarID=";
				try
				{
					if (!IsPostBack)
					{
						ClientScript.RegisterStartupScript(this.GetType(), "OnClick_GWindow", "<script>NavigateTargetByReference('" + UrlPage + "','GWindow', { Modal: true, Center: true });</script>");
					}
					else
					{
						AjaxPanel.ResponseScripts.Add("NavigateTargetByReference('" + UrlPage + "','GWindow', { Modal: true, Center: true });");
					}
				}
				catch(Exception ex)
				{
				}
			}
			catch (Exception ex)
			{
				ActionSucceeded_1 = false;
				PageErrors.Add("Error", ex.Message);
				ShowErrors();
			}
		}

		protected override void OnLoadComplete(EventArgs e)
		{
			StartListControls();
			base.OnLoadComplete(e);
		}

        public void DataListProviderSinc(object LineIndex, Hashtable Repeaterindex, GeneralDataProvider Provider)
		{
            if (LineIndex is DataRow)
            {
                Provider.LocateRecordByRow((DataRow)LineIndex);
            }
            else
            {
				if (Repeaterindex.Count > 0 && Repeaterindex.ContainsKey(LineIndex))
                {
					Dictionary<string, object> Values = new Dictionary<string, object>();
					string[] splittedVals = Repeaterindex[LineIndex].ToString().Split('§');
					foreach (string Val in splittedVals)
					{
						Values.Add(Val.Substring(0, Val.IndexOf("=")), Val.Substring(Val.IndexOf("=") + 1));
					}
					Provider.FindRecord(Values);
				}
            }
		}


		private void DataPage_Load(object sender, EventArgs e)
		{
			if (IsPostBack)
			{
				string EventTarget = Request["__EVENTTARGET"];
                int End = EventTarget.LastIndexOf("$");
                
                if (End == -1)
                {
                    EventTarget = Request["__EVENTARGUMENT"];
                    int Start  = EventTarget.LastIndexOf("|TargetControl:");
                    
                    if (Start > -1 )
                    {
                        End = (EventTarget.IndexOf("|", Start + 1) > -1 ? EventTarget.IndexOf("|"):(EventTarget.Length - 15) - Start);
                        EventTarget = EventTarget.Substring(Start + 15, End);
                    }
                }
				
				string[] TargetParts = EventTarget.Split(':');
				int DataList1Pos = EventTarget.LastIndexOf("$");
				if (EventTarget.StartsWith("DataList1$") && DataList1Pos != -1)
				{
					string DataList1ClientID = EventTarget.Substring(0, DataList1Pos);
					DataListProviderSinc(DataList1ClientID, DataList1Index, PageProvider.DataList1DataListProvider.DataProvider);
				}
			}
		}


		public override void ExecuteServerCommandRequest(string CommandName, string TargetName, string[] Parameters)
		{
			ExecuteLocalCommandRequest(CommandName, TargetName, Parameters);
		}		





		protected void ___CBFiltroCliente_OnItemsRequested(object sender, RadComboBoxItemsRequestedEventArgs e)
		{
			KeyValuePair<string, object> AllowFilterContext = e.Context.FirstOrDefault(c => c.Key == "AllowFilter");
			bool AllowFilter = false;
			if (AllowFilterContext.Value != null) AllowFilter = Convert.ToBoolean(AllowFilterContext.Value);
		
			KeyValuePair<string, object> IsRefreshContext = e.Context.FirstOrDefault(c => c.Key == "IsRefresh");
			bool IsRefresh = false;
			if (IsRefreshContext.Value != null) IsRefresh = Convert.ToBoolean(IsRefreshContext.Value);
		
			int ItemsCount = Convert.ToInt32(e.Context["ItemsCount"]);
			e.EndOfItems = PageProvider.FillCBFiltroCliente(sender as RadComboBox, e.NumberOfItems, e.Text, AllowFilter);
		}
		
		protected void ___CBFiltroStatus_OnItemsRequested(object sender, RadComboBoxItemsRequestedEventArgs e)
		{
			KeyValuePair<string, object> AllowFilterContext = e.Context.FirstOrDefault(c => c.Key == "AllowFilter");
			bool AllowFilter = false;
			if (AllowFilterContext.Value != null) AllowFilter = Convert.ToBoolean(AllowFilterContext.Value);
		
			KeyValuePair<string, object> IsRefreshContext = e.Context.FirstOrDefault(c => c.Key == "IsRefresh");
			bool IsRefresh = false;
			if (IsRefreshContext.Value != null) IsRefresh = Convert.ToBoolean(IsRefreshContext.Value);
		
			int ItemsCount = Convert.ToInt32(e.Context["ItemsCount"]);
			e.EndOfItems = PageProvider.FillCBFiltroStatus(sender as RadComboBox, e.NumberOfItems, e.Text, AllowFilter);
		}
		
		protected void ___CBFiltroProduto_OnItemsRequested(object sender, RadComboBoxItemsRequestedEventArgs e)
		{
			KeyValuePair<string, object> AllowFilterContext = e.Context.FirstOrDefault(c => c.Key == "AllowFilter");
			bool AllowFilter = false;
			if (AllowFilterContext.Value != null) AllowFilter = Convert.ToBoolean(AllowFilterContext.Value);
		
			KeyValuePair<string, object> IsRefreshContext = e.Context.FirstOrDefault(c => c.Key == "IsRefresh");
			bool IsRefresh = false;
			if (IsRefreshContext.Value != null) IsRefresh = Convert.ToBoolean(IsRefreshContext.Value);
		
			int ItemsCount = Convert.ToInt32(e.Context["ItemsCount"]);
			e.EndOfItems = PageProvider.FillCBFiltroProduto(sender as RadComboBox, e.NumberOfItems, e.Text, AllowFilter);
		}
		
		protected void ___CBFiltroFase_OnItemsRequested(object sender, RadComboBoxItemsRequestedEventArgs e)
		{
			KeyValuePair<string, object> AllowFilterContext = e.Context.FirstOrDefault(c => c.Key == "AllowFilter");
			bool AllowFilter = false;
			if (AllowFilterContext.Value != null) AllowFilter = Convert.ToBoolean(AllowFilterContext.Value);
		
			KeyValuePair<string, object> IsRefreshContext = e.Context.FirstOrDefault(c => c.Key == "IsRefresh");
			bool IsRefresh = false;
			if (IsRefreshContext.Value != null) IsRefresh = Convert.ToBoolean(IsRefreshContext.Value);
		
			int ItemsCount = Convert.ToInt32(e.Context["ItemsCount"]);
			e.EndOfItems = PageProvider.FillCBFiltroFase(sender as RadComboBox, e.NumberOfItems, e.Text, AllowFilter);
		}
#region CÓDIGO DE USUARIO
		private string Filtrar()
		{
			string filtro = " 1 = 1 ";
			
			if (!string.IsNullOrEmpty(CBFiltroCliente.SelectedValue))
			{
				filtro += " AND CLI_ID = " + CBFiltroCliente.SelectedValue;	
			}

            if (!string.IsNullOrEmpty(CBFiltroStatus.SelectedValue))
            {
                filtro += " AND NEG_STATUS = '" + CBFiltroStatus.SelectedValue + "'";
            }

            if (!string.IsNullOrEmpty(CBFiltroFase.SelectedValue))
            {
                filtro += " AND FASE_ID = " + CBFiltroFase.SelectedValue;
            }

            if (!string.IsNullOrEmpty(CBFiltroProduto.SelectedValue))
            {
                filtro += " AND PROD_ID = " + CBFiltroProduto.SelectedValue;
            }

            return filtro;
		}
#endregion
	}
}

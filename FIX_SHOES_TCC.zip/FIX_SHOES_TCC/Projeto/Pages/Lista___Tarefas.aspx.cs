using System;
using System.Collections;
using System.Collections.Specialized;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Web;
using System.IO;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.Security;
using System.Text.RegularExpressions;
using System.Globalization;
using System.Configuration;
using System.Linq;
using PROJETO;
using COMPONENTS;
using COMPONENTS.Data;
using COMPONENTS.Configuration;
using COMPONENTS.Security;
using PROJETO.DataProviders;
using PROJETO.DataPages;
using Telerik.Web.UI;

namespace PROJETO.DataPages
{
	public partial class Lista___Tarefas : GeneralDataPage
	{
		protected Lista___TarefasPageProvider PageProvider;
	
		public string ATBFiltroField = "";
		public string PAR_EMPRESAField = "";
		public long PAR_FASE1Field = 0;
		public long PAR_FASE2Field = 0;
		public long PAR_FASE3Field = 0;
		public long PAR_FASE4Field = 0;
		public long PAR_FASE5Field = 0;
		
		public override string FormID { get { return "28690"; } }
		public override string TableName { get { return "TB_PARAMETRO"; } }
		public override string DatabaseName { get { return "CRMSSI"; } }
		public override string PageName { get { return "Lista___Tarefas.aspx"; } }
		public override string ProjectID { get { return "1DB2E771"; } }
		public override string TableParameters { get { return "true"; } }
		public override bool PageInsert { get { return false;}}
		public override bool CanEdit { get { return false && UpdateValidation(); }}
		public override bool CanInsert  { get { return false && InsertValidation(); } }
		public override bool CanDelete { get { return false && DeleteValidation(); } }
		public override bool CanView { get { return true; } }
		public override bool OpenInEditMode { get { return false; } }
		



		public override bool AuthenticationRequired { get { return false; } }
		
		public override void CreateProvider()
		{
			PageProvider = new Lista___TarefasPageProvider(this);
		}
		
		private void InitializePageContent()
		{
		}

		/// <summary>
        /// onInit Vamos Carregar o Painel de Ajax e Label de erros da página
        /// </summary>
		protected override void OnInit(EventArgs e)
		{
			AjaxPanel = MainAjaxPanel;
			if (IsPostBack)
			{
				AjaxPanel.ResponseScripts.Add("setTimeout(\"InitializeClient();\",100);");
			}
			if (HttpContext.Current.Request.UrlReferrer == null)
			{
				HttpContext.Current.Response.Redirect(Utility.StartPageName);  
				return;
			}
			if (!PageInsert )
				DisableEnableContros(false);
			this.Load += new EventHandler(PageLoad_SaveOnSession);
			this.Load += new EventHandler(DataPage_Load);

			base.OnInit(e);
		}

		private void PageLoad_SaveOnSession(object sender, EventArgs e)
		{
			if(IsPostBack)
			{
				Session["28690_TBFiltro"] = TBFiltro.Text;
			}
			else
			{
				try { TBFiltro.Text = (Session["28690_TBFiltro"]).ToString(); } catch { }
			}
		}

		
		
		private void StartListControls()
		{
			DataList1Index = new Hashtable();
			PageProvider.DataList1DataListProvider.DataProvider.PrepareSelectCountCommands();
			PageProvider.DataList1DataListProvider.DataProvider.OrderBy = PageProvider.DataList1DataListProvider.DataProvider.Dao.PoeColAspas("ID") + " Asc";
			try
			{
				PageProvider.DataList1DataListProvider.DataProvider.FiltroAtual = Filtrar();
			}
			catch
			{
				PageProvider.DataList1DataListProvider.DataProvider.FiltroAtual = "1 = 2";
			}
			int __DataList1_PageNumber = DataList1_PageNumber;
			DataList1.DataSource = RepeaterPagerControler.ControlPagesButtons(Pager1, 5, 15, ref __DataList1_PageNumber, true, true, PageProvider.DataList1DataListProvider.DataProvider);
			DataList1_PageNumber = __DataList1_PageNumber;
			DataList1.ItemDataBound += new DataListItemEventHandler(DataList1_ItemDataBound);
			DataList1.DataBind();
		}

		public int DataList1_PageNumber
		{
			get
			{
				if (ViewState["DataList1_PageNumber"] != null)
					return (int)ViewState["DataList1_PageNumber"];
				return 0;
			}
			set
			{
				ViewState["DataList1_PageNumber"] = value;
			}
		}

		public void __Pager1__Click(object sender, EventArgs e)
		{
			switch (((Button)sender).CommandArgument.ToUpper())
			{
				case "F":
					DataList1_PageNumber = 0;
					break;
				case "P":
					if(DataList1_PageNumber > 0)
						DataList1_PageNumber--;
					break;
				case "N":
					DataList1_PageNumber++;
					break;
				case "L":
					DataList1_PageNumber = -1;
					break;
				default:
					int Num;
					if (int.TryParse(((Button)sender).CommandArgument, out Num))
					{
						DataList1_PageNumber = Num;
					}
					break;
			}
		}

		public Hashtable DataList1Index
		{
			get
			{
				if (ViewState["DataList1Index"] != null)
				{
					return (Hashtable)ViewState["DataList1Index"];
				}
				return null;
			}
			set
			{
				ViewState["DataList1Index"] = value;
			}
		}

		void DataList1_ItemDataBound(object sender, DataListItemEventArgs e)
		{
			object RowObj = e.Item.DataItem;
			if (RowObj is DataRowView) RowObj = ((DataRowView)RowObj).Row;
			DataRow row = RowObj as DataRow;
			if(row != null)
			{
				DataListProviderSinc(row, null, PageProvider.DataList1DataListProvider.DataProvider);
				DataList1Index[e.Item.UniqueID] = "ID=" + row["ID"].ToString();
			}
			switch (e.Item.ItemType)
			{
				case ListItemType.Item:
				case ListItemType.AlternatingItem:
					if(row != null)
					{
						RadLabel DListCtrLabel4 = e.Item.FindControl("Label4") as RadLabel;
						DListCtrLabel4.Text = row["Tipo"].ToString();
						DListCtrLabel4.Text = DListCtrLabel4.Text.Replace("<", "&lt;").Replace(">", "&gt;");
						RadLabel DListCtrLabel9 = e.Item.FindControl("Label9") as RadLabel;
						DListCtrLabel9.Text = new DateField("",row["Data"].ToString()).GetFormattedValue("dd/MM/yyyy");
						DListCtrLabel9.Text = DListCtrLabel9.Text.Replace("<", "&lt;").Replace(">", "&gt;");
						RadLabel DListCtrLabel7 = e.Item.FindControl("Label7") as RadLabel;
						DListCtrLabel7.Text = row["NEG_TITULO"].ToString();
						DListCtrLabel7.Text = DListCtrLabel7.Text.Replace("<", "&lt;").Replace(">", "&gt;");
						RadLabel DListCtrLabel11 = e.Item.FindControl("Label11") as RadLabel;
						DListCtrLabel11.Text = row["CLI_EMAIL"].ToString();
						DListCtrLabel11.Text = DListCtrLabel11.Text.Replace("<", "&lt;").Replace(">", "&gt;");
						RadLabel DListCtrLabel8 = e.Item.FindControl("Label8") as RadLabel;
						DListCtrLabel8.Text = row["CLI_SKYPE"].ToString();
						DListCtrLabel8.Text = DListCtrLabel8.Text.Replace("<", "&lt;").Replace(">", "&gt;");
						RadLabel DListCtrLabel6 = e.Item.FindControl("Label6") as RadLabel;
						DListCtrLabel6.Text = row["CLI_FONE"].ToString();
						DListCtrLabel6.Text = DListCtrLabel6.Text.Replace("<", "&lt;").Replace(">", "&gt;");
						DListCtrLabel6.Text = Mask.ApplyMask(DListCtrLabel6.Text, "(99) 9999-9999", "TEXT");
						RadLabel DListCtrLabel10 = e.Item.FindControl("Label10") as RadLabel;
						DListCtrLabel10.Text = row["CLI_CELULAR"].ToString();
						DListCtrLabel10.Text = DListCtrLabel10.Text.Replace("<", "&lt;").Replace(">", "&gt;");
						DListCtrLabel10.Text = Mask.ApplyMask(DListCtrLabel10.Text, "(99) 99999-9999", "TEXT");
						RadLabel DListCtrLabel12 = e.Item.FindControl("Label12") as RadLabel;
						DListCtrLabel12.Text = row["CLI_NOME"].ToString();
						DListCtrLabel12.Text = DListCtrLabel12.Text.Replace("<", "&lt;").Replace(">", "&gt;");
						try { (e.Item.FindControl("ImgLigar") as System.Web.UI.WebControls.Image).Style["display"] = VisLigar61262543(row); } catch { }
						try { (e.Item.FindControl("ImgEmail") as System.Web.UI.WebControls.Image).Style["display"] = VisEmail1308188400(row); } catch { }
						try { (e.Item.FindControl("ImgProposta") as System.Web.UI.WebControls.Image).Style["display"] = VisProposta_1267147156(row); } catch { }
						try { (e.Item.FindControl("ImgReuniao") as System.Web.UI.WebControls.Image).Style["display"] = VisReuniao1768710296(row); } catch { }
						try { (e.Item.FindControl("Imgvisita") as System.Web.UI.WebControls.Image).Style["display"] = Visita_277915521(row); } catch { }
						try { (e.Item.FindControl("Image8") as System.Web.UI.WebControls.Image).Style["display"] = uncheck_1084326718(row); } catch { }
						try { (e.Item.FindControl("Image9") as System.Web.UI.WebControls.Image).Style["display"] = Check1385127226(row); } catch { }
					}
					break;
			}
		}

		public override void ResetDataList()
		{
			DataList1_PageNumber = 0;
		}

		/// <summary>
		/// Carrega os objetos de Item de acordo com os controles
		/// </summary>
		public override void UpdateItemFromControl(GeneralDataProviderItem  Item)
		{
			// só vamos permitir a carga dos itens de acordo com os controles de tela caso esteja ocorrendo
			// um postback pois em caso contrário a página está sendo aberta em modo de inclusão/edição
			// e dessa forma não teve alteração de usuário nos dados do formulário
			if (PageState != FormStateEnum.Navigation && this.IsPostBack)
			{
			}
			InitializeAlias(Item);
		}

		/// <summary>
		/// Carrega os objetos de tela para o Item Provider da página
		/// </summary>

		public override GeneralDataProviderItem LoadItemFromControl(bool EnableValidation)
		{
			GeneralDataProviderItem Item = PageProvider.GetDataProviderItem(DataProvider);
			if (PageState != FormStateEnum.Navigation)
			{
			}
			else
			{
				Item = PageProvider.MainProvider.DataProvider.SelectItem(PageNumber, FormPositioningEnum.Current);
			}
			if (EnableValidation)
			{
				InitializeAlias(Item);
				if (PageState == FormStateEnum.Insert)
				{
					FillAuxiliarTables();
				}
				PageProvider.Validate(Item); 
			}
			if (Item!=null) PageErrors.Add(Item.Errors);
			return Item;
		}
		
		public string VisLigar61262543(DataRow row)
		{
			if((string)row["Tipo"] != "Ligação")
			{
				return (bool.Parse(("false").ToString())?"inline-block":"none");
			}
			throw new Exception();
		}
		public string VisEmail1308188400(DataRow row)
		{
			if((string)row["Tipo"] != "Email")
			{
				return (bool.Parse(("false").ToString())?"inline-block":"none");
			}
			throw new Exception();
		}
		public string VisProposta_1267147156(DataRow row)
		{
			if((string)row["Tipo"]  != "Proposta")
			{
				return (bool.Parse(("false").ToString())?"inline-block":"none");
			}
			throw new Exception();
		}
		public string VisReuniao1768710296(DataRow row)
		{
			if((string)row["Tipo"]  != "Reunião")
			{
				return (bool.Parse(("false").ToString())?"inline-block":"none");
			}
			throw new Exception();
		}
		public string Visita_277915521(DataRow row)
		{
			if((string)row["Tipo"]  != "Visita")
			{
				return (bool.Parse(("false").ToString())?"inline-block":"none");
			}
			throw new Exception();
		}
		public string uncheck_1084326718(DataRow row)
		{
			if((bool)row["Finalizado"] != false)
			{
				return (bool.Parse(("false").ToString())?"inline-block":"none");
			}
			throw new Exception();
		}
		public string Check1385127226(DataRow row)
		{
			if((bool)row["Finalizado"]  == false)
			{
				return (bool.Parse(("false").ToString())?"inline-block":"none");
			}
			throw new Exception();
		}

		/// <summary>
		/// Define a Máscara para cada campo na tela
		/// </summary>
		public override void DefineMask()
		{
		}

		public override void DefineStartScripts()
		{
			Utility.SetControlTabOnEnter(TBFiltro);
		}
		
		public override void DisableEnableContros(bool Action)
		{
		}

		/// <summary>
		/// Limpa Campos na tela
		/// </summary>
		public override void ClearFields(bool ShouldClearFields)
		{
			if (ShouldClearFields)
			{
			}
			if (!PageInsert && PageState == FormStateEnum.Navigation)
				DisableEnableContros(false);				
			else
				DisableEnableContros(true);				
		}		

		public override void ShowInitialValues()
		{
			try
			{
				TBFiltro.Text = ("P").ToString();
			}
			catch (Exception e)
			{
			}
		}

		public override void PageEdit()
		{
			DisableEnableContros(true); 
			base.PageEdit(); 
		}

		public override void ShowFormulas()
		{
			Label5.Text = Label5.Text.Replace("<", "&lt;");
			Label5.Text = Label5.Text.Replace(">", "&gt;");
		}
		
		/// <summary>
		/// Define conteudo dos objetos de Tela
		/// </summary>
		public override void DefinePageContent(GeneralDataProviderItem Item)
		{
			ApplyMasks(TBFiltro);
			InitializePageContent();
			base.DefinePageContent(Item);
		}
		
		/// <summary>
		/// Define apelidos da Página
		/// </summary>
		public override void InitializeAlias(GeneralDataProviderItem Item)
        {
			PageProvider.AliasVariables = new Dictionary<string, object>();
			PageProvider.AliasVariables.Clear();
			
			try
			{
				ATBFiltroField = TBFiltro.Text;
			}
			catch
			{
				ATBFiltroField = "";
			}
			try
			{
				PAR_EMPRESAField = Item["PAR_EMPRESA"].GetFormattedValue();
			}
			catch
			{
				PAR_EMPRESAField = "";
			}
			try
			{
				PAR_FASE1Field = long.Parse(Item["PAR_FASE1"].GetFormattedValue(), CultureInfo.CurrentCulture);
			}
			catch
			{
				PAR_FASE1Field = 0;
			}
			try
			{
				PAR_FASE2Field = long.Parse(Item["PAR_FASE2"].GetFormattedValue(), CultureInfo.CurrentCulture);
			}
			catch
			{
				PAR_FASE2Field = 0;
			}
			try
			{
				PAR_FASE3Field = long.Parse(Item["PAR_FASE3"].GetFormattedValue(), CultureInfo.CurrentCulture);
			}
			catch
			{
				PAR_FASE3Field = 0;
			}
			try
			{
				PAR_FASE4Field = long.Parse(Item["PAR_FASE4"].GetFormattedValue(), CultureInfo.CurrentCulture);
			}
			catch
			{
				PAR_FASE4Field = 0;
			}
			try
			{
				PAR_FASE5Field = long.Parse(Item["PAR_FASE5"].GetFormattedValue(), CultureInfo.CurrentCulture);
			}
			catch
			{
				PAR_FASE5Field = 0;
			}
			PageProvider.AliasVariables.Add("ATBFiltroField", ATBFiltroField);
			PageProvider.AliasVariables.Add("PAR_EMPRESAField", PAR_EMPRESAField);
			PageProvider.AliasVariables.Add("PAR_FASE1Field", PAR_FASE1Field);
			PageProvider.AliasVariables.Add("PAR_FASE2Field", PAR_FASE2Field);
			PageProvider.AliasVariables.Add("PAR_FASE3Field", PAR_FASE3Field);
			PageProvider.AliasVariables.Add("PAR_FASE4Field", PAR_FASE4Field);
			PageProvider.AliasVariables.Add("PAR_FASE5Field", PAR_FASE5Field);
			PageProvider.AliasVariables.Add("BasePage", this);
        }

		protected void ___BtnFinalizada_OnClick(object sender, EventArgs e)
		{
			bool ActionSucceeded_1 = true;
			try
			{
				BtnFinalizada_OnClick(sender, e);
			}
			catch (Exception ex)
			{
				ActionSucceeded_1 = false;
				PageErrors.Add("Error", ex.Message);
				ShowErrors();
			}
			bool ActionSucceeded_2 = true;
			try
			{
				if (TBFiltro.Text == "F")
				{
					BtnFinalizada.Style["background-color"] = "#2395DF";
				}
			}
			catch (Exception ex)
			{
				ActionSucceeded_2 = false;
				PageErrors.Add("Error", ex.Message);
				ShowErrors();
			}
			bool ActionSucceeded_3 = true;
			try
			{
				if (TBFiltro.Text == "F")
				{
					BtnPendente.Style["background-color"] = "#C0BFBF";
				}
			}
			catch (Exception ex)
			{
				ActionSucceeded_3 = false;
				PageErrors.Add("Error", ex.Message);
				ShowErrors();
			}
			bool ActionSucceeded_4 = true;
			try
			{
				if (TBFiltro.Text == "F")
				{
					BtnTodas.Style["background-color"] = "#C0BFBF";
				}
			}
			catch (Exception ex)
			{
				ActionSucceeded_4 = false;
				PageErrors.Add("Error", ex.Message);
				ShowErrors();
			}
		}

		protected void ___BtnTodas_OnClick(object sender, EventArgs e)
		{
			bool ActionSucceeded_1 = true;
			try
			{
				BtnTodas_OnClick(sender, e);
			}
			catch (Exception ex)
			{
				ActionSucceeded_1 = false;
				PageErrors.Add("Error", ex.Message);
				ShowErrors();
			}
			bool ActionSucceeded_2 = true;
			try
			{
				if (TBFiltro.Text == "T")
				{
					BtnTodas.Style["background-color"] = "#2395DF";
				}
			}
			catch (Exception ex)
			{
				ActionSucceeded_2 = false;
				PageErrors.Add("Error", ex.Message);
				ShowErrors();
			}
			bool ActionSucceeded_3 = true;
			try
			{
				if (TBFiltro.Text == "T")
				{
					BtnPendente.Style["background-color"] = "#C0BFBF";
				}
			}
			catch (Exception ex)
			{
				ActionSucceeded_3 = false;
				PageErrors.Add("Error", ex.Message);
				ShowErrors();
			}
			bool ActionSucceeded_4 = true;
			try
			{
				if (TBFiltro.Text == "T")
				{
					BtnFinalizada.Style["background-color"] = "#C0BFBF";
				}
			}
			catch (Exception ex)
			{
				ActionSucceeded_4 = false;
				PageErrors.Add("Error", ex.Message);
				ShowErrors();
			}
		}

		protected void ___BtnPendente_OnClick(object sender, EventArgs e)
		{
			bool ActionSucceeded_1 = true;
			try
			{
				BtnPendente_OnClick(sender, e);
			}
			catch (Exception ex)
			{
				ActionSucceeded_1 = false;
				PageErrors.Add("Error", ex.Message);
				ShowErrors();
			}
			bool ActionSucceeded_2 = true;
			try
			{
				if (TBFiltro.Text == "P")
				{
					BtnPendente.Style["background-color"] = "#2395DF";
				}
			}
			catch (Exception ex)
			{
				ActionSucceeded_2 = false;
				PageErrors.Add("Error", ex.Message);
				ShowErrors();
			}
			bool ActionSucceeded_3 = true;
			try
			{
				if (TBFiltro.Text == "P")
				{
					BtnFinalizada.Style["background-color"] = "#C0BFBF";
				}
			}
			catch (Exception ex)
			{
				ActionSucceeded_3 = false;
				PageErrors.Add("Error", ex.Message);
				ShowErrors();
			}
			bool ActionSucceeded_4 = true;
			try
			{
				if (TBFiltro.Text == "P")
				{
					BtnTodas.Style["background-color"] = "#C0BFBF";
				}
			}
			catch (Exception ex)
			{
				ActionSucceeded_4 = false;
				PageErrors.Add("Error", ex.Message);
				ShowErrors();
			}
		}

		protected void ___Button7_OnClick(object sender, EventArgs e)
		{
			bool ActionSucceeded_1 = true;
			try
			{
				TarefaFinalizarProcessProvider PreDefProvider = new TarefaFinalizarProcessProvider(this);
				PreDefProvider.AliasVariables = new Dictionary<string, object>();
				PreDefProvider.AliasVariables.Clear();
				PreDefProvider.AliasVariables.Add("ParTarefaID", Convert.ToString(PageProvider.DataList1DataListProvider.DataProvider.Item["ID"].GetValue()));
				PreDefProvider.ExecutePreDefinedProcess();
			}
			catch (Exception ex)
			{
				ActionSucceeded_1 = false;
				PageErrors.Add("Error", ex.Message);
				ShowErrors();
			}
		}

		protected void ___Button5_OnClick(object sender, EventArgs e)
		{
			bool ActionSucceeded_1 = true;
			try
			{
				string UrlPage = ResolveUrl("~/Pages/Tarefas.aspx");
				UrlPage += '?' + "ParTarID=" + (Convert.ToString(PageProvider.DataList1DataListProvider.DataProvider.Item["ID"].GetValue())).ToString();
				UrlPage += '&' + "Par_neg=";
				try
				{
					if (!IsPostBack)
					{
						ClientScript.RegisterStartupScript(this.GetType(), "OnClick_GWindow", "<script>NavigateTargetByReference('" + UrlPage + "','GWindow', { Modal: true, Center: true });</script>");
					}
					else
					{
						AjaxPanel.ResponseScripts.Add("NavigateTargetByReference('" + UrlPage + "','GWindow', { Modal: true, Center: true });");
					}
				}
				catch(Exception ex)
				{
				}
			}
			catch (Exception ex)
			{
				ActionSucceeded_1 = false;
				PageErrors.Add("Error", ex.Message);
				ShowErrors();
			}
		}

		protected void ___Button9_OnClick(object sender, EventArgs e)
		{
			bool ActionSucceeded_1 = true;
			try
			{
				string UrlPage = ResolveUrl("~/Pages/Detalhe_da_Tarefa.aspx");
				UrlPage += '?' + "ParID=" + (Convert.ToString(PageProvider.DataList1DataListProvider.DataProvider.Item["ID"].GetValue())).ToString();
				try
				{
					if (!IsPostBack)
					{
						ClientScript.RegisterStartupScript(this.GetType(), "OnClick_GWindow", "<script>NavigateTargetByReference('" + UrlPage + "','GWindow', { Modal: true, Center: true });</script>");
					}
					else
					{
						AjaxPanel.ResponseScripts.Add("NavigateTargetByReference('" + UrlPage + "','GWindow', { Modal: true, Center: true });");
					}
				}
				catch(Exception ex)
				{
				}
			}
			catch (Exception ex)
			{
				ActionSucceeded_1 = false;
				PageErrors.Add("Error", ex.Message);
				ShowErrors();
			}
		}

		protected void ___Button2_OnClick(object sender, EventArgs e)
		{
			bool ActionSucceeded_1 = true;
			try
			{
				string UrlPage = ResolveUrl("~/Pages/Cadastro_Cliente.aspx");
				UrlPage += '?' + "Par_IDCliente=";
				try
				{
					if (!IsPostBack)
					{
						ClientScript.RegisterStartupScript(this.GetType(), "OnClick_GWindow", "<script>NavigateTargetByReference('" + UrlPage + "','GWindow', { Modal: true, Center: true });</script>");
					}
					else
					{
						AjaxPanel.ResponseScripts.Add("NavigateTargetByReference('" + UrlPage + "','GWindow', { Modal: true, Center: true });");
					}
				}
				catch(Exception ex)
				{
				}
			}
			catch (Exception ex)
			{
				ActionSucceeded_1 = false;
				PageErrors.Add("Error", ex.Message);
				ShowErrors();
			}
		}

		protected void ___Button4_OnClick(object sender, EventArgs e)
		{
			bool ActionSucceeded_1 = true;
			try
			{
				string UrlPage = ResolveUrl("~/Pages/Neg_cio.aspx");
				UrlPage += '?' + "Par_NegID=";
				try
				{
					if (!IsPostBack)
					{
						ClientScript.RegisterStartupScript(this.GetType(), "OnClick_GWindow", "<script>NavigateTargetByReference('" + UrlPage + "','GWindow', { Modal: true, Center: true });</script>");
					}
					else
					{
						AjaxPanel.ResponseScripts.Add("NavigateTargetByReference('" + UrlPage + "','GWindow', { Modal: true, Center: true });");
					}
				}
				catch(Exception ex)
				{
				}
			}
			catch (Exception ex)
			{
				ActionSucceeded_1 = false;
				PageErrors.Add("Error", ex.Message);
				ShowErrors();
			}
		}

		protected void ___Button8_OnClick(object sender, EventArgs e)
		{
			bool ActionSucceeded_1 = true;
			try
			{
				string UrlPage = ResolveUrl("~/Pages/Tarefas.aspx");
				UrlPage += '?' + "ParTarID=";
				try
				{
					if (!IsPostBack)
					{
						ClientScript.RegisterStartupScript(this.GetType(), "OnClick_GWindow", "<script>NavigateTargetByReference('" + UrlPage + "','GWindow', { Modal: true, Center: true });</script>");
					}
					else
					{
						AjaxPanel.ResponseScripts.Add("NavigateTargetByReference('" + UrlPage + "','GWindow', { Modal: true, Center: true });");
					}
				}
				catch(Exception ex)
				{
				}
			}
			catch (Exception ex)
			{
				ActionSucceeded_1 = false;
				PageErrors.Add("Error", ex.Message);
				ShowErrors();
			}
		}

		protected override void OnLoadComplete(EventArgs e)
		{
			StartListControls();
			base.OnLoadComplete(e);
		}

        public void DataListProviderSinc(object LineIndex, Hashtable Repeaterindex, GeneralDataProvider Provider)
		{
            if (LineIndex is DataRow)
            {
                Provider.LocateRecordByRow((DataRow)LineIndex);
            }
            else
            {
				if (Repeaterindex.Count > 0 && Repeaterindex.ContainsKey(LineIndex))
                {
					Dictionary<string, object> Values = new Dictionary<string, object>();
					string[] splittedVals = Repeaterindex[LineIndex].ToString().Split('§');
					foreach (string Val in splittedVals)
					{
						Values.Add(Val.Substring(0, Val.IndexOf("=")), Val.Substring(Val.IndexOf("=") + 1));
					}
					Provider.FindRecord(Values);
				}
            }
		}


		private void DataPage_Load(object sender, EventArgs e)
		{
			if (IsPostBack)
			{
				string EventTarget = Request["__EVENTTARGET"];
                int End = EventTarget.LastIndexOf("$");
                
                if (End == -1)
                {
                    EventTarget = Request["__EVENTARGUMENT"];
                    int Start  = EventTarget.LastIndexOf("|TargetControl:");
                    
                    if (Start > -1 )
                    {
                        End = (EventTarget.IndexOf("|", Start + 1) > -1 ? EventTarget.IndexOf("|"):(EventTarget.Length - 15) - Start);
                        EventTarget = EventTarget.Substring(Start + 15, End);
                    }
                }
				
				string[] TargetParts = EventTarget.Split(':');
				int DataList1Pos = EventTarget.LastIndexOf("$");
				if (EventTarget.StartsWith("DataList1$") && DataList1Pos != -1)
				{
					string DataList1ClientID = EventTarget.Substring(0, DataList1Pos);
					DataListProviderSinc(DataList1ClientID, DataList1Index, PageProvider.DataList1DataListProvider.DataProvider);
				}
			}
		}


		public override void ExecuteServerCommandRequest(string CommandName, string TargetName, string[] Parameters)
		{
			ExecuteLocalCommandRequest(CommandName, TargetName, Parameters);
		}		





		public override GeneralDataProviderItem GetDataProviderItem(GeneralDataProvider Provider)
		{
			if (Provider.Name == "ProcFinalizar")
			{
				return new CRMSSI_TB_TAREFAItem("CRMSSI");
			}
			if (Provider.Name == "ProcFinalizar")
			{
				return new CRMSSI_TB_TAREFAItem("CRMSSI");
			}
			return base.GetDataProviderItem(Provider);
		}
		
#region CÓDIGO DE USUARIO
		private string Filtrar()
		{
			string filtro = " 1 = 1 ";
			
			if (TBFiltro.Text == "P" || TBFiltro.Text == "")
			{
				filtro += "AND FINALIZADO = false ";	
			}

            if (TBFiltro.Text == "F")
            {
                filtro += "AND FINALIZADO = true ";
            }
            return filtro;
		}
		protected void BtnPendente_OnClick(object sender, EventArgs e)
		{
			TBFiltro.Text = "P";
		}

		protected void BtnTodas_OnClick(object sender, EventArgs e)
		{
			TBFiltro.Text = "T";
		}

		protected void BtnFinalizada_OnClick(object sender, EventArgs e)
		{
			TBFiltro.Text = "F";
		}
#endregion
	}
}

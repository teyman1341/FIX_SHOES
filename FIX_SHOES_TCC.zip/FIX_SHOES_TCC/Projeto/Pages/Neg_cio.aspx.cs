using System;
using System.Collections;
using System.Collections.Specialized;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Web;
using System.IO;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.Security;
using System.Text.RegularExpressions;
using System.Globalization;
using System.Configuration;
using System.Linq;
using PROJETO;
using COMPONENTS;
using COMPONENTS.Data;
using COMPONENTS.Configuration;
using COMPONENTS.Security;
using PROJETO.DataProviders;
using PROJETO.DataPages;
using Telerik.Web.UI;

namespace PROJETO.DataPages
{
	public partial class Neg_cio : GeneralDataPage
	{
		protected Neg_cioPageProvider PageProvider;
	
		public string NEG_MOTIVOPERDAField = "";
		public string NEG_COMENTARIO_PERDAField = "";
		public long CLI_IDField = 0;
		public string NEG_TITULOField = "";
		public string NEG_RESPONSAVELField = "";
		public DateTime ? NEG_DATAINICIALField;
		public DateTime ? NEG_DATACONCLUSAOField;
		public long PROD_IDField = 0;
		public double NEG_VALORTOTALField = 0;
		public double NEG_VALORULTField = 0;
		public string NEG_CORPOPROPField = "";
		public long NEG_IDField = 0;
		public string NEG_DESCRICAOField = "";
		public string NEG_STATUSField = "";
		public long FASE_IDField = 0;
		public long FASE_PARField = 0;
		
		public override string FormID { get { return "28712"; } }
		public override string TableName { get { return "TB_NEGOCIO"; } }
		public override string DatabaseName { get { return "CRMSSI"; } }
		public override string PageName { get { return "Neg_cio.aspx"; } }
		public override string ProjectID { get { return "1DB2E771"; } }
		public override string TableParameters { get { return "false"; } }
		public override bool PageInsert { get { return true;}}
		public override bool CanEdit { get { return true && UpdateValidation(); }}
		public override bool CanInsert  { get { return true && InsertValidation(); } }
		public override bool CanDelete { get { return true && DeleteValidation(); } }
		public override bool CanView { get { return true; } }
		public override bool OpenInEditMode { get { return true; } }
		


		public string Par_NegID = "";

		public override void SetStartFilter()
		{
			try
			{
				if (!String.IsNullOrEmpty(Par_NegID))
				{
					PageProvider.MainProvider.DataProvider.StartFilter = Dao.PoeColAspas("NEG_ID") + " = " + Dao.ToSql(Par_NegID.ToString(), FieldType.Integer);
				}
				else
				{
					PageProvider.MainProvider.DataProvider.StartFilter = "1 = 2";
				}
			}
			catch
			{
				PageProvider.MainProvider.DataProvider.StartFilter = "1 = 2";
			}
		}
		
		public override void CreateProvider()
		{
			PageProvider = new Neg_cioPageProvider(this);
		}
		
		private void InitializePageContent()
		{
		}

		public override void GridRebind()
		{
			Grid1.CurrentPageIndex = 0;
			Grid1.DataSource = null;
			Grid1.Rebind();
		}

		/// <summary>
        /// onInit Vamos Carregar o Painel de Ajax e Label de erros da página
        /// </summary>
		protected override void OnInit(EventArgs e)
		{
			Par_NegID = HttpContext.Current.Request.QueryString["Par_NegID"];
			try { if (string.IsNullOrEmpty(Par_NegID)) Par_NegID = HttpContext.Current.Session["Par_NegID"].ToString();} catch {} 
			if (string.IsNullOrEmpty(Par_NegID)) Par_NegID = "0";
			AjaxPanel = MainAjaxPanel;
			if (IsPostBack)
			{
				AjaxPanel.ResponseScripts.Add("setTimeout(\"InitializeClient();\",100);");
			}
			AjaxPanel.ResponseScripts.Add("setTimeout(\"RegisterClientValidateScript();\",100);");
			ErrorLabel = labError;
			if (!PageInsert )
				DisableEnableContros(false);

			base.OnInit(e);
		}
		

		/// <summary>
		/// Define os Parâmetros para acesso às tabelas auxiliares
		/// </summary>
		public override void SetParametersValues(GeneralDataProvider Provider)
		{
			try
			{
				if (Provider == PageProvider.PAR_FASE1Provider && Provider.IndexName == "PK_FASE")
				{
						Provider.Parameters["FASE_ID"].Parameter.SetValue(EnvironmentVariable.CRMSSI.TB_PARAMETRO.PAR_FASE1);
				}
				if (Provider == PageProvider.PAR_FASE2Provider && Provider.IndexName == "PK_FASE")
				{
						Provider.Parameters["FASE_ID"].Parameter.SetValue(EnvironmentVariable.CRMSSI.TB_PARAMETRO.PAR_FASE2);
				}
				if (Provider == PageProvider.PAR_FASE3Provider && Provider.IndexName == "PK_FASE")
				{
						Provider.Parameters["FASE_ID"].Parameter.SetValue(EnvironmentVariable.CRMSSI.TB_PARAMETRO.PAR_FASE3);
				}
				if (Provider == PageProvider.PAR_FASE4Provider && Provider.IndexName == "PK_FASE")
				{
						Provider.Parameters["FASE_ID"].Parameter.SetValue(EnvironmentVariable.CRMSSI.TB_PARAMETRO.PAR_FASE4);
				}
				if (Provider == PageProvider.PAR_FASE5Provider && Provider.IndexName == "PK_FASE")
				{
						Provider.Parameters["FASE_ID"].Parameter.SetValue(EnvironmentVariable.CRMSSI.TB_PARAMETRO.PAR_FASE5);
				}
				if (Provider == PageProvider.AUX_Neg_cio_TB_CLIENTEProvider && Provider.IndexName == "PK_TB_CLIENTE")
				{
						Provider.Parameters["CLI_ID"].Parameter.SetValue(CLI_IDField);
				}
			}
			catch
			{
			}
		}

		/// <summary>
		/// Carrega os objetos de Item de acordo com os controles
		/// </summary>
		public override void UpdateItemFromControl(GeneralDataProviderItem  Item)
		{
			// só vamos permitir a carga dos itens de acordo com os controles de tela caso esteja ocorrendo
			// um postback pois em caso contrário a página está sendo aberta em modo de inclusão/edição
			// e dessa forma não teve alteração de usuário nos dados do formulário
			if (PageState != FormStateEnum.Navigation && this.IsPostBack)
			{
				Item.SetFieldValue(Item["NEG_MOTIVOPERDA"], ComboBox4.SelectedValue);
				Item.SetFieldValue(Item["NEG_COMENTARIO_PERDA"], RadTextBox11.Text, false);
				Item.SetFieldValue(Item["CLI_ID"], ComboBox1.SelectedValue);
				Item.SetFieldValue(Item["NEG_TITULO"], RadTextBox1.Text, false);
				Item.SetFieldValue(Item["NEG_RESPONSAVEL"], ComboBox2.SelectedValue);
				if (DatePicker1.SelectedDate != null) Item.SetFieldValue(Item["NEG_DATAINICIAL"], DatePicker1.SelectedDate.Value.ToString("dd/MM/yyyy"));
				else Item.SetFieldValue(Item["NEG_DATAINICIAL"], DBNull.Value);
				if (DatePicker2.SelectedDate != null) Item.SetFieldValue(Item["NEG_DATACONCLUSAO"], DatePicker2.SelectedDate.Value.ToString("dd/MM/yyyy"));
				else Item.SetFieldValue(Item["NEG_DATACONCLUSAO"], DBNull.Value);
				Item.SetFieldValue(Item["PROD_ID"], ComboBox5.SelectedValue);
				Item.SetFieldValue(Item["NEG_VALORTOTAL"], RadTextBox5.Text, false);
				Item.SetFieldValue(Item["NEG_VALORULT"], RadTextBox9.Text, false);
				Item.SetFieldValue(Item["NEG_CORPOPROP"], GEditor1.Content, true);
			}
			InitializeAlias(Item);
		}

		/// <summary>
		/// Carrega os objetos de tela para o Item Provider da página
		/// </summary>

		public override GeneralDataProviderItem LoadItemFromControl(bool EnableValidation)
		{
			GeneralDataProviderItem Item = PageProvider.GetDataProviderItem(DataProvider);
			if (PageState != FormStateEnum.Navigation)
			{
				Item.SetFieldValue(Item["NEG_MOTIVOPERDA"], ComboBox4.SelectedValue);
				Item.SetFieldValue(Item["NEG_COMENTARIO_PERDA"], RadTextBox11.Text, false);
				Item.SetFieldValue(Item["CLI_ID"], ComboBox1.SelectedValue);
				Item.SetFieldValue(Item["NEG_TITULO"], RadTextBox1.Text, false);
				Item.SetFieldValue(Item["NEG_RESPONSAVEL"], ComboBox2.SelectedValue);
				if (DatePicker1.SelectedDate != null) Item.SetFieldValue(Item["NEG_DATAINICIAL"], DatePicker1.SelectedDate.Value.ToString("dd/MM/yyyy"));
				else Item.SetFieldValue(Item["NEG_DATAINICIAL"], DBNull.Value);
				if (DatePicker2.SelectedDate != null) Item.SetFieldValue(Item["NEG_DATACONCLUSAO"], DatePicker2.SelectedDate.Value.ToString("dd/MM/yyyy"));
				else Item.SetFieldValue(Item["NEG_DATACONCLUSAO"], DBNull.Value);
				Item.SetFieldValue(Item["PROD_ID"], ComboBox5.SelectedValue);
				Item.SetFieldValue(Item["NEG_VALORTOTAL"], RadTextBox5.Text, false);
				Item.SetFieldValue(Item["NEG_VALORULT"], RadTextBox9.Text, false);
				Item.SetFieldValue(Item["NEG_CORPOPROP"], GEditor1.Content, true);
			}
			else
			{
				Item = PageProvider.MainProvider.DataProvider.SelectItem(PageNumber, FormPositioningEnum.Current);
			}
			if (EnableValidation)
			{
				InitializeAlias(Item);
				if (PageState == FormStateEnum.Insert)
				{
					FillAuxiliarTables();
				}
				PageProvider.Validate(Item); 
			}
			if (Item!=null) PageErrors.Add(Item.Errors);
			return Item;
		}
		

		/// <summary>
		/// Define a Máscara para cada campo na tela
		/// </summary>
		public override void DefineMask()
		{
			Mask.SetMask(DatePicker1.DateInput, "99/99/9999", 10, false);
			Mask.SetMask(DatePicker2.DateInput, "99/99/9999", 10, false);
			Mask.SetMask(RadTextBox5, "99999999,99", 11, true);
			Mask.SetMask(RadTextBox9, "99999999,99", 11, true);
		}

		public override void DefineStartScripts()
		{
			Utility.SetControlTabOnEnter(ComboBox4);
			Utility.SetControlTabOnEnter(RadTextBox11);
			Utility.SetControlTabOnEnter(ComboBox1);
			Utility.SetControlTabOnEnter(RadTextBox1);
			Utility.SetControlTabOnEnter(ComboBox2);
			Utility.SetControlTabOnEnter(ComboBox5);
			Utility.SetControlTabOnEnter(RadTextBox15);
		}
		
		public override void DisableEnableContros(bool Action)
		{
			ComboBox4.Attributes.Add("EnableEdit", "True");
			RadTextBox11.Attributes.Add("EnableEdit", "True");
			ComboBox1.Attributes.Add("EnableEdit", "True");
			RadTextBox1.Attributes.Add("EnableEdit", "True");
			ComboBox2.Attributes.Add("EnableEdit", "True");
			DatePicker1.Attributes.Add("EnableEdit", "True");
			DatePicker2.Attributes.Add("EnableEdit", "True");
			ComboBox5.Attributes.Add("EnableEdit", "True");
			RadTextBox5.Attributes.Add("EnableEdit", "True");
			RadTextBox9.Attributes.Add("EnableEdit", "True");
			GEditor1.Attributes.Add("EnableEdit", "True");
		}

		/// <summary>
		/// Limpa Campos na tela
		/// </summary>
		public override void ClearFields(bool ShouldClearFields)
		{
			if (ShouldClearFields)
			{
				ComboBox4.SelectedIndex = -1;
				ComboBox4.Text = "";
				RadTextBox11.Text = "";
				ComboBox1.SelectedIndex = -1;
				ComboBox1.Text = "";
				RadTextBox1.Text = "";
				ComboBox2.SelectedIndex = -1;
				ComboBox2.Text = "";
				DatePicker1.SelectedDate = null;
				DatePicker2.SelectedDate = null;
				ComboBox5.SelectedIndex = -1;
				ComboBox5.Text = "";
				RadTextBox5.Text = "";
				RadTextBox9.Text = "";
				GEditor1.Content = "";
			}
			if (!PageInsert && PageState == FormStateEnum.Navigation)
				DisableEnableContros(false);				
			else
				DisableEnableContros(true);				
		}		

		public override void ShowInitialValues()
		{
			DatePicker1.SelectedDate = DateTime.Parse(EnvironmentVariable.ActualDate.ToString("dd/MM/yyyy"));
			DatePicker2.SelectedDate = null;
		}

		public override void PageEdit()
		{
			base.PageEdit(); 
		}

		public override void ShowFormulas()
		{
			Label1.Text = Label1.Text.Replace("<", "&lt;");
			Label1.Text = Label1.Text.Replace(">", "&gt;");
			try { BtnFase1.Text = (PageProvider.PAR_FASE1Provider["FASE_NOME"].GetFormattedValue()).ToString(); }
			catch { BtnFase1.Text = ""; }
			try { BtnFase2.Text = (PageProvider.PAR_FASE2Provider["FASE_NOME"].GetFormattedValue()).ToString(); }
			catch { BtnFase2.Text = ""; }
			try { BtnFase3.Text = (PageProvider.PAR_FASE3Provider["FASE_NOME"].GetFormattedValue()).ToString(); }
			catch { BtnFase3.Text = ""; }
			try { BtnFase4.Text = (PageProvider.PAR_FASE4Provider["FASE_NOME"].GetFormattedValue()).ToString(); }
			catch { BtnFase4.Text = ""; }
			try { BtnFase5.Text = (PageProvider.PAR_FASE5Provider["FASE_NOME"].GetFormattedValue()).ToString(); }
			catch { BtnFase5.Text = ""; }
			Label11.Text = Label11.Text.Replace("<", "&lt;");
			Label11.Text = Label11.Text.Replace(">", "&gt;");
			Label14.Text = Label14.Text.Replace("<", "&lt;");
			Label14.Text = Label14.Text.Replace(">", "&gt;");
			Label3.Text = Label3.Text.Replace("<", "&lt;");
			Label3.Text = Label3.Text.Replace(">", "&gt;");
			Label22.Text = Label22.Text.Replace("<", "&lt;");
			Label22.Text = Label22.Text.Replace(">", "&gt;");
			Label23.Text = Label23.Text.Replace("<", "&lt;");
			Label23.Text = Label23.Text.Replace(">", "&gt;");
			Label24.Text = Label24.Text.Replace("<", "&lt;");
			Label24.Text = Label24.Text.Replace(">", "&gt;");
			Label26.Text = Label26.Text.Replace("<", "&lt;");
			Label26.Text = Label26.Text.Replace(">", "&gt;");
			Label27.Text = Label27.Text.Replace("<", "&lt;");
			Label27.Text = Label27.Text.Replace(">", "&gt;");
			try { Label40.Text = (PageProvider.AUX_Neg_cio_TB_CLIENTEProvider["CLI_FONE"].GetFormattedValue()).ToString(); }
			catch { Label40.Text = ""; }
			Label40.Text = Label40.Text.Replace(double.NaN.ToString(), "");
			Label40.Text = Label40.Text.Replace("<", "&lt;");
			Label40.Text = Label40.Text.Replace(">", "&gt;");
			try { Label41.Text = (PageProvider.AUX_Neg_cio_TB_CLIENTEProvider["CLI_CELULAR"].GetFormattedValue()).ToString(); }
			catch { Label41.Text = ""; }
			Label41.Text = Label41.Text.Replace(double.NaN.ToString(), "");
			Label41.Text = Label41.Text.Replace("<", "&lt;");
			Label41.Text = Label41.Text.Replace(">", "&gt;");
			try { Label42.Text = (PageProvider.AUX_Neg_cio_TB_CLIENTEProvider["CLI_EMAIL"].GetFormattedValue()).ToString(); }
			catch { Label42.Text = ""; }
			Label42.Text = Label42.Text.Replace(double.NaN.ToString(), "");
			Label42.Text = Label42.Text.Replace("<", "&lt;");
			Label42.Text = Label42.Text.Replace(">", "&gt;");
			try { Label43.Text = (PageProvider.AUX_Neg_cio_TB_CLIENTEProvider["CLI_SKYPE"].GetFormattedValue()).ToString(); }
			catch { Label43.Text = ""; }
			Label43.Text = Label43.Text.Replace(double.NaN.ToString(), "");
			Label43.Text = Label43.Text.Replace("<", "&lt;");
			Label43.Text = Label43.Text.Replace(">", "&gt;");
			Label25.Text = Label25.Text.Replace("<", "&lt;");
			Label25.Text = Label25.Text.Replace(">", "&gt;");
			try { Label44.Text = (PageProvider.AUX_Neg_cio_TB_CLIENTEProvider["CLI_CONTATO"].GetFormattedValue()).ToString(); }
			catch { Label44.Text = ""; }
			Label44.Text = Label44.Text.Replace(double.NaN.ToString(), "");
			Label44.Text = Label44.Text.Replace("<", "&lt;");
			Label44.Text = Label44.Text.Replace(">", "&gt;");
			Label2.Text = Label2.Text.Replace("<", "&lt;");
			Label2.Text = Label2.Text.Replace(">", "&gt;");
			Label5.Text = Label5.Text.Replace("<", "&lt;");
			Label5.Text = Label5.Text.Replace(">", "&gt;");
			Label7.Text = Label7.Text.Replace("<", "&lt;");
			Label7.Text = Label7.Text.Replace(">", "&gt;");
			Label9.Text = Label9.Text.Replace("<", "&lt;");
			Label9.Text = Label9.Text.Replace(">", "&gt;");
			Label15.Text = Label15.Text.Replace("<", "&lt;");
			Label15.Text = Label15.Text.Replace(">", "&gt;");
			Label6.Text = Label6.Text.Replace("<", "&lt;");
			Label6.Text = Label6.Text.Replace(">", "&gt;");
			Label8.Text = Label8.Text.Replace("<", "&lt;");
			Label8.Text = Label8.Text.Replace(">", "&gt;");
			Label13.Text = Label13.Text.Replace("<", "&lt;");
			Label13.Text = Label13.Text.Replace(">", "&gt;");
			Label45.Text = Label45.Text.Replace("<", "&lt;");
			Label45.Text = Label45.Text.Replace(">", "&gt;");
		}
		
		/// <summary>
		/// Define conteudo dos objetos de Tela
		/// </summary>
		public override void DefinePageContent(GeneralDataProviderItem Item)
		{
			try
			{
				string Val = Item["NEG_MOTIVOPERDA"].GetFormattedValue();
				if (ComboBox4.Items.Count == 0)
				{
					RadComboBoxDataItem item = Utility.FindComboBoxItem(PageProvider.ComboBox4Items, Val);
					ComboBox4.Text = item.Text;
					ComboBox4.SelectedValue = item.Value;
					ComboBox4.Attributes.Add("AllowFilter", "False");
				}
			}
			catch
			{
				ComboBox4.SelectedValue = "";
				ComboBox4.Text = "";
			}
			try { RadTextBox11.Text = Item["NEG_COMENTARIO_PERDA"].GetFormattedValue(); }
			catch { RadTextBox11.Text = ""; }
			try
			{
				string Val = Item["CLI_ID"].GetFormattedValue();
				if (ComboBox1.Items.Count == 0)
				{
					DataRow row = PageProvider.ComboBox1_GetComboItem(Val);
					ComboBox1.Text = row["DISPLAY_FIELD"].ToString();
					ComboBox1.SelectedValue = row["CLI_ID"].ToString();
					ComboBox1.Attributes.Add("AllowFilter", "False");
				}
			}
			catch
			{
				ComboBox1.SelectedValue = "";
				ComboBox1.Text = "";
			}
			try { RadTextBox1.Text = Item["NEG_TITULO"].GetFormattedValue(); }
			catch { RadTextBox1.Text = ""; }
			try
			{
				string Val = Item["NEG_RESPONSAVEL"].GetFormattedValue();
				if (ComboBox2.Items.Count == 0)
				{
					ComboBox2.Attributes["Encrypt"] = "False";
					DataRow row = PageProvider.ComboBox2_GetComboItem(Val);
					ComboBox2.Text = Crypt.Decripta(row["DISPLAY_FIELD"].ToString());
					ComboBox2.SelectedValue = row["LOGIN_USER_LOGIN"].ToString();
					ComboBox2.Attributes.Add("AllowFilter", "False");
				}
			}
			catch
			{
				ComboBox2.SelectedValue = "";
				ComboBox2.Text = "";
			}
			try { DatePicker1.SelectedDate = Convert.ToDateTime(Item["NEG_DATAINICIAL"].GetFormattedValue("dd/MM/yyyy")); }
			catch { DatePicker1.SelectedDate = null; }
			try { DatePicker2.SelectedDate = Convert.ToDateTime(Item["NEG_DATACONCLUSAO"].GetFormattedValue("dd/MM/yyyy")); }
			catch { DatePicker2.SelectedDate = null; }
			try
			{
				string Val = Item["PROD_ID"].GetFormattedValue();
				if (ComboBox5.Items.Count == 0)
				{
					DataRow row = PageProvider.ComboBox5_GetComboItem(Val);
					ComboBox5.Text = row["DISPLAY_FIELD"].ToString();
					ComboBox5.SelectedValue = row["PROD_ID"].ToString();
					ComboBox5.Attributes.Add("AllowFilter", "False");
				}
			}
			catch
			{
				ComboBox5.SelectedValue = "";
				ComboBox5.Text = "";
			}
			try { RadTextBox5.Text = Item["NEG_VALORTOTAL"].GetFormattedValue().Replace(".",","); }
			catch { RadTextBox5.Text = ""; }
			try { RadTextBox9.Text = Item["NEG_VALORULT"].GetFormattedValue().Replace(".",","); }
			catch { RadTextBox9.Text = ""; }
			try { GEditor1.Content = Item["NEG_CORPOPROP"].GetFormattedValue(); }
			catch { GEditor1.Content = ""; }
			ApplyMasks(RadTextBox11);
			ApplyMasks(RadTextBox1);
			ApplyMasks(DatePicker1);
			ApplyMasks(DatePicker2);
			ApplyMasks(RadTextBox5);
			ApplyMasks(RadTextBox9);
			ApplyMasks(RadTextBox15);
			InitializePageContent();
			base.DefinePageContent(Item);
		}
		
		/// <summary>
		/// Define apelidos da Página
		/// </summary>
		public override void InitializeAlias(GeneralDataProviderItem Item)
        {
			PageProvider.AliasVariables = new Dictionary<string, object>();
			PageProvider.AliasVariables.Clear();
			
			try
			{
				NEG_MOTIVOPERDAField = Item["NEG_MOTIVOPERDA"].GetFormattedValue();
			}
			catch
			{
				NEG_MOTIVOPERDAField = "";
			}
			try
			{
				NEG_COMENTARIO_PERDAField = Item["NEG_COMENTARIO_PERDA"].GetFormattedValue();
			}
			catch
			{
				NEG_COMENTARIO_PERDAField = "";
			}
			try
			{
				CLI_IDField = long.Parse(Item["CLI_ID"].GetFormattedValue());
			}
			catch
			{
				CLI_IDField = 0;
			}
			try
			{
				NEG_TITULOField = Item["NEG_TITULO"].GetFormattedValue();
			}
			catch
			{
				NEG_TITULOField = "";
			}
			try
			{
				NEG_RESPONSAVELField = Item["NEG_RESPONSAVEL"].GetFormattedValue();
			}
			catch
			{
				NEG_RESPONSAVELField = "";
			}
			try
			{
				NEG_DATAINICIALField = Convert.ToDateTime(Item["NEG_DATAINICIAL"].GetFormattedValue("dd/MM/yyyy"));
			}
			catch
			{
				NEG_DATAINICIALField = null;
			}
			try
			{
				NEG_DATACONCLUSAOField = Convert.ToDateTime(Item["NEG_DATACONCLUSAO"].GetFormattedValue("dd/MM/yyyy"));
			}
			catch
			{
				NEG_DATACONCLUSAOField = null;
			}
			try
			{
				PROD_IDField = long.Parse(Item["PROD_ID"].GetFormattedValue());
			}
			catch
			{
				PROD_IDField = 0;
			}
			try
			{
				NEG_VALORTOTALField = double.Parse(Item["NEG_VALORTOTAL"].GetFormattedValue().Replace(".",","));
			}
			catch
			{
				NEG_VALORTOTALField = 0;
			}
			try
			{
				NEG_VALORULTField = double.Parse(Item["NEG_VALORULT"].GetFormattedValue().Replace(".",","));
			}
			catch
			{
				NEG_VALORULTField = 0;
			}
			try
			{
				NEG_CORPOPROPField = Item["NEG_CORPOPROP"].GetFormattedValue();
			}
			catch
			{
				NEG_CORPOPROPField = "";
			}
			try
			{
				NEG_IDField = long.Parse(Item["NEG_ID"].GetFormattedValue(), CultureInfo.CurrentCulture);
			}
			catch
			{
				NEG_IDField = 0;
			}
			try
			{
				NEG_DESCRICAOField = Item["NEG_DESCRICAO"].GetFormattedValue();
			}
			catch
			{
				NEG_DESCRICAOField = "";
			}
			try
			{
				NEG_STATUSField = Item["NEG_STATUS"].GetFormattedValue();
			}
			catch
			{
				NEG_STATUSField = "";
			}
			try
			{
				FASE_IDField = long.Parse(Item["FASE_ID"].GetFormattedValue(), CultureInfo.CurrentCulture);
			}
			catch
			{
				FASE_IDField = 0;
			}
			try
			{
				FASE_PARField = long.Parse(Item["FASE_PAR"].GetFormattedValue(), CultureInfo.CurrentCulture);
			}
			catch
			{
				FASE_PARField = 0;
			}
			PageProvider.AliasVariables.Add("NEG_MOTIVOPERDAField", NEG_MOTIVOPERDAField);
			PageProvider.AliasVariables.Add("NEG_COMENTARIO_PERDAField", NEG_COMENTARIO_PERDAField);
			PageProvider.AliasVariables.Add("CLI_IDField", CLI_IDField);
			PageProvider.AliasVariables.Add("NEG_TITULOField", NEG_TITULOField);
			PageProvider.AliasVariables.Add("NEG_RESPONSAVELField", NEG_RESPONSAVELField);
			PageProvider.AliasVariables.Add("NEG_DATAINICIALField", NEG_DATAINICIALField);
			PageProvider.AliasVariables.Add("NEG_DATACONCLUSAOField", NEG_DATACONCLUSAOField);
			PageProvider.AliasVariables.Add("PROD_IDField", PROD_IDField);
			PageProvider.AliasVariables.Add("NEG_VALORTOTALField", NEG_VALORTOTALField);
			PageProvider.AliasVariables.Add("NEG_VALORULTField", NEG_VALORULTField);
			PageProvider.AliasVariables.Add("NEG_CORPOPROPField", NEG_CORPOPROPField);
			PageProvider.AliasVariables.Add("NEG_IDField", NEG_IDField);
			PageProvider.AliasVariables.Add("NEG_DESCRICAOField", NEG_DESCRICAOField);
			PageProvider.AliasVariables.Add("NEG_STATUSField", NEG_STATUSField);
			PageProvider.AliasVariables.Add("FASE_IDField", FASE_IDField);
			PageProvider.AliasVariables.Add("FASE_PARField", FASE_PARField);
			PageProvider.AliasVariables.Add("Par_NegID", Par_NegID);
			PageProvider.AliasVariables.Add("BasePage", this);
        }

		protected void ___Form1_OnSaveSucceeded(GeneralDataProviderItem Item)
		{
			bool ActionSucceeded_1 = true;
			try
			{
				AjaxPanel.ResponseScripts.Add("try {getParentPage().GetRadWindowManager().GetActiveWindow().Caller.Refresh();} catch (e) {}");
			}
			catch (Exception ex)
			{
				ActionSucceeded_1 = false;
				PageErrors.Add("Error", ex.Message);
				ShowErrors();
			}
			bool ActionSucceeded_2 = true;
			try
			{
				if (ActionSucceeded_1)
				{
						AjaxPanel.Alert("Salvo com Sucesso!");
				}
			}
			catch (Exception ex)
			{
				ActionSucceeded_2 = false;
				PageErrors.Add("Error", ex.Message);
				ShowErrors();
			}
		}

		protected void ___Form1_OnRemoveSucceeded(GeneralDataProviderItem Item)
		{
			bool ActionSucceeded_1 = true;
			try
			{
				AjaxPanel.ResponseScripts.Add("try {getParentPage().GetRadWindowManager().GetActiveWindow().Caller.Refresh();} catch (e) {}");
			}
			catch (Exception ex)
			{
				ActionSucceeded_1 = false;
				PageErrors.Add("Error", ex.Message);
				ShowErrors();
			}
			bool ActionSucceeded_2 = true;
			try
			{
				if (ActionSucceeded_1)
				{
						AjaxPanel.Alert("Negociação Removida com Sucesso!");
				}
			}
			catch (Exception ex)
			{
				ActionSucceeded_2 = false;
				PageErrors.Add("Error", ex.Message);
				ShowErrors();
			}
		}

		protected void ___Form1_LoadCompleted()
		{
			bool ActionSucceeded_1 = true;
			try
			{
				Form1_LoadCompleted();
			}
			catch (Exception ex)
			{
				ActionSucceeded_1 = false;
				PageErrors.Add("Error", ex.Message);
				ShowErrors();
			}
			bool ActionSucceeded_2 = true;
			try
			{
				AjaxPanel.ResponseScripts.Add("try {getParentPage().GetRadWindowManager().GetActiveWindow().Caller.Refresh();} catch (e) {}");
			}
			catch (Exception ex)
			{
				ActionSucceeded_2 = false;
				PageErrors.Add("Error", ex.Message);
				ShowErrors();
			}
		}

		protected void ___BtnFase1_OnClick(object sender, EventArgs e)
		{
			bool ActionSucceeded_1 = true;
			try
			{
				FaseProcessProvider PreDefProvider = new FaseProcessProvider(this);
				PreDefProvider.AliasVariables = new Dictionary<string, object>();
				PreDefProvider.AliasVariables.Clear();
				PreDefProvider.AliasVariables.Add("Par_FasePar", "1");
				PreDefProvider.AliasVariables.Add("Par_FaseID", Convert.ToInt32(PageProvider.PAR_FASE1Provider.Item["FASE_ID"].GetValue()));
				PreDefProvider.AliasVariables.Add("Par_NegID", Convert.ToInt32(PageProvider.AliasVariables["NEG_IDField"]));
				PreDefProvider.ExecutePreDefinedProcess();
			}
			catch (Exception ex)
			{
				ActionSucceeded_1 = false;
				PageErrors.Add("Error", ex.Message);
				ShowErrors();
			}
		}

		protected void ___BtnFase2_OnClick(object sender, EventArgs e)
		{
			bool ActionSucceeded_1 = true;
			try
			{
				FaseProcessProvider PreDefProvider = new FaseProcessProvider(this);
				PreDefProvider.AliasVariables = new Dictionary<string, object>();
				PreDefProvider.AliasVariables.Clear();
				PreDefProvider.AliasVariables.Add("Par_FasePar", "2");
				PreDefProvider.AliasVariables.Add("Par_FaseID", Convert.ToInt32(PageProvider.PAR_FASE2Provider.Item["FASE_ID"].GetValue()));
				PreDefProvider.AliasVariables.Add("Par_NegID", Convert.ToInt32(PageProvider.AliasVariables["NEG_IDField"]));
				PreDefProvider.ExecutePreDefinedProcess();
			}
			catch (Exception ex)
			{
				ActionSucceeded_1 = false;
				PageErrors.Add("Error", ex.Message);
				ShowErrors();
			}
		}

		protected void ___BtnFase3_OnClick(object sender, EventArgs e)
		{
			bool ActionSucceeded_1 = true;
			try
			{
				FaseProcessProvider PreDefProvider = new FaseProcessProvider(this);
				PreDefProvider.AliasVariables = new Dictionary<string, object>();
				PreDefProvider.AliasVariables.Clear();
				PreDefProvider.AliasVariables.Add("Par_FasePar", "3");
				PreDefProvider.AliasVariables.Add("Par_FaseID", Convert.ToInt32(PageProvider.PAR_FASE3Provider.Item["FASE_ID"].GetValue()));
				PreDefProvider.AliasVariables.Add("Par_NegID", Convert.ToInt32(PageProvider.AliasVariables["NEG_IDField"]));
				PreDefProvider.ExecutePreDefinedProcess();
			}
			catch (Exception ex)
			{
				ActionSucceeded_1 = false;
				PageErrors.Add("Error", ex.Message);
				ShowErrors();
			}
		}

		protected void ___BtnFase4_OnClick(object sender, EventArgs e)
		{
			bool ActionSucceeded_1 = true;
			try
			{
				FaseProcessProvider PreDefProvider = new FaseProcessProvider(this);
				PreDefProvider.AliasVariables = new Dictionary<string, object>();
				PreDefProvider.AliasVariables.Clear();
				PreDefProvider.AliasVariables.Add("Par_FasePar", "4");
				PreDefProvider.AliasVariables.Add("Par_FaseID", Convert.ToInt32(PageProvider.PAR_FASE4Provider.Item["FASE_ID"].GetValue()));
				PreDefProvider.AliasVariables.Add("Par_NegID", Convert.ToInt32(PageProvider.AliasVariables["NEG_IDField"]));
				PreDefProvider.ExecutePreDefinedProcess();
			}
			catch (Exception ex)
			{
				ActionSucceeded_1 = false;
				PageErrors.Add("Error", ex.Message);
				ShowErrors();
			}
		}

		protected void ___BtnFase5_OnClick(object sender, EventArgs e)
		{
			bool ActionSucceeded_1 = true;
			try
			{
				FaseProcessProvider PreDefProvider = new FaseProcessProvider(this);
				PreDefProvider.AliasVariables = new Dictionary<string, object>();
				PreDefProvider.AliasVariables.Clear();
				PreDefProvider.AliasVariables.Add("Par_FasePar", "5");
				PreDefProvider.AliasVariables.Add("Par_FaseID", Convert.ToInt32(PageProvider.PAR_FASE5Provider.Item["FASE_ID"].GetValue()));
				PreDefProvider.AliasVariables.Add("Par_NegID", Convert.ToInt32(PageProvider.AliasVariables["NEG_IDField"]));
				PreDefProvider.ExecutePreDefinedProcess();
			}
			catch (Exception ex)
			{
				ActionSucceeded_1 = false;
				PageErrors.Add("Error", ex.Message);
				ShowErrors();
			}
		}

		protected void ___BtnConcluido_OnClick(object sender, EventArgs e)
		{
			bool ActionSucceeded_1 = true;
			try
			{
				Status_da_NegociacaoProcessProvider PreDefProvider = new Status_da_NegociacaoProcessProvider(this);
				PreDefProvider.AliasVariables = new Dictionary<string, object>();
				PreDefProvider.AliasVariables.Clear();
				PreDefProvider.AliasVariables.Add("Par_NegID", Convert.ToInt32(PageProvider.AliasVariables["NEG_IDField"]));
				PreDefProvider.AliasVariables.Add("Par_Status", "Concluído");
				PreDefProvider.ExecutePreDefinedProcess();
			}
			catch (Exception ex)
			{
				ActionSucceeded_1 = false;
				PageErrors.Add("Error", ex.Message);
				ShowErrors();
			}
		}

		protected void ___BtnAndamento_OnClick(object sender, EventArgs e)
		{
			bool ActionSucceeded_1 = true;
			try
			{
				Status_da_NegociacaoProcessProvider PreDefProvider = new Status_da_NegociacaoProcessProvider(this);
				PreDefProvider.AliasVariables = new Dictionary<string, object>();
				PreDefProvider.AliasVariables.Clear();
				PreDefProvider.AliasVariables.Add("Par_NegID", Convert.ToInt32(PageProvider.AliasVariables["NEG_IDField"]));
				PreDefProvider.AliasVariables.Add("Par_Status", "Em andamento");
				PreDefProvider.ExecutePreDefinedProcess();
			}
			catch (Exception ex)
			{
				ActionSucceeded_1 = false;
				PageErrors.Add("Error", ex.Message);
				ShowErrors();
			}
		}

		protected void ___BtnPerdido_OnClick(object sender, EventArgs e)
		{
			bool ActionSucceeded_1 = true;
			try
			{
				Status_da_NegociacaoProcessProvider PreDefProvider = new Status_da_NegociacaoProcessProvider(this);
				PreDefProvider.AliasVariables = new Dictionary<string, object>();
				PreDefProvider.AliasVariables.Clear();
				PreDefProvider.AliasVariables.Add("Par_NegID", Convert.ToInt32(PageProvider.AliasVariables["NEG_IDField"]));
				PreDefProvider.AliasVariables.Add("Par_Status", "Perdido");
				PreDefProvider.ExecutePreDefinedProcess();
			}
			catch (Exception ex)
			{
				ActionSucceeded_1 = false;
				PageErrors.Add("Error", ex.Message);
				ShowErrors();
			}
		}

		protected void ___Button5_OnClick(object sender, EventArgs e)
		{
			bool ActionSucceeded_1 = true;
			try
			{
				string UrlPage = ResolveUrl("~/Pages/Cadastro_Cliente.aspx");
				UrlPage += '?' + "Par_IDCliente=";
				try
				{
					if (!IsPostBack)
					{
						ClientScript.RegisterStartupScript(this.GetType(), "OnClick_GWindow", "<script>NavigateTargetByReference('" + UrlPage + "','GWindow', { Modal: true, Center: true });</script>");
					}
					else
					{
						AjaxPanel.ResponseScripts.Add("NavigateTargetByReference('" + UrlPage + "','GWindow', { Modal: true, Center: true });");
					}
				}
				catch(Exception ex)
				{
				}
			}
			catch (Exception ex)
			{
				ActionSucceeded_1 = false;
				PageErrors.Add("Error", ex.Message);
				ShowErrors();
			}
		}

		protected void ___Button6_OnClick(object sender, EventArgs e)
		{
			bool ActionSucceeded_1 = true;
			try
			{
				string UrlPage = ResolveUrl("~/Pages/Cadastro_Cliente.aspx");
				UrlPage += '?' + "Par_IDCliente=" + (CLI_IDField ).ToString();
				try
				{
					if (!IsPostBack)
					{
						ClientScript.RegisterStartupScript(this.GetType(), "OnClick_GWindow", "<script>NavigateTargetByReference('" + UrlPage + "','GWindow', { Modal: true, Center: true });</script>");
					}
					else
					{
						AjaxPanel.ResponseScripts.Add("NavigateTargetByReference('" + UrlPage + "','GWindow', { Modal: true, Center: true });");
					}
				}
				catch(Exception ex)
				{
				}
			}
			catch (Exception ex)
			{
				ActionSucceeded_1 = false;
				PageErrors.Add("Error", ex.Message);
				ShowErrors();
			}
		}

		protected void ___Button8_OnClick(object sender, EventArgs e)
		{
			bool ActionSucceeded_1 = true;
			try
			{
				string UrlPage = ResolveUrl("~/Pages/Tarefas.aspx");
				UrlPage += '?' + "ParTarID=";
				UrlPage += '&' + "Par_neg=" + (Convert.ToInt32(PageProvider.AliasVariables["NEG_IDField"])).ToString();
				try
				{
					Response.Redirect(UrlPage);
				}
				catch(Exception ex)
				{
				}
			}
			catch (Exception ex)
			{
				ActionSucceeded_1 = false;
				PageErrors.Add("Error", ex.Message);
				ShowErrors();
			}
		}

		protected void ___Button9_OnClick(object sender, EventArgs e)
		{
			bool ActionSucceeded_1 = true;
			try
			{
				string UrlPage = ResolveUrl("~/Pages/Rel_PCompra.aspx");
				UrlPage += '?' + "PARNEGID=" + (Convert.ToInt32(PageProvider.AliasVariables["NEG_IDField"])).ToString();
				try
				{
					if (!IsPostBack)
					{
						ClientScript.RegisterStartupScript(this.GetType(), "OnClick_Nova janela do Browser", "<script>NavigatePopup('" + UrlPage + "');</script>");
					}
					else
					{
						AjaxPanel.ResponseScripts.Add("NavigatePopup('" + UrlPage + "');");
					}
				}
				catch(Exception ex)
				{
				}
			}
			catch (Exception ex)
			{
				ActionSucceeded_1 = false;
				PageErrors.Add("Error", ex.Message);
				ShowErrors();
			}
		}





		public override void ExecuteServerCommandRequest(string CommandName, string TargetName, string[] Parameters)
		{
			ExecuteLocalCommandRequest(CommandName, TargetName, Parameters);
		}		


		
		/// <summary>
		/// Carrega os objetos de tela para o Item Provider da grid
		/// </summary>
		public override GeneralDataProviderItem LoadItemFromGridControl(bool EnableValidation, string GridId)
		{
			GeneralDataProviderItem Item = null;
			switch (GridId)
			{
				case "Grid1":
					if (PageProvider.Neg_cio_Grid1Provider.DataProvider.Item == null)
						Item = PageProvider.Neg_cio_Grid1Provider.GetDataProviderItem();
					else
						Item = PageProvider.Neg_cio_Grid1Provider.DataProvider.Item;
					PageProvider.Neg_cio_Grid1Provider.RaiseSetRelationFields(PageProvider.Neg_cio_Grid1Provider, Item);
					Item.SetFieldValue(Item["Tipo"], PageProvider.Neg_cio_Grid1Provider.GridData["Tipo"]);
					Item.SetFieldValue(Item["Data"], PageProvider.Neg_cio_Grid1Provider.GridData["Data"]);
					Item.SetFieldValue(Item["Descricao"], PageProvider.Neg_cio_Grid1Provider.GridData["Descricao"]);
					PageProvider.Neg_cio_Grid1Provider.InitializeAlias(Item);
					if (EnableValidation)
					{
						PageProvider.Neg_cio_Grid1Provider.Validate(Item);
					}
					break;
			}

			return Item;
		}

		public override void setGridPerm()
		{
			if (!PageOperations.AllowInsert)
			{
				Grid1.MasterTableView.CommandItemDisplay = GridCommandItemDisplay.None;
			}
			if (Grid1.Columns[0] is GridEditCommandColumn && !PageOperations.AllowUpdate)
			{
				Grid1.Columns[0].Visible = false;
			}
			if (Grid1.Columns.Count != 0 && Grid1.Columns[Grid1.Columns.Count - 1] is GridButtonColumn && (Grid1.Columns[Grid1.Columns.Count - 1] as GridButtonColumn).CommandName == "Delete" && !PageOperations.AllowDelete)
			{
				Grid1.Columns[Grid1.Columns.Count - 1].Visible = false;
			}
		}

		protected void Grid1_ItemCreated(object sender, GridItemEventArgs e)
		{
			if (e.Item is GridEditableItem && (e.Item.IsInEditMode))
			{
				if (Grid1.Columns[0].ColumnType == "GridEditCommandColumn" && PageOperations.AllowUpdate)
				{
					if (Grid1.Columns[0].HeaderStyle.Width == 20 && Grid1.Columns[0].Visible == true)
					{
						Grid1.Columns[0].HeaderStyle.Width = 70; 
					}
					else
					{
						Grid1.Columns[0].HeaderStyle.Width = 20; 
					}
				}
				GridEditableItem editableItem = (GridEditableItem)e.Item;
				TextBox txt;
				txt = (editableItem.EditManager.GetColumnEditor("GridColumn1") as GridTextBoxColumnEditor).TextBoxControl;
				txt.Width = 78;
				RadDatePicker dtp;
				dtp = (editableItem.EditManager.GetColumnEditor("GridColumn5") as GridDateTimeColumnEditor).PickerControl;
				dtp.Width = 128;
				Mask.SetMask(dtp.DateInput, "dd/MM/yyyy", 10, false);
				dtp.DateInput.Attributes.Add("onblur", "OnMaskBlur();");
				dtp.DateInput.Attributes.Add("isGrid", "true");
				ApplyMasks(dtp.DateInput);
				txt = (editableItem.EditManager.GetColumnEditor("GridColumn2") as GridTextBoxColumnEditor).TextBoxControl;
				txt.Width = 478;
				GridItemCreatedFinished(sender, e);
			}
		}
		
		
		
		protected void Grid1_ItemDataBound(object sender, GridItemEventArgs e)
		{
			if (e.Item is GridPagerItem)
			{
				GridPagerItem pager = (GridPagerItem)e.Item;
				RadComboBox PageSizeComboBox = (RadComboBox)pager.FindControl("PageSizeComboBox");
				PageSizeComboBox.Visible = false;
				Label ChangePageSizeLabel = (Label)pager.FindControl("ChangePageSizeLabel");
				ChangePageSizeLabel.Visible = false;
			}
		}
		
		protected void Grid1_ItemCommand(object source, GridCommandEventArgs e)
		{
			RadGrid Grid = (RadGrid)source;
			if (e.CommandName == RadGrid.InitInsertCommandName)// If insert mode, disallow edit
			{
				Grid.MasterTableView.ClearEditItems();
			}
			if (e.CommandName == RadGrid.EditCommandName) // If edit mode, disallow insert
			{
				e.Item.OwnerTableView.IsItemInserted = false;
			}
			if (e.CommandName == RadGrid.ExpandCollapseCommandName) // Allow Expand/Collapse one row at a time
			{
				foreach (GridItem item in e.Item.OwnerTableView.Items)
				{
					if (item.Expanded && item != e.Item)
					{
						item.Expanded = false;
					}
				}
			}
			if (e.CommandName == Telerik.Web.UI.RadGrid.ExportToWordCommandName || e.CommandName == Telerik.Web.UI.RadGrid.ExportToPdfCommandName ||
				e.CommandName == Telerik.Web.UI.RadGrid.ExportToExcelCommandName || e.CommandName == Telerik.Web.UI.RadGrid.ExportToCsvCommandName)
			{
				Grid.AllowPaging = false;
				Grid.ExportSettings.IgnorePaging = true;
				Grid.ExportSettings.OpenInNewWindow = true;
			}
			if (e.Item is GridDataItem && !(e.Item is GridDataInsertItem) && e.CommandName != "Cancel" && e.CommandName != "Update" && e.CommandName != "Insert")
			{
				GeneralGridProvider Provider = GetGridProvider(Grid);
				Hashtable CurrentValues = new Hashtable();
				GridDataItem item = (GridDataItem)e.Item;
				if (e.CommandArgument != null && e.CommandArgument.ToString() != "")
				{
					int index = 0;
					if (int.TryParse(e.CommandArgument.ToString(), out index)) item = e.Item.OwnerTableView.Items[index];
				}
				item.ExtractValues(CurrentValues);
				InitializeGridData(Grid);
				string Filtro = "";
				Dictionary<string, FieldBase> Items = Provider.DataProvider.CreateItemFields();
				foreach (string key in item.OwnerTableView.DataKeyNames)
				{
					if(Provider.DataProvider.Item.GetFieldAliasByFieldName(key) != "")
						CurrentValues[Provider.DataProvider.Item.GetFieldAliasByFieldName(key)] = item.GetDataKeyValue(key);
					else
						CurrentValues[key] = item.GetDataKeyValue(key);
					FieldBase field = Provider.DataProvider.GetFieldByName(Items, key);
					FieldType fieldType = (field != null ? field.FieldType : FieldType.Text);
					if(Provider.DataProvider.Item.GetFieldAliasByFieldName(key) != "")
						Filtro += String.Format("[{0}] = {1} AND ", key, Dao.ToSql(CurrentValues[Provider.DataProvider.Item.GetFieldAliasByFieldName(key)].ToString(), fieldType));
					else
						Filtro += String.Format("[{0}] = {1} AND ", key, Dao.ToSql(CurrentValues[key].ToString(), fieldType));
				}
				if (Filtro.Length > 0)
				{
					if (String.IsNullOrEmpty(Provider.DataProvider.FiltroAtual))
						Provider.DataProvider.FiltroAtual = Filtro.Substring(0, Filtro.Length - 5);
					else
						Provider.DataProvider.FiltroAtual = String.Format("({0}) AND {1}", Provider.DataProvider.FiltroAtual, Filtro.Substring(0, Filtro.Length - 5));
				}
				Provider.SelectItem(this, Grid.ID, CurrentValues);
		
				switch (e.CommandName)
				{
					case "GridColumn6":
						bool ActionSucceeded_GridColumn6_1 = true;
						try
						{
							string UrlPage = ResolveUrl("~/Pages/Tarefas.aspx");
							UrlPage += '?' + "ParTarID=" + (Convert.ToString(Provider.DataProvider.Item["ID"].GetValue())).ToString();
							try
							{
								if (!IsPostBack)
								{
									ClientScript.RegisterStartupScript(this.GetType(), "OnLinkClick_GWindow", "<script>NavigateTargetByReference('" + UrlPage + "','GWindow', { Modal: true, Center: true });</script>");
								}
								else
								{
									AjaxPanel.ResponseScripts.Add("NavigateTargetByReference('" + UrlPage + "','GWindow', { Modal: true, Center: true });");
								}
							}
							catch(Exception ex)
							{
							}
						}
						catch (Exception ex)
						{
							ActionSucceeded_GridColumn6_1 = false;
							PageErrors.Add("Error", ex.Message);
							ShowErrors();
						}
					break;
				}
			}
		}

		public override void RefreshOnNavigation()
		{
			Grid1.MasterTableView.ClearEditItems();
			Grid1.MasterTableView.IsItemInserted = false;
		}

		protected void Grid_Init(object sender, EventArgs e)
		{
			RadGrid Grid = (RadGrid)sender;
			GridFilterMenu menu = Grid.FilterMenu;
			int i = 0;
			while (i < menu.Items.Count)
			{
				if (menu.Items[i].Value == "Between" || menu.Items[i].Value == "NotBetween")
				{
					menu.Items.RemoveAt(i);
				}
				else
				{
					i++;
				}
			}
		}

		protected void Grid_NeedDataSource(object source, GridNeedDataSourceEventArgs e)
		{
			int TotalRecords = 0;
			string GridFilter = "";
			RadGrid Grid = (RadGrid)source;
			InitializeGridData(Grid);

			
			if (Grid.MasterTableView.SortExpressions.Count > 0)
			{
				string orderBy = "";
				foreach (GridSortExpression sort in Grid.MasterTableView.SortExpressions)
				{
					orderBy += GetGridProvider(Grid).DataProvider.Dao.PoeColAspas(sort.FieldName) + " " + sort.SortOrderAsString() + ", ";
				}
				GetGridProvider(Grid).DataProvider.OrderBy = orderBy.Remove(orderBy.Length - 2);
			}
			Grid.DataSource = GetGridProvider(Grid).DataProvider.SelectItems(Grid.CurrentPageIndex, Grid.PageSize, out TotalRecords);
			Grid.VirtualItemCount = TotalRecords;
		}
		 
		protected void Grid_UpdateCommand(object source, GridCommandEventArgs e)
		{
			var editableItem = (GridEditableItem)e.Item;
			RadGrid Grid = (RadGrid)source;
			Tuple<Hashtable, Hashtable> GridValues = FillGridValues(editableItem, Grid);
			GetGridProvider(Grid).UpdateItem(this, Grid.ID, DefineGridInsertValues(Grid.ID, GridValues.Item1), GridValues.Item2);
			 if (GetGridProvider(Grid).PageErrors != null)
            {
                e.Canceled = true;
                PageErrors.Add(GetGridProvider(Grid).PageErrors);
                return;
            }
			Grid.DataSource = null;
            Grid.Rebind();
			PageShow(FormPositioningEnum.Current, true, false, false);
		}

		protected void Grid_InsertCommand(object source, GridCommandEventArgs e)
		{
			var editableItem = (GridEditableItem)e.Item;
			RadGrid Grid = (RadGrid)source;
			Hashtable newValues = new Hashtable();
			e.Item.OwnerTableView.ExtractValuesFromItem(newValues, editableItem);
			GetGridProvider(Grid).InsertItem(this, Grid.ID, DefineGridInsertValues(Grid.ID, newValues));
			if (GetGridProvider(Grid).PageErrors != null)
            {
                e.Canceled = true;
                PageErrors.Add(GetGridProvider(Grid).PageErrors);
                return;
            }
			PageShow(FormPositioningEnum.Current, true, false, false);
		}

		protected void Grid_DeleteCommand(object source, GridCommandEventArgs e)
		{
			RadGrid Grid = (RadGrid)source;
            DeleteGrid(Grid, false, (GridEditableItem)e.Item);
			if (GetGridProvider(Grid).PageErrors != null)
			{
				e.Canceled = true;
				PageErrors.Add(GetGridProvider(Grid).PageErrors);
				return;
			}
			PageShow(FormPositioningEnum.Current, true, false, false);
		}

		public override void DeleteChildItens()
        {
            base.DeleteChildItens();
        }

		public void DeleteGrid(RadGrid Grid, bool DeleteAllItems, GridEditableItem SingleItem)
        {
			int StartIndex = 0;
            if (!DeleteAllItems) StartIndex = SingleItem.ItemIndex;
            else
            {
                Grid.DataSource = null;
                Grid.CurrentPageIndex = 0;
                Grid.Rebind();
            }
            while (Grid.Items.Count != 0 && PageErrors.Count == 0)
            {
                for (int i = StartIndex; Grid.MasterTableView.Items.Count > i; i++)
                {
                    switch (Grid.ID)
                    {
					}
                    Tuple<Hashtable, Hashtable> GridValues = FillGridValues(Grid.MasterTableView.Items[i], Grid);
                    GetGridProvider(Grid).DeleteItem(this, Grid.ID, GridValues.Item1, GridValues.Item2);
					if(GetGridProvider(Grid).PageErrors != null) PageErrors.Add(GetGridProvider(Grid).PageErrors);
                    if (!DeleteAllItems) break;
                }
				Grid.DataSource = null;
				if (DeleteAllItems) Grid.CurrentPageIndex = 0;
                if (!DeleteAllItems && Grid.Items.Count == 1 && Grid.CurrentPageIndex > 0) Grid.CurrentPageIndex--;
                Grid.Rebind();
				if (!DeleteAllItems) break;
            }
		}

		private Tuple<Hashtable, Hashtable> FillGridValues(GridEditableItem editableItem, RadGrid Grid)
		{
			Hashtable newValues = new Hashtable();
			editableItem.OwnerTableView.ExtractValuesFromItem(newValues, editableItem);
			Hashtable oldValues = newValues.Clone() as Hashtable;
			foreach (string key in Grid.MasterTableView.DataKeyNames)
			{
				string FdAlias = (from f in GetGridProvider(Grid).DataProvider.Item.Fields where f.Value.Name == key select f.Key).FirstOrDefault();
				if (!newValues.ContainsKey(key)) newValues.Add(key, editableItem.GetDataKeyValue(key));
				if (!oldValues.ContainsKey(FdAlias))
				{
					oldValues.Add(FdAlias, editableItem.GetDataKeyValue(key));
				}
				else
				{
					oldValues[FdAlias] = editableItem.GetDataKeyValue(key);
				}
			}
			return new Tuple<Hashtable, Hashtable>(newValues, oldValues);
		}
		
		private void InitializeGridData(RadGrid Grid)
		{
			switch (Grid.ID)
			{
				case "Grid1":
					try
					{
						if(GetGridProvider(Grid).DataProvider.FiltroAtual != null && GetGridProvider(Grid).DataProvider.FiltroAtual.Trim().Length > 0)
						{
							GetGridProvider(Grid).DataProvider.FiltroAtual = "(" + GetGridProvider(Grid).DataProvider.FiltroAtual + ") AND (" + Dao.PoeColAspas("NEG_ID") + " = " + Dao.ToSql(PageProvider.MainProvider.DataProvider.Item["NEG_ID"].GetFormattedValue(), FieldType.Integer) + ")";
						}
						else
						{
							GetGridProvider(Grid).DataProvider.FiltroAtual = Dao.PoeColAspas("NEG_ID") + " = " + Dao.ToSql(PageProvider.MainProvider.DataProvider.Item["NEG_ID"].GetFormattedValue(), FieldType.Integer);
						}
					}
					catch
					{
						GetGridProvider(Grid).DataProvider.FiltroAtual = "1 = 2";
					}
					break;
			}
		}
		
		public override GeneralGridProvider GetGridProvider(RadGrid Grid)
		{
			switch (Grid.ID)
		{
				case "Grid1":
					return PageProvider.Neg_cio_Grid1Provider;
			}
			return null;
		}



		public override GeneralDataProviderItem GetDataProviderItem(GeneralDataProvider Provider)
		{
			if (Provider.Name == "ProcessoFase")
			{
				return new CRMSSI_TB_NEGOCIOItem("CRMSSI");
			}
			if (Provider.Name == "ProcessoFase")
			{
				return new CRMSSI_TB_NEGOCIOItem("CRMSSI");
			}
			if (Provider.Name == "ProcStatus")
			{
				return new CRMSSI_TB_NEGOCIOItem("CRMSSI");
			}
			if (Provider.Name == "ProcStatus")
			{
				return new CRMSSI_TB_NEGOCIOItem("CRMSSI");
			}
			return base.GetDataProviderItem(Provider);
		}
		
		protected void ___ComboBox4_OnItemsRequested(object sender, RadComboBoxItemsRequestedEventArgs e)
		{
			KeyValuePair<string, object> AllowFilterContext = e.Context.FirstOrDefault(c => c.Key == "AllowFilter");
			bool AllowFilter = false;
			if (AllowFilterContext.Value != null) AllowFilter = Convert.ToBoolean(AllowFilterContext.Value);
		
			KeyValuePair<string, object> IsRefreshContext = e.Context.FirstOrDefault(c => c.Key == "IsRefresh");
			bool IsRefresh = false;
			if (IsRefreshContext.Value != null) IsRefresh = Convert.ToBoolean(IsRefreshContext.Value);
		
			int ItemsCount = Convert.ToInt32(e.Context["ItemsCount"]);
			e.EndOfItems = PageProvider.FillComboBox4(sender as RadComboBox, e.NumberOfItems, e.Text, AllowFilter);
		}
		
		protected void ___ComboBox1_OnItemsRequested(object sender, RadComboBoxItemsRequestedEventArgs e)
		{
			KeyValuePair<string, object> AllowFilterContext = e.Context.FirstOrDefault(c => c.Key == "AllowFilter");
			bool AllowFilter = false;
			if (AllowFilterContext.Value != null) AllowFilter = Convert.ToBoolean(AllowFilterContext.Value);
		
			KeyValuePair<string, object> IsRefreshContext = e.Context.FirstOrDefault(c => c.Key == "IsRefresh");
			bool IsRefresh = false;
			if (IsRefreshContext.Value != null) IsRefresh = Convert.ToBoolean(IsRefreshContext.Value);
		
			int ItemsCount = Convert.ToInt32(e.Context["ItemsCount"]);
			e.EndOfItems = PageProvider.FillComboBox1(sender as RadComboBox, e.NumberOfItems, e.Text, AllowFilter);
		}
		
		protected void ___ComboBox2_OnItemsRequested(object sender, RadComboBoxItemsRequestedEventArgs e)
		{
			KeyValuePair<string, object> AllowFilterContext = e.Context.FirstOrDefault(c => c.Key == "AllowFilter");
			bool AllowFilter = false;
			if (AllowFilterContext.Value != null) AllowFilter = Convert.ToBoolean(AllowFilterContext.Value);
		
			KeyValuePair<string, object> IsRefreshContext = e.Context.FirstOrDefault(c => c.Key == "IsRefresh");
			bool IsRefresh = false;
			if (IsRefreshContext.Value != null) IsRefresh = Convert.ToBoolean(IsRefreshContext.Value);
		
			int ItemsCount = Convert.ToInt32(e.Context["ItemsCount"]);
			e.EndOfItems = PageProvider.FillComboBox2(sender as RadComboBox, e.NumberOfItems, e.Text, AllowFilter);
		}
		
		protected void ___ComboBox5_OnItemsRequested(object sender, RadComboBoxItemsRequestedEventArgs e)
		{
			KeyValuePair<string, object> AllowFilterContext = e.Context.FirstOrDefault(c => c.Key == "AllowFilter");
			bool AllowFilter = false;
			if (AllowFilterContext.Value != null) AllowFilter = Convert.ToBoolean(AllowFilterContext.Value);
		
			KeyValuePair<string, object> IsRefreshContext = e.Context.FirstOrDefault(c => c.Key == "IsRefresh");
			bool IsRefresh = false;
			if (IsRefreshContext.Value != null) IsRefresh = Convert.ToBoolean(IsRefreshContext.Value);
		
			int ItemsCount = Convert.ToInt32(e.Context["ItemsCount"]);
			e.EndOfItems = PageProvider.FillComboBox5(sender as RadComboBox, e.NumberOfItems, e.Text, AllowFilter);
		}
		protected override void OnLoadComplete(EventArgs e)
		{
			___Form1_LoadCompleted();
			base.OnLoadComplete(e);
		}
		public override void OnRemoveSucceeded(GeneralDataProviderItem Item)
		{
			___Form1_OnRemoveSucceeded(Item);
		}
		public override void SaveSucceeded(GeneralDataProviderItem Item)
		{
			___Form1_OnSaveSucceeded(Item);
		}
#region CÓDIGO DE USUARIO
		private bool Destaca()
		{
			return true;
		}
		protected void Form1_OnLoad()
		{
			
		}

		protected void Form1_LoadCompleted()
		{
			#region Botoes de Fase
				//Busca no banco de dados a situação da fase
				//Cores: Marcado #2395DF | Desmarcado #A3C0E5
				string FasePar = CRMSSI.SQLExecutaRetornoF9("select FASE_PAR from TB_Negocio where neg_id = " + NEG_IDField, "");
				if (FasePar == "1" || FasePar == "")
		        {
		            BtnFase1.Style["background-color"] = "#2395DF";
		            BtnFase2.Style["background-color"] = "#A3C0E5";
		            BtnFase3.Style["background-color"] = "#A3C0E5";
		            BtnFase4.Style["background-color"] = "#A3C0E5";
		            BtnFase5.Style["background-color"] = "#A3C0E5";
		        }
		        if (FasePar == "2")
		        {
		            BtnFase1.Style["background-color"] = "#2395DF";
		            BtnFase2.Style["background-color"] = "#2395DF";
		            BtnFase3.Style["background-color"] = "#A3C0E5";
		            BtnFase4.Style["background-color"] = "#A3C0E5";
		            BtnFase5.Style["background-color"] = "#A3C0E5";
		        }
		        if (FasePar == "3")
		        {
		            BtnFase1.Style["background-color"] = "#2395DF";
		            BtnFase2.Style["background-color"] = "#2395DF";
		            BtnFase3.Style["background-color"] = "#2395DF";
		            BtnFase4.Style["background-color"] = "#A3C0E5";
		            BtnFase5.Style["background-color"] = "#A3C0E5";
		        }
		        if (FasePar == "4")
		        {
		            BtnFase1.Style["background-color"] = "#2395DF";
		            BtnFase2.Style["background-color"] = "#2395DF";
		            BtnFase3.Style["background-color"] = "#2395DF";
		            BtnFase4.Style["background-color"] = "#2395DF";
		            BtnFase5.Style["background-color"] = "#A3C0E5";
		        }
		        if (FasePar == "5")
		        {
		            BtnFase1.Style["background-color"] = "#2395DF";
		            BtnFase2.Style["background-color"] = "#2395DF";
		            BtnFase3.Style["background-color"] = "#2395DF";
		            BtnFase4.Style["background-color"] = "#2395DF";
		            BtnFase5.Style["background-color"] = "#2395DF";
		        }
			#endregion
				
				

			
			#region Botoes de Status
				
				//Busca no banco de dados a situação da fase
				string Status = CRMSSI.SQLExecutaRetornoF9("select NEG_STATUS from TB_Negocio where neg_id = " + NEG_IDField, "");
		        if (Status == "Perdido" )
		        {
		            BtnPerdido.Style["background-color"] = "#ED3737";
		            BtnAndamento.Style["background-color"] = "#E4E4E4";
		            BtnConcluido.Style["background-color"] = "#E4E4E4";
					
					DivPerda.Visible = true;

		        }
		        if (Status == "Em andamento" || Status == "")
		        {
		            BtnPerdido.Style["background-color"] = "#E4E4E4";
		            BtnAndamento.Style["background-color"] = "#FF9439";
		            BtnConcluido.Style["background-color"] = "#E4E4E4";
					
					DivPerda.Visible = false;

		        }
		        if (Status == "Concluído")
		        {
		            BtnPerdido.Style["background-color"] = "#E4E4E4";
		            BtnAndamento.Style["background-color"] = "#E4E4E4";
		            BtnConcluido.Style["background-color"] = "#5AB211";
					
					DivPerda.Visible = false;
		        }
				
			#endregion
		}
#endregion
	}
}

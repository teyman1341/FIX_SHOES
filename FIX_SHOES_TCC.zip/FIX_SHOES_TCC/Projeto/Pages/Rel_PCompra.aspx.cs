using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Telerik.Reporting;
using COMPONENTS;
using COMPONENTS.Configuration;

namespace PROJETO.Reports
{
	public partial class Rel_PCompra : Page
	{
		protected override void OnLoad(EventArgs e)
		{
			try
			{
				Utility.CheckAuthentication(this,true);
			}
			catch (Exception ex)
			{
			}
		}

		public double PARNEGID = 0;
		protected override void OnInit(EventArgs e)
		{
			try{ PARNEGID = Convert.ToDouble(HttpContext.Current.Request.QueryString["PARNEGID"]); } catch { }
			
			Dictionary<string, Dictionary<string, string>> DataSourcesConnections = new Dictionary<string, Dictionary<string, string>>();
			DataSourcesConnections.Add("Rel_PCompra.trdx", new Dictionary<string, string>());
			DataSourcesConnections["Rel_PCompra.trdx"].Add("GV_DS_PEDIDOCOMPRA", Settings.GetConnectionString((((Databases)HttpContext.Current.Application["Databases"])["CRMSSI"])).Connection);
				
			var connectionStringHandler = new TelerikReportConnectionStringManager(DataSourcesConnections);
			var reportSource = connectionStringHandler.UpdateReportSource(new UriReportSource { Uri = Server.MapPath("~/Pages/Rel_PCompra.trdx") });

			reportSource.Parameters.Add(new Telerik.Reporting.Parameter("GV_PARAM_PARNEGID", PARNEGID));

			TelerikReportViewer1.ReportSource = reportSource;
			TelerikReportViewer1.RefreshReport();
		}
		
	}

}

using System;
using System.Collections;
using System.Collections.Specialized;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Web;
using System.IO;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.Security;
using System.Text.RegularExpressions;
using System.Globalization;
using PROJETO;
using COMPONENTS;
using COMPONENTS.Data;
using COMPONENTS.Configuration;
using COMPONENTS.Security;
using PROJETO.DataProviders;
using PROJETO.DataPages;
using Telerik.Web.UI;
using System.Linq;

namespace PROJETO.DataPages
{
	
	public partial class Status_da_Negociacao : GeneralDataProcess
	{

		private Status_da_NegociacaoProcessProvider PageProvider;

		public override string FormID { get { return "28717"; } }
		public override string PageName { get { return "Status_da_Negociacao.aspx"; } }
		public string Par_NegID = "";
		public string Par_Status = "";

		public override void CreateProvider()
		{
			PageProvider = new Status_da_NegociacaoProcessProvider(this);
		}
		
		/// <summary>
		/// onInit Vamos Carregar o Painel de Ajax e Label de erros da página
		/// </summary>
		protected override void OnInit(EventArgs e)
		{
			Par_NegID = HttpContext.Current.Request.QueryString["Par_NegID"];
			try { if (string.IsNullOrEmpty(Par_NegID)) Par_NegID = HttpContext.Current.Session["Par_NegID"].ToString();} catch {} 
			if (string.IsNullOrEmpty(Par_NegID)) Par_NegID = "0";
			Par_Status = HttpContext.Current.Request.QueryString["Par_Status"];
			try { if (string.IsNullOrEmpty(Par_Status)) Par_Status = HttpContext.Current.Session["Par_Status"].ToString();} catch {} 
			if (string.IsNullOrEmpty(Par_Status)) Par_Status = "";
			base.OnInit(e);
			
		}
		
		public override void ShowFormulas()
		{
		}

		public override void GetScreenFieldsValues()
		{
			PageProvider.AliasVariables = new Dictionary<string, object>();
			PageProvider.AliasVariables.Clear();
			PageProvider.AliasVariables.Add("Par_NegID", Par_NegID);
			PageProvider.AliasVariables.Add("Par_Status", Par_Status);
		}

		public void ExecutePreDefProcess()
		{
			try
			{
				GetScreenFieldsValues();
				GeneralDataProviderItem item = new GeneralDataProviderItem();
				PageProvider.Validate(item);
				if (item.Errors.Count == 0)
				{
					if (ErrorLabel != null) ErrorLabel.Text = "";
					PageProvider.ExecutePreDefinedProcess();
					OnProcessSucceeded();
				}
				else ShowErrors(item.Errors);
			}
			catch (Exception ex)
			{
				OnProcessFailed();
				NameValueCollection Errors = new NameValueCollection();
                Errors.Add("Error", ex.Message);
                ShowErrors(Errors);
			}
		}

		public override GeneralDataProviderItem GetDataProviderItem(GeneralDataProvider Provider)
		{
			if (Provider.Name == "ProcStatus")
			{
				return new CRMSSI_TB_NEGOCIOItem("CRMSSI");
			}
			if (Provider.Name == "ProcStatus")
			{
				return new CRMSSI_TB_NEGOCIOItem("CRMSSI");
			}
			return null;
		}

	}


}

using System;
using System.Collections;
using System.Collections.Specialized;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Web;
using System.IO;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.Security;
using System.Text.RegularExpressions;
using System.Globalization;
using System.Configuration;
using System.Linq;
using PROJETO;
using COMPONENTS;
using COMPONENTS.Data;
using COMPONENTS.Configuration;
using COMPONENTS.Security;
using PROJETO.DataProviders;
using PROJETO.DataPages;
using Telerik.Web.UI;

namespace PROJETO.DataPages
{
	public partial class Tarefas : GeneralDataPage
	{
		protected TarefasPageProvider PageProvider;
	
		public string TAR_DESCField = "";
		public string TAR_TIPOField = "";
		public long NEG_IDField = 0;
		public string TAR_RESPONSAVELField = "";
		public bool TAR_FINALIZADOField;
		public DateTime ? TAR_DATAHORAField;
		public long TAR_IDField = 0;
		public long CLI_IDField = 0;
		
		public override string FormID { get { return "28699"; } }
		public override string TableName { get { return "TB_TAREFA"; } }
		public override string DatabaseName { get { return "CRMSSI"; } }
		public override string PageName { get { return "Tarefas.aspx"; } }
		public override string ProjectID { get { return "1DB2E771"; } }
		public override string TableParameters { get { return "false"; } }
		public override bool PageInsert { get { return true;}}
		public override bool CanEdit { get { return true && UpdateValidation(); }}
		public override bool CanInsert  { get { return true && InsertValidation(); } }
		public override bool CanDelete { get { return true && DeleteValidation(); } }
		public override bool CanView { get { return true; } }
		public override bool OpenInEditMode { get { return true; } }
		


		public string ParTarID = "";
		public string Par_neg = "";

		public override void SetStartFilter()
		{
			try
			{
				if (!String.IsNullOrEmpty(ParTarID))
				{
					PageProvider.MainProvider.DataProvider.StartFilter = Dao.PoeColAspas("TAR_ID") + " = " + Dao.ToSql(ParTarID.ToString(), FieldType.Integer);
				}
				else
				{
					PageProvider.MainProvider.DataProvider.StartFilter = "1 = 2";
				}
			}
			catch
			{
				PageProvider.MainProvider.DataProvider.StartFilter = "1 = 2";
			}
		}
		
		public override void CreateProvider()
		{
			PageProvider = new TarefasPageProvider(this);
		}
		
		private void InitializePageContent()
		{
		}

		/// <summary>
        /// onInit Vamos Carregar o Painel de Ajax e Label de erros da página
        /// </summary>
		protected override void OnInit(EventArgs e)
		{
			ParTarID = HttpContext.Current.Request.QueryString["ParTarID"];
			try { if (string.IsNullOrEmpty(ParTarID)) ParTarID = HttpContext.Current.Session["ParTarID"].ToString();} catch {} 
			if (string.IsNullOrEmpty(ParTarID)) ParTarID = "0";
			Par_neg = HttpContext.Current.Request.QueryString["Par_neg"];
			try { if (string.IsNullOrEmpty(Par_neg)) Par_neg = HttpContext.Current.Session["Par_neg"].ToString();} catch {} 
			if (string.IsNullOrEmpty(Par_neg)) Par_neg = "0";
			AjaxPanel = MainAjaxPanel;
			if (IsPostBack)
			{
				AjaxPanel.ResponseScripts.Add("setTimeout(\"InitializeClient();\",100);");
			}
			AjaxPanel.ResponseScripts.Add("setTimeout(\"RegisterClientValidateScript();\",100);");
			ErrorLabel = labError;
			if (!PageInsert )
				DisableEnableContros(false);

			base.OnInit(e);
		}
		

		/// <summary>
		/// Carrega os objetos de Item de acordo com os controles
		/// </summary>
		public override void UpdateItemFromControl(GeneralDataProviderItem  Item)
		{
			// só vamos permitir a carga dos itens de acordo com os controles de tela caso esteja ocorrendo
			// um postback pois em caso contrário a página está sendo aberta em modo de inclusão/edição
			// e dessa forma não teve alteração de usuário nos dados do formulário
			if (PageState != FormStateEnum.Navigation && this.IsPostBack)
			{
				Item.SetFieldValue(Item["TAR_DESC"], RadTextBox3.Text, false);
				Item.SetFieldValue(Item["TAR_TIPO"], ComboBox1.SelectedValue);
				Item.SetFieldValue(Item["NEG_ID"], ComboBox2.SelectedValue);
				Item.SetFieldValue(Item["TAR_RESPONSAVEL"], ComboBox3.SelectedValue);
				Item.SetFieldValue(Item["TAR_FINALIZADO"], RadCheckBox1.Checked);
				if (DatePicker1.SelectedDate != null) Item.SetFieldValue(Item["TAR_DATAHORA"], DatePicker1.SelectedDate.Value.ToString("dd/MM/yyyy HH:mm"));
				else Item.SetFieldValue(Item["TAR_DATAHORA"], DBNull.Value);
			}
			InitializeAlias(Item);
		}

		/// <summary>
		/// Carrega os objetos de tela para o Item Provider da página
		/// </summary>

		public override GeneralDataProviderItem LoadItemFromControl(bool EnableValidation)
		{
			GeneralDataProviderItem Item = PageProvider.GetDataProviderItem(DataProvider);
			if (PageState != FormStateEnum.Navigation)
			{
				Item.SetFieldValue(Item["TAR_DESC"], RadTextBox3.Text, false);
				Item.SetFieldValue(Item["TAR_TIPO"], ComboBox1.SelectedValue);
				Item.SetFieldValue(Item["NEG_ID"], ComboBox2.SelectedValue);
				Item.SetFieldValue(Item["TAR_RESPONSAVEL"], ComboBox3.SelectedValue);
				Item.SetFieldValue(Item["TAR_FINALIZADO"], RadCheckBox1.Checked);
				if (DatePicker1.SelectedDate != null) Item.SetFieldValue(Item["TAR_DATAHORA"], DatePicker1.SelectedDate.Value.ToString("dd/MM/yyyy HH:mm"));
				else Item.SetFieldValue(Item["TAR_DATAHORA"], DBNull.Value);
			}
			else
			{
				Item = PageProvider.MainProvider.DataProvider.SelectItem(PageNumber, FormPositioningEnum.Current);
			}
			if (EnableValidation)
			{
				InitializeAlias(Item);
				if (PageState == FormStateEnum.Insert)
				{
					FillAuxiliarTables();
				}
				PageProvider.Validate(Item); 
			}
			if (Item!=null) PageErrors.Add(Item.Errors);
			return Item;
		}
		

		/// <summary>
		/// Define a Máscara para cada campo na tela
		/// </summary>
		public override void DefineMask()
		{
			Mask.SetMask(DatePicker1.DateInput, "99/99/9999 99:99", 16, false);
		}

		public override void DefineStartScripts()
		{
			Utility.SetControlTabOnEnter(RadTextBox3);
			Utility.SetControlTabOnEnter(ComboBox1);
			Utility.SetControlTabOnEnter(ComboBox2);
			Utility.SetControlTabOnEnter(ComboBox3);
			Utility.SetControlTabOnEnter(RadCheckBox1);
		}
		
		public override void DisableEnableContros(bool Action)
		{
			RadTextBox3.Attributes.Add("EnableEdit", "True");
			ComboBox1.Attributes.Add("EnableEdit", "True");
			ComboBox2.Attributes.Add("EnableEdit", "True");
			ComboBox3.Attributes.Add("EnableEdit", "True");
			RadCheckBox1.Attributes.Add("EnableEdit", "True");
			DatePicker1.Attributes.Add("EnableEdit", "True");
		}

		/// <summary>
		/// Limpa Campos na tela
		/// </summary>
		public override void ClearFields(bool ShouldClearFields)
		{
			if (ShouldClearFields)
			{
				RadTextBox3.Text = "";
				ComboBox1.SelectedIndex = -1;
				ComboBox1.Text = "";
				ComboBox2.SelectedIndex = -1;
				ComboBox2.Text = "";
				ComboBox3.SelectedIndex = -1;
				ComboBox3.Text = "";
				RadCheckBox1.Checked = false;
				DatePicker1.SelectedDate = null;
			}
			if (!PageInsert && PageState == FormStateEnum.Navigation)
				DisableEnableContros(false);				
			else
				DisableEnableContros(true);				
		}		

		public override void ShowInitialValues()
		{
			try
			{
				ComboBox2.SelectedValue = (int.Parse(Par_neg)).ToString();
				DataRow DR = PageProvider.ComboBox2_GetComboItem(ComboBox2.SelectedValue);
				ComboBox2.Text = DR["DISPLAY_FIELD"].ToString();
			}
			catch (Exception e)
			{
				ComboBox2.SelectedValue = "";
				ComboBox2.Text = "";
			}
			DatePicker1.SelectedDate = null;
		}

		public override void PageEdit()
		{
			base.PageEdit(); 
		}

		public override void ShowFormulas()
		{
			Label2.Text = Label2.Text.Replace("<", "&lt;");
			Label2.Text = Label2.Text.Replace(">", "&gt;");
			Label3.Text = Label3.Text.Replace("<", "&lt;");
			Label3.Text = Label3.Text.Replace(">", "&gt;");
			Label4.Text = Label4.Text.Replace("<", "&lt;");
			Label4.Text = Label4.Text.Replace(">", "&gt;");
			Label6.Text = Label6.Text.Replace("<", "&lt;");
			Label6.Text = Label6.Text.Replace(">", "&gt;");
			Label7.Text = Label7.Text.Replace("<", "&lt;");
			Label7.Text = Label7.Text.Replace(">", "&gt;");
			Label1.Text = Label1.Text.Replace("<", "&lt;");
			Label1.Text = Label1.Text.Replace(">", "&gt;");
		}
		
		/// <summary>
		/// Define conteudo dos objetos de Tela
		/// </summary>
		public override void DefinePageContent(GeneralDataProviderItem Item)
		{
			try { RadTextBox3.Text = Item["TAR_DESC"].GetFormattedValue(); }
			catch { RadTextBox3.Text = ""; }
			try
			{
				string Val = Item["TAR_TIPO"].GetFormattedValue();
				if (ComboBox1.Items.Count == 0)
				{
					RadComboBoxDataItem item = Utility.FindComboBoxItem(PageProvider.ComboBox1Items, Val);
					ComboBox1.Text = item.Text;
					ComboBox1.SelectedValue = item.Value;
					ComboBox1.Attributes.Add("AllowFilter", "False");
				}
			}
			catch
			{
				ComboBox1.SelectedValue = "";
				ComboBox1.Text = "";
			}
			try
			{
				string Val = Item["NEG_ID"].GetFormattedValue();
				if (ComboBox2.Items.Count == 0)
				{
					DataRow row = PageProvider.ComboBox2_GetComboItem(Val);
					ComboBox2.Text = row["DISPLAY_FIELD"].ToString();
					ComboBox2.SelectedValue = row["NEG_ID"].ToString();
					ComboBox2.Attributes.Add("AllowFilter", "False");
				}
			}
			catch
			{
				ComboBox2.SelectedValue = "";
				ComboBox2.Text = "";
			}
			try
			{
				string Val = Item["TAR_RESPONSAVEL"].GetFormattedValue();
				if (ComboBox3.Items.Count == 0)
				{
					ComboBox3.Attributes["Encrypt"] = "False";
					DataRow row = PageProvider.ComboBox3_GetComboItem(Val);
					ComboBox3.Text = Crypt.Decripta(row["DISPLAY_FIELD"].ToString());
					ComboBox3.SelectedValue = row["LOGIN_USER_LOGIN"].ToString();
					ComboBox3.Attributes.Add("AllowFilter", "False");
				}
			}
			catch
			{
				ComboBox3.SelectedValue = "";
				ComboBox3.Text = "";
			}
			try
			{
				RadCheckBox1.Attributes.Add("OnClick","InitiateEditAuto();");
				RadCheckBox1.Checked = (Item["TAR_FINALIZADO"].Value != null && Convert.ToBoolean(Item["TAR_FINALIZADO"].Value));
			}
			catch { RadCheckBox1.Checked = false;}
			try { DatePicker1.SelectedDate = Convert.ToDateTime(Item["TAR_DATAHORA"].GetFormattedValue("dd/MM/yyyy HH:mm")); }
			catch { DatePicker1.SelectedDate = null; }
			ApplyMasks(RadTextBox3);
			ApplyMasks(DatePicker1);
			InitializePageContent();
			base.DefinePageContent(Item);
		}
		
		/// <summary>
		/// Define apelidos da Página
		/// </summary>
		public override void InitializeAlias(GeneralDataProviderItem Item)
        {
			PageProvider.AliasVariables = new Dictionary<string, object>();
			PageProvider.AliasVariables.Clear();
			
			try
			{
				TAR_DESCField = Item["TAR_DESC"].GetFormattedValue();
			}
			catch
			{
				TAR_DESCField = "";
			}
			try
			{
				TAR_TIPOField = Item["TAR_TIPO"].GetFormattedValue();
			}
			catch
			{
				TAR_TIPOField = "";
			}
			try
			{
				NEG_IDField = long.Parse(Item["NEG_ID"].GetFormattedValue());
			}
			catch
			{
				NEG_IDField = 0;
			}
			try
			{
				TAR_RESPONSAVELField = Item["TAR_RESPONSAVEL"].GetFormattedValue();
			}
			catch
			{
				TAR_RESPONSAVELField = "";
			}
			try
			{
				TAR_FINALIZADOField = Convert.ToBoolean(Item["TAR_FINALIZADO"].Value);
			}
			catch
			{
				TAR_FINALIZADOField = false;
			}
			try
			{
				TAR_DATAHORAField = Convert.ToDateTime(Item["TAR_DATAHORA"].GetFormattedValue("dd/MM/yyyy HH:mm"));
			}
			catch
			{
				TAR_DATAHORAField = null;
			}
			try
			{
				TAR_IDField = long.Parse(Item["TAR_ID"].GetFormattedValue(), CultureInfo.CurrentCulture);
			}
			catch
			{
				TAR_IDField = 0;
			}
			try
			{
				CLI_IDField = long.Parse(Item["CLI_ID"].GetFormattedValue(), CultureInfo.CurrentCulture);
			}
			catch
			{
				CLI_IDField = 0;
			}
			PageProvider.AliasVariables.Add("TAR_DESCField", TAR_DESCField);
			PageProvider.AliasVariables.Add("TAR_TIPOField", TAR_TIPOField);
			PageProvider.AliasVariables.Add("NEG_IDField", NEG_IDField);
			PageProvider.AliasVariables.Add("TAR_RESPONSAVELField", TAR_RESPONSAVELField);
			PageProvider.AliasVariables.Add("TAR_FINALIZADOField", TAR_FINALIZADOField);
			PageProvider.AliasVariables.Add("TAR_DATAHORAField", TAR_DATAHORAField);
			PageProvider.AliasVariables.Add("TAR_IDField", TAR_IDField);
			PageProvider.AliasVariables.Add("CLI_IDField", CLI_IDField);
			PageProvider.AliasVariables.Add("ParTarID", ParTarID);
			PageProvider.AliasVariables.Add("Par_neg", Par_neg);
			PageProvider.AliasVariables.Add("BasePage", this);
        }

		protected void ___Form1_OnSaveSucceeded(GeneralDataProviderItem Item)
		{
			bool ActionSucceeded_1 = true;
			try
			{
				AjaxPanel.ResponseScripts.Add("try {getParentPage().GetRadWindowManager().GetActiveWindow().Caller.Refresh();} catch (e) {}");
			}
			catch (Exception ex)
			{
				ActionSucceeded_1 = false;
				PageErrors.Add("Error", ex.Message);
				ShowErrors();
			}
			bool ActionSucceeded_2 = true;
			try
			{
				if (ActionSucceeded_1)
				{
						AjaxPanel.Alert("Salvo com Sucesso!");
				}
			}
			catch (Exception ex)
			{
				ActionSucceeded_2 = false;
				PageErrors.Add("Error", ex.Message);
				ShowErrors();
			}
		}

		protected void ___Form1_OnRemoveSucceeded(GeneralDataProviderItem Item)
		{
			bool ActionSucceeded_1 = true;
			try
			{
				AjaxPanel.ResponseScripts.Add("try {getParentPage().GetRadWindowManager().GetActiveWindow().Caller.Refresh();} catch (e) {}");
			}
			catch (Exception ex)
			{
				ActionSucceeded_1 = false;
				PageErrors.Add("Error", ex.Message);
				ShowErrors();
			}
			bool ActionSucceeded_2 = true;
			try
			{
				if (ActionSucceeded_1)
				{
						AjaxPanel.Alert("Tarefa Removida com Sucesso!");
				}
			}
			catch (Exception ex)
			{
				ActionSucceeded_2 = false;
				PageErrors.Add("Error", ex.Message);
				ShowErrors();
			}
		}

		protected void ___Button8_OnClick(object sender, EventArgs e)
		{
			bool ActionSucceeded_1 = true;
			try
			{
				string UrlPage = ResolveUrl("~/Pages/Neg_cio.aspx");
				UrlPage += '?' + "Par_NegID=" + (Convert.ToInt32(PageProvider.AliasVariables["NEG_IDField"])).ToString();
				try
				{
					Response.Redirect(UrlPage);
				}
				catch(Exception ex)
				{
				}
			}
			catch (Exception ex)
			{
				ActionSucceeded_1 = false;
				PageErrors.Add("Error", ex.Message);
				ShowErrors();
			}
		}





		public override void ExecuteServerCommandRequest(string CommandName, string TargetName, string[] Parameters)
		{
			ExecuteLocalCommandRequest(CommandName, TargetName, Parameters);
		}		





		protected void ___ComboBox1_OnItemsRequested(object sender, RadComboBoxItemsRequestedEventArgs e)
		{
			KeyValuePair<string, object> AllowFilterContext = e.Context.FirstOrDefault(c => c.Key == "AllowFilter");
			bool AllowFilter = false;
			if (AllowFilterContext.Value != null) AllowFilter = Convert.ToBoolean(AllowFilterContext.Value);
		
			KeyValuePair<string, object> IsRefreshContext = e.Context.FirstOrDefault(c => c.Key == "IsRefresh");
			bool IsRefresh = false;
			if (IsRefreshContext.Value != null) IsRefresh = Convert.ToBoolean(IsRefreshContext.Value);
		
			int ItemsCount = Convert.ToInt32(e.Context["ItemsCount"]);
			e.EndOfItems = PageProvider.FillComboBox1(sender as RadComboBox, e.NumberOfItems, e.Text, AllowFilter);
		}
		
		protected void ___ComboBox2_OnItemsRequested(object sender, RadComboBoxItemsRequestedEventArgs e)
		{
			KeyValuePair<string, object> AllowFilterContext = e.Context.FirstOrDefault(c => c.Key == "AllowFilter");
			bool AllowFilter = false;
			if (AllowFilterContext.Value != null) AllowFilter = Convert.ToBoolean(AllowFilterContext.Value);
		
			KeyValuePair<string, object> IsRefreshContext = e.Context.FirstOrDefault(c => c.Key == "IsRefresh");
			bool IsRefresh = false;
			if (IsRefreshContext.Value != null) IsRefresh = Convert.ToBoolean(IsRefreshContext.Value);
		
			int ItemsCount = Convert.ToInt32(e.Context["ItemsCount"]);
			e.EndOfItems = PageProvider.FillComboBox2(sender as RadComboBox, e.NumberOfItems, e.Text, AllowFilter);
		}
		
		protected void ___ComboBox3_OnItemsRequested(object sender, RadComboBoxItemsRequestedEventArgs e)
		{
			KeyValuePair<string, object> AllowFilterContext = e.Context.FirstOrDefault(c => c.Key == "AllowFilter");
			bool AllowFilter = false;
			if (AllowFilterContext.Value != null) AllowFilter = Convert.ToBoolean(AllowFilterContext.Value);
		
			KeyValuePair<string, object> IsRefreshContext = e.Context.FirstOrDefault(c => c.Key == "IsRefresh");
			bool IsRefresh = false;
			if (IsRefreshContext.Value != null) IsRefresh = Convert.ToBoolean(IsRefreshContext.Value);
		
			int ItemsCount = Convert.ToInt32(e.Context["ItemsCount"]);
			e.EndOfItems = PageProvider.FillComboBox3(sender as RadComboBox, e.NumberOfItems, e.Text, AllowFilter);
		}
		public override void OnRemoveSucceeded(GeneralDataProviderItem Item)
		{
			___Form1_OnRemoveSucceeded(Item);
		}
		public override void SaveSucceeded(GeneralDataProviderItem Item)
		{
			___Form1_OnSaveSucceeded(Item);
		}
	}
}

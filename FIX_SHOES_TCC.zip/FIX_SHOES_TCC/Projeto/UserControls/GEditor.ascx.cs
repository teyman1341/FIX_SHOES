using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;

namespace COMPONENTS
{
    public enum Mode
    {
        Design,
        Html,
        DesignAndHtml,
        Preview
    }
    public partial class GEditor : System.Web.UI.UserControl
    {

        public string cssClass { get; set; }

        public GEditor()
        {
            ShowToolbarFind = true;
            ShowToolbarPrint = true;
            ShowToolbarCopyPaste = true;
            ShowToolbarUndoRedo = true;
            ShowToolbarTime = true;
            ShowToolbarLink = true;
            ShowToolbarParagraph = true;
            ShowToolbarAlign = true;
            ShowToolbarFontSize = true;
            ShowToolbarFont = true;
            ShowToolbarViewMode = true;
        }

        #region Property

        public bool ShowToolbarFind { get; set; }
        public bool ShowToolbarPrint { get; set; }
        public bool ShowToolbarCopyPaste { get; set; }
        public bool ShowToolbarUndoRedo { get; set; }
        public bool ShowToolbarTime { get; set; }
        public bool ShowToolbarLink { get; set; }
        public bool ShowToolbarParagraph { get; set; }
        public bool ShowToolbarAlign { get; set; }
        public bool ShowToolbarFontSize { get; set; }
        public bool ShowToolbarFont { get; set; }
        public bool ShowToolbarViewMode { get; set; }
		public string Skin { get; set; }
        public Mode ViewMode { get; set; }

        public bool Enabled
        {
            get
            {
                return Editor.EditModes != EditModes.Preview;
            }
            set
            {
                EnableEditor(value);
            }
        }

        public string Content
        {
            get
            {
                return Editor.Content.ToString();
            }
            set
            {
                Editor.Content = value;
            }
        }
        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
            ContentEditor.ID = this.ID;
            ContentEditor.CssClass = this.cssClass;
            RemoveToolbar();
			Editor.Skin = Skin;
            Editor.OnClientLoad = "OnClientLoad_" + this.ClientID;
        }

        private void EnableEditor(bool enabled)
        {
            if (enabled)
            {
                switch (ViewMode)
                {
                    case Mode.Design:
                        Editor.EditModes = EditModes.Design;
                        break;
                    case Mode.Html:
                        Editor.EditModes = EditModes.Html;
                        break;
                    case Mode.DesignAndHtml:
                        Editor.EditModes = EditModes.Design | EditModes.Html;
                        break;
                    case Mode.Preview:
                        Editor.EditModes = EditModes.Preview;
                        break;
                    default:
                        break;
                }
            }
            else
            {
                Editor.EditModes = EditModes.Preview;
            }

        }
 
        public void RemoveToolbar()
        {
			List<EditorToolGroup> RemoveTools = new List<EditorToolGroup>();

			if (ShowToolbarFind || ShowToolbarPrint || ShowToolbarCopyPaste || ShowToolbarUndoRedo || ShowToolbarTime || 
				ShowToolbarLink || ShowToolbarParagraph || ShowToolbarAlign || ShowToolbarFontSize || ShowToolbarFont || ShowToolbarViewMode)
			{

				foreach (EditorToolGroup Tool in Editor.Tools)
				{

					switch (Tool.Tag)
					{
						case "FindAndReplace":
							if (!ShowToolbarFind) RemoveTools.Add(Tool);
							break;
						case "Print":
							if (!ShowToolbarPrint) RemoveTools.Add(Tool);
							break;
						case "CopyPaste":
							if (!ShowToolbarCopyPaste) RemoveTools.Add(Tool);
							break;
						case "UndoRedo":
							if (!ShowToolbarUndoRedo) RemoveTools.Add(Tool);
							break;
						case "Time":
							if (!ShowToolbarTime) RemoveTools.Add(Tool);
							break;
						case "Link":
							if (!ShowToolbarLink) RemoveTools.Add(Tool);
							break;
						case "Paragraph":
							if (!ShowToolbarParagraph) RemoveTools.Add(Tool);
							break;
						case "Align":
							if (!ShowToolbarAlign) RemoveTools.Add(Tool);
							break;
						case "FontSize":
							if (!ShowToolbarFontSize) RemoveTools.Add(Tool);
							break;
						case "Font":
							if (!ShowToolbarFont) RemoveTools.Add(Tool);
							break;
						case "ViewMode":
							if (!ShowToolbarViewMode) RemoveTools.Add(Tool);
							break;
						default:
							break;
					}
				}
			}
			else
			{

				bool SkipNext = true;
				foreach (EditorToolGroup tool in Editor.Tools)
				{
					if (!SkipNext)
					{
						RemoveTools.Add(tool);
					}
					else
					{
						tool.Tools.Clear();
						SkipNext = false;
					}
				}

				if (!this.Page.IsPostBack)
				{
					((PROJETO.DataPages.GeneralDataPage)this.Page).ClientScript.RegisterStartupScript(this.GetType(), "DisableToolbar" + this.ClientID, "<script>HideToolbar();</script>");
				}
				else
				{
					((PROJETO.DataPages.GeneralDataPage)this.Page).AjaxPanel.ResponseScripts.Add(String.Format("HideToolbar();", this.ClientID));
				}
			}

			foreach (EditorToolGroup tool in RemoveTools)
			{
				Editor.Tools.Remove(tool);
			}
        }

    }
}
